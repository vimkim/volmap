import { densityUrl } from "./density-address";
import { loadVolumeCells } from "./volume-fixture";
import { chromium, firefox, expect, test, type Page } from "@playwright/test";
import { readFile, readdir, writeFile } from "node:fs/promises";
import { execFileSync } from "node:child_process";
import { cpus, hostname, release, totalmem } from "node:os";
import { createHash } from "node:crypto";

// A dedicated browser process tree with one tab. Summed RSS includes shared
// pages in each process; this is conservative accounting, not JS heap size.
const pageSize = Number(execFileSync("getconf", ["PAGESIZE"], { encoding: "utf8" }).trim());

async function rssTree(root: number): Promise<number> {
  const pending = [root];
  const seen = new Set<number>();
  let total = 0;
  while (pending.length > 0) {
    const pid = pending.pop()!;
    if (seen.has(pid)) continue;
    seen.add(pid);
    try {
      const resident = Number((await readFile(`/proc/${pid}/statm`, "utf8")).trim().split(/\s+/)[1]);
      if (!Number.isSafeInteger(resident) || resident < 0 || (pid === root && resident === 0)) throw new Error(`Invalid resident pages for browser process ${pid}`);
      total += resident * pageSize;
      // Children may be forked by any thread (not just the process leader).
      for (const tid of await readdir(`/proc/${pid}/task`)) {
        try {
          const children = (await readFile(`/proc/${pid}/task/${tid}/children`, "utf8")).trim();
          if (children) pending.push(...children.split(/\s+/).map(Number));
        } catch (error) {
          if (!["ENOENT", "ESRCH"].includes((error as NodeJS.ErrnoException).code ?? "")) throw error;
        }
      }
    } catch (error) {
      if (pid === root || !["ENOENT", "ESRCH"].includes((error as NodeJS.ErrnoException).code ?? "")) throw error;
    }
  }
  return total;
}

for (const enabled of [false, true]) {
test(`same-browser20cycles: ${enabled ? "toggle-lru" : "disabled-control"}`, async ({}, testInfo) => {
  const browserServer = await chromium.launchServer({ headless: true });
  const pid = browserServer.process().pid!;
  const browser = await chromium.connect(browserServer.wsEndpoint());
  const page = await browser.newPage({ viewport: { width: 1920, height: 1080 } });
  const cdp = await page.context().newCDPSession(page);
  await cdp.send("Performance.enable");
  const samples: object[] = [];
  const started = performance.now();
  const metadata = {
    consumerCommit: execFileSync("git", ["rev-parse", "HEAD"], { encoding: "utf8" }).trim(),
    browserVersion: browser.version(),
    host: { name: hostname(), kernel: release(), cpu: cpus()[0]?.model, logicalCpus: cpus().length, memoryBytes: totalmem() },
    enabled, cycleCount: 20, inputsPerCycle: 40, viewport: { width: 1920, height: 1080 },
    method: "Diagnostic same-browser fixed cycles. RSS snapshots are not peaks. Forced GC at cycles0/5/10/20 is an intervention and is not release acceptance.",
  };
  let completed = 0;
  let failure: string | null = null;
  const capture = async (cycle: number, phase: string) => {
    const metrics = await cdp.send("Performance.getMetrics");
    const byName = Object.fromEntries(metrics.metrics.map((m: { name: string; value: number }) => [m.name, m.value]));
    const dom = await cdp.send("Memory.getDOMCounters");
    samples.push({ cycle, phase, elapsedMs: performance.now() - started, rssBytes: await rssTree(pid),
      jsHeapUsedBytes: byName.JSHeapUsedSize, jsHeapTotalBytes: byName.JSHeapTotalSize, ...dom });
    await writeFile(testInfo.outputPath("growth.json"), JSON.stringify({ ...metadata, completed, failure, samples }, null, 2));
  };
  try {
    await page.goto(`${densityUrl}/volume/0`, { waitUntil: "commit" });
    await loadVolumeCells(page, 12288);
    expect(await page.locator("[data-observation-page]").evaluateAll((nodes) => nodes.filter((n) => n.getClientRects().length > 0).length)).toBe(12288);
    await cdp.send("HeapProfiler.collectGarbage");
    await capture(0, "disabled-after-gc");
    for (let cycle = 1; cycle <= 20; cycle += 1) {
      await page.evaluate(() => window.scrollTo(0, 0));
      if (enabled) {
        await page.getByRole("button", { name: "Enable observations", exact: true }).click();
        await expect(page.locator('.observation-detail[aria-label="Visible-page buffer observations"]')).toContainText("Evaluated 512 / requested 512");
        await page.getByRole("combobox", { name: "Runtime color mode" }).selectOption("lru");
      }
      await page.locator("#sector-0").focus();
      for (let i = 0; i < 40; i += 1) {
        await page.keyboard.press("Tab");
        await page.evaluate(() => new Promise<void>((resolve) => requestAnimationFrame(() => requestAnimationFrame(() => resolve()))));
      }
      await capture(cycle, enabled ? "enabled-after-inputs" : "control-after-inputs");
      if (enabled) await page.getByRole("button", { name: "Disable observations", exact: true }).click();
      await page.waitForTimeout(1000);
      completed = cycle;
      await capture(cycle, "disabled-after-settle");
      if ([5, 10, 20].includes(cycle)) {
        await cdp.send("HeapProfiler.collectGarbage");
        await capture(cycle, "disabled-after-gc");
      }
    }
    expect(completed).toBe(20);
  } catch (error) {
    failure = String(error);
    throw error;
  } finally {
    await writeFile(testInfo.outputPath("growth.json"), JSON.stringify({ ...metadata, completed, failure, samples }, null, 2));
    await cdp.detach();
    await browser.close();
    await browserServer.close();
  }
});
}
