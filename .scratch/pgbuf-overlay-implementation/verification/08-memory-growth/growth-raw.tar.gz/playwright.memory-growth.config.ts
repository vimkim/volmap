import { defineConfig } from "@playwright/test";
import density from "./playwright.density.config";
export default defineConfig({ ...density, testMatch: "**/memory-growth-probe.spec.ts", timeout: 240_000, outputDir: "../.scratch/pgbuf-overlay-implementation/verification/08-memory-growth/results" });
