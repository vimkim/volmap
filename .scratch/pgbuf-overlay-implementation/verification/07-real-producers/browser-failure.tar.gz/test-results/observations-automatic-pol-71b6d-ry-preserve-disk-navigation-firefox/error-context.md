# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: observations.spec.ts >> automatic polling, paused offers, hidden silence, resume and expiry preserve disk navigation
- Location: e2e/observations.spec.ts:37:1

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: page.goto: Test timeout of 30000ms exceeded.
Call log:
  - navigating to "http://127.0.0.1:41741/page/0/10", waiting until "commit"

```

# Page snapshot

```yaml
- generic [ref=e2]:
  - banner [ref=e3]:
    - strong [ref=e4]: VOLMAP
    - generic [ref=e5]: snapshot 4240cd83d344 · revision 1
    - generic [ref=e6]:
      - generic [ref=e7]: "paused at gen 0 · newer: gen 0"
      - button "Resume" [active] [pressed] [ref=e8] [cursor=pointer]
    - button "About & licenses" [ref=e9] [cursor=pointer]
    - generic [ref=e10]: success-limited
  - main [ref=e11]:
    - complementary [ref=e12]:
      - region "CUBRID page-buffer observation" [ref=e13]:
        - heading "CUBRID page-buffer observation" [level=2] [ref=e14]
        - button "Disable observations" [pressed] [ref=e15] [cursor=pointer]
        - generic [ref=e16]:
          - text: Runtime color mode
          - combobox "Runtime color mode" [ref=e17]:
            - option "State marks" [selected]
            - option "LRU topology"
        - button "Refresh selected-page observation" [disabled] [ref=e18]
        - paragraph [ref=e19]: Observation expired
        - paragraph [ref=e20]: "Observation source: active"
      - heading "Snapshot hierarchy" [level=2] [ref=e21]
      - button "volume 0 · 64 sectors" [ref=e23] [cursor=pointer]
    - generic [ref=e24]:
      - navigation "Inspection hierarchy" [ref=e25]:
        - button "← Back" [ref=e26] [cursor=pointer]
        - button "Volume 0" [ref=e28] [cursor=pointer]
        - generic [ref=e29]:
          - text: ›
          - button "Sector 0" [ref=e30] [cursor=pointer]
        - generic [ref=e31]: ›Page 10
      - generic [ref=e32]:
        - generic [ref=e34]:
          - heading "Page 10" [level=1] [ref=e35]
          - paragraph [ref=e36]: heap · detailed structural view
        - generic [ref=e37]:
          - generic [ref=e38]:
            - heading "Page facts" [level=2] [ref=e39]
            - generic [ref=e40]:
              - generic [ref=e41]:
                - term [ref=e42]: Identity
                - definition [ref=e43]: page:0:10
              - generic [ref=e44]:
                - term [ref=e45]: Sector
                - definition [ref=e46]: "0"
              - generic [ref=e47]:
                - term [ref=e48]: Physical type
                - definition [ref=e49]: heap
              - generic [ref=e50]:
                - term [ref=e51]: Allocation
                - definition [ref=e52]: reserved-unallocated
              - generic [ref=e53]:
                - term [ref=e54]: File
                - definition [ref=e55]: none
              - generic [ref=e56]:
                - term [ref=e57]: File role
                - definition [ref=e58]: none
              - generic [ref=e59]:
                - term [ref=e60]: Class OID
                - definition [ref=e61]: none
              - generic [ref=e62]:
                - term [ref=e63]: Class/table
                - definition [ref=e64]: none
              - generic [ref=e65]:
                - term [ref=e66]: Availability
                - definition [ref=e67]: available
              - generic [ref=e68]:
                - term [ref=e69]: Detail support
                - definition [ref=e70]: semantic
              - generic [ref=e71]:
                - term [ref=e72]: Deep state
                - definition [ref=e73]: slotted
              - generic [ref=e74]:
                - term [ref=e75]: TDE
                - definition [ref=e76]: not-encrypted
            - heading "Decoded structure" [level=3] [ref=e77]
            - generic [ref=e78]:
              - generic [ref=e79]:
                - term [ref=e80]: anchor
                - definition [ref=e81]: anchored
              - generic [ref=e82]:
                - term [ref=e83]: alignment
                - definition [ref=e84]: "8"
              - generic [ref=e85]:
                - term [ref=e86]: total free
                - definition [ref=e87]: "16312"
              - generic [ref=e88]:
                - term [ref=e89]: contiguous free
                - definition [ref=e90]: "16312"
              - generic [ref=e91]:
                - term [ref=e92]: free area offset
                - definition [ref=e93]: "32"
              - generic [ref=e94]:
                - term [ref=e95]: flags
                - definition [ref=e96]: "0"
              - generic [ref=e97]:
                - term [ref=e98]: is saving
                - definition [ref=e99]: "false"
            - paragraph [ref=e100]: evidence page:0:10 · structural ranges only · bytes withheld
          - region "Selected-page buffer observation" [ref=e101]:
            - heading "Buffer observation" [level=2] [ref=e102]
            - paragraph [ref=e103]: Observation expired
            - paragraph [ref=e104]: Refresh to request a separate runtime observation. Disk facts remain independently observed.
          - generic [ref=e105]:
            - heading "Full slotted-page distribution" [level=2] [ref=e106]
            - generic [ref=e107]:
              - generic [ref=e108]:
                - strong [ref=e109]: "0"
                - generic [ref=e110]: allocated records
              - generic [ref=e111]:
                - strong [ref=e112]: "0"
                - generic [ref=e113]: slots not allocated
              - generic [ref=e114]:
                - strong [ref=e115]: "1"
                - generic [ref=e116]: free byte regions
              - generic [ref=e117]:
                - strong [ref=e118]: 16312 B
                - generic [ref=e119]: unoccupied bytes
            - generic [ref=e120]:
              - generic [ref=e121]: Slotted header
              - generic [ref=e123]: Allocated record
              - generic [ref=e125]: Fragmented free
              - generic [ref=e127]: Contiguous free
              - generic [ref=e129]: Slot directory
            - generic "Complete 16344-byte slotted-page content map" [ref=e131]:
              - 'generic "Slotted-page header: offset 0, size 32 bytes, end 32" [ref=e132]'
              - 'generic "Contiguous free region 1: offset 32, size 16312 bytes, end 16344" [ref=e133]'
              - 'generic "Slot directory: offset 16344, size 0 bytes, end 16344" [ref=e134]'
            - generic [ref=e135]:
              - generic [ref=e136]: "0"
              - generic [ref=e137]: "4086"
              - generic [ref=e138]: "8172"
              - generic [ref=e139]: "12258"
              - generic [ref=e140]: "16344"
            - generic [ref=e141]:
              - generic [ref=e142]:
                - heading "Physical intervals" [level=3] [ref=e143]
                - generic [ref=e144]: 3 exhaustive non-overlapping regions
              - generic [ref=e145]:
                - generic [ref=e146]:
                  - generic [ref=e147]: Slotted-page header
                  - generic [ref=e150]: 0–32
                  - generic [ref=e151]: 32 B
                - generic [ref=e154]:
                  - generic [ref=e155]: Contiguous free region 1
                  - generic [ref=e158]: 32–16344
                  - generic [ref=e159]: 16312 B
                - generic [ref=e162]:
                  - generic [ref=e163]: Slot directory
                  - generic [ref=e166]: 16344–16344
                  - generic [ref=e167]: 0 B
            - generic [ref=e171]:
              - heading "Slot directory" [level=3] [ref=e172]
              - generic [ref=e173]: 0 entries · allocated, empty, and deleted
```

# Test source

```ts
  1   | import { expect, test } from "@playwright/test";
  2   | 
  3   | // Firefox can keep document readiness pending alongside the live watch.
  4   | // Wait for navigation commit, then assert rendered controls and observations.
  5   | 
  6   | test("selected-page observation uses the real producer, HTTP boundary and non-color detail", async ({ page, browserName }) => {
  7   |   const errors: string[] = [];
  8   |   page.on("pageerror", (error) => errors.push(error.message));
  9   |   await page.goto("http://127.0.0.1:41741/page/0/10", { waitUntil: "commit" });
  10  |   await expect(page.getByRole("heading", { name: "Page facts" })).toBeVisible();
  11  |   const source = page.getByRole("region", { name: "CUBRID page-buffer observation" });
  12  |   await source.getByRole("button", { name: "Enable observations" }).click();
  13  |   const response = page.waitForResponse((response) => response.url().endsWith("/runtime/page-buffer/observe"));
  14  |   await source.getByRole("button", { name: "Refresh selected-page observation" }).click();
  15  |   const observed = await response;
  16  |   expect(observed.status()).toBe(200);
  17  |   expect(observed.headers()["cache-control"]).toBe("no-store");
  18  |   const detail = page.getByRole("region", { name: "Selected-page buffer observation" });
  19  |   await expect(detail).toContainText("◉ Observed resident");
  20  |   await expect(detail).toContainText("VPID 0:10");
  21  |   await expect(source).toContainText("Observation source: active");
  22  |   await expect(detail).toContainText("latch mode");
  23  |   await expect(detail).toContainText("oldest unflush lsa");
  24  |   await detail.getByText("Capture identity and limitations", { exact: true }).click();
  25  |   await expect(detail).toContainText("records and scans are not atomic");
  26  |   await expect(page.getByRole("heading", { name: "Page facts" })).toBeVisible();
  27  |   await page.getByRole("button", { name: "Pause", exact: true }).click();
  28  |   await expect(source.getByRole("button", { name: "Refresh selected-page observation" })).toBeDisabled();
  29  |   await expect(detail).toContainText("paused");
  30  |   await page.evaluate(() => window.scrollTo(0, 0));
  31  |   await page.screenshot({ path: `../.scratch/pgbuf-overlay-implementation/verification/selected-observation-${browserName}.png`, fullPage: true });
  32  |   await source.getByRole("button", { name: "Disable observations" }).click();
  33  |   await expect(detail).toHaveCount(0);
  34  |   expect(errors).toEqual([]);
  35  | });
  36  | 
  37  | test("automatic polling, paused offers, hidden silence, resume and expiry preserve disk navigation", async ({ page, context, browserName }) => {
  38  |   await page.clock.install();
  39  |   await page.goto("http://127.0.0.1:41741/page/0/10", { waitUntil: "commit" });
  40  |   const source = page.getByRole("region", { name: "CUBRID page-buffer observation" });
  41  |   const detail = page.getByRole("region", { name: "Selected-page buffer observation" });
  42  |   let observations = 0;
  43  |   let metadata = 0;
  44  |   page.on("request", (request) => {
  45  |     if (request.url().endsWith("/page-buffer/observe")) observations += 1;
  46  |     if (request.url().endsWith("/runtime/capabilities")) metadata += 1;
  47  |   });
  48  |   await source.getByRole("button", { name: "Enable observations" }).click();
  49  |   await expect(detail).toContainText("Observed resident");
  50  |   const first = observations;
  51  |   await page.clock.runFor(500);
  52  |   await expect.poll(() => observations).toBeGreaterThan(first);
  53  |   await expect(source.getByRole("button", { name: "Refresh selected-page observation" })).toBeEnabled();
  54  |   await page.getByRole("button", { name: "Pause", exact: true }).click();
  55  |   const pausedRequests = observations;
  56  |   const beforeMetadata = metadata;
  57  |   const other = await context.newPage();
> 58  |   await other.goto("http://127.0.0.1:41741/page/0/10", { waitUntil: "commit" });
      |               ^ Error: page.goto: Test timeout of 30000ms exceeded.
  59  |   const otherSource = other.getByRole("region", { name: "CUBRID page-buffer observation" });
  60  |   await otherSource.getByRole("button", { name: "Enable observations" }).click();
  61  |   await expect(other.getByRole("region", { name: "Selected-page buffer observation" })).toContainText("Observed resident");
  62  |   await other.waitForResponse((response) => response.url().endsWith("/page-buffer/observe"));
  63  |   await page.clock.runFor(5000);
  64  |   await expect(source).toContainText("Newer observation available");
  65  |   expect(observations).toBe(pausedRequests);
  66  |   expect(metadata).toBeGreaterThan(beforeMetadata);
  67  |   await other.close();
  68  | 
  69  |   await page.evaluate(() => {
  70  |     Object.defineProperty(document, "visibilityState", { configurable: true, get: () => "hidden" });
  71  |     document.dispatchEvent(new Event("visibilitychange"));
  72  |   });
  73  |   const hiddenMetadata = metadata;
  74  |   await page.clock.runFor(10000);
  75  |   expect(metadata).toBe(hiddenMetadata);
  76  |   expect(observations).toBe(pausedRequests);
  77  |   await page.evaluate(() => {
  78  |     Object.defineProperty(document, "visibilityState", { configurable: true, get: () => "visible" });
  79  |     document.dispatchEvent(new Event("visibilitychange"));
  80  |   });
  81  |   const resumedRequest = page.waitForRequest((request) => request.url().endsWith("/page-buffer/observe"));
  82  |   await page.getByRole("button", { name: "Resume", exact: true }).click();
  83  |   expect((await resumedRequest).postDataJSON().after_request).toBe(true);
  84  |   await expect(detail).toContainText("Observed resident");
  85  |   await expect(source.getByRole("button", { name: "Refresh selected-page observation" })).toBeEnabled();
  86  |   await page.getByRole("button", { name: "Pause", exact: true }).click();
  87  |   await page.clock.runFor(31000);
  88  |   await expect(detail).toContainText("Observation expired");
  89  |   await expect(page.getByRole("heading", { name: "Page facts" })).toBeVisible();
  90  |   await page.screenshot({ path: `../.scratch/pgbuf-overlay-implementation/verification/lifecycle-expired-${browserName}.png`, fullPage: true });
  91  | });
  92  | 
  93  | test("producer restart while paused clears evidence and requires an explicit retry", async ({ page }) => {
  94  |   const { readFile } = await import("node:fs/promises");
  95  |   await page.clock.install();
  96  |   await page.goto("http://127.0.0.1:41741/page/0/10", { waitUntil: "commit" });
  97  |   const source = page.getByRole("region", { name: "CUBRID page-buffer observation" });
  98  |   const detail = page.getByRole("region", { name: "Selected-page buffer observation" });
  99  |   await source.getByRole("button", { name: "Enable observations" }).click();
  100 |   await expect(detail).toContainText("Observed resident");
  101 |   await page.getByRole("button", { name: "Pause", exact: true }).click();
  102 |   const pid = Number((await readFile("/tmp/volmap-browser-producer-41741.pid", "utf8")).trim());
  103 |   process.kill(pid, "SIGHUP");
  104 |   await page.clock.runFor(5000);
  105 |   await expect(source).toContainText("incarnation-changed");
  106 |   await expect(detail).not.toContainText("Observed resident");
  107 |   await page.getByRole("button", { name: "Resume", exact: true }).click();
  108 |   await expect(source).toContainText("Automatic retry stopped");
  109 |   await source.getByRole("button", { name: "Refresh selected-page observation" }).click();
  110 |   await expect(detail).toContainText("Observed resident");
  111 |   await expect(page.getByRole("heading", { name: "Page facts" })).toBeVisible();
  112 | });
  113 | 
  114 | test("transient browser retries back off and protocol incompatibility waits for explicit retry", async ({ page }) => {
  115 |   await page.addInitScript(() => { Math.random = () => 0.5; });
  116 |   await page.clock.install();
  117 |   let requests = 0;
  118 |   await page.route("**/runtime/page-buffer/observe", async (route) => {
  119 |     requests += 1;
  120 |     if (requests <= 2) await route.abort("failed");
  121 |     else if (requests === 3) await route.fulfill({ json: { schema: "unsupported" } });
  122 |     else await route.continue();
  123 |   });
  124 |   await page.goto("http://127.0.0.1:41741/page/0/10", { waitUntil: "commit" });
  125 |   const source = page.getByRole("region", { name: "CUBRID page-buffer observation" });
  126 |   await source.getByRole("button", { name: "Enable observations" }).click();
  127 |   await expect(source).toContainText("Observation unavailable");
  128 |   expect(requests).toBe(1);
  129 |   await page.clock.runFor(500);
  130 |   await expect.poll(() => requests).toBe(2);
  131 |   await expect(source).toContainText("Observation unavailable");
  132 |   await page.clock.runFor(1000);
  133 |   await expect(source).toContainText("Automatic retry stopped");
  134 |   expect(requests).toBe(3);
  135 |   await page.clock.runFor(10000);
  136 |   expect(requests).toBe(3);
  137 |   await source.getByRole("button", { name: "Refresh selected-page observation" }).click();
  138 |   await expect(page.getByRole("region", { name: "Selected-page buffer observation" })).toContainText("Observed resident");
  139 |   await expect(page.getByRole("heading", { name: "Page facts" })).toBeVisible();
  140 | });
  141 | 
  142 | test("Volume and Sector show bounded coverage, semantic rows and independent cadences across tabs", async ({ page, context, browserName }) => {
  143 |   await page.goto("http://127.0.0.1:41741/volume/0", { waitUntil: "commit" });
  144 |   const source = page.getByRole("region", { name: "CUBRID page-buffer observation" });
  145 |   const request = page.waitForRequest((request) => request.url().endsWith("/page-buffer/observe"));
  146 |   await source.getByRole("button", { name: "Enable observations" }).click();
  147 |   const visible = (await request).postDataJSON();
  148 |   expect(visible.cadence_ms).toBe(2000);
  149 |   expect(visible.pages.length).toBeGreaterThan(1);
  150 |   expect(visible.pages.length).toBeLessThanOrEqual(512);
  151 |   const coverage = page.getByRole("region", { name: "Visible-page buffer observations" });
  152 |   await expect(coverage).toContainText("Evaluated");
  153 |   await expect(coverage).toContainText("producer scan complete");
  154 |   await expect(coverage).toContainText("2000 ms interval");
  155 |   const selected = await context.newPage();
  156 |   await selected.goto("http://127.0.0.1:41741/page/0/10", { waitUntil: "commit" });
  157 |   await selected.getByRole("button", { name: "Enable observations" }).click();
  158 |   await expect(selected.getByRole("region", { name: "Selected-page buffer observation" })).toContainText("Observed resident");
```