# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: observations.spec.ts >> automatic polling, paused offers, hidden silence, resume and expiry preserve disk navigation
- Location: e2e/observations.spec.ts:38:1

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: page.goto: Test timeout of 30000ms exceeded.
Call log:
  - navigating to "http://127.0.0.1:41741/page/0/10", waiting until "commit"

```

# Page snapshot

```yaml
- generic [ref=e2]:
  - banner [ref=e3]:
    - strong [ref=e4]: VOLMAP
    - generic [ref=e5]: snapshot dc9688937a31 · revision 0
    - generic [ref=e6]:
      - generic [ref=e7]: "paused at gen 0 · newer: gen 0"
      - button "Resume" [active] [pressed] [ref=e8] [cursor=pointer]
    - button "About & licenses" [ref=e9] [cursor=pointer]
    - generic [ref=e10]: success-limited
  - main [ref=e11]:
    - complementary [ref=e12]:
      - region "CUBRID page-buffer observation" [ref=e13]:
        - heading "CUBRID page-buffer observation" [level=2] [ref=e14]
        - button "Disable observations" [pressed] [ref=e15] [cursor=pointer]
        - generic [ref=e16]:
          - text: Runtime color mode
          - combobox "Runtime color mode" [ref=e17]:
            - option "State marks" [selected]
            - option "LRU topology"
        - button "Refresh selected-page observation" [disabled] [ref=e18]
        - paragraph [ref=e19]: resident
        - paragraph [ref=e20]: "Observation source: active"
      - heading "Snapshot hierarchy" [level=2] [ref=e21]
      - button "volume 0 · 64 sectors" [ref=e23] [cursor=pointer]
    - generic [ref=e24]:
      - navigation "Inspection hierarchy" [ref=e25]:
        - button "← Back" [ref=e26] [cursor=pointer]
        - button "Volume 0" [ref=e28] [cursor=pointer]
        - generic [ref=e29]:
          - text: ›
          - button "Sector 0" [ref=e30] [cursor=pointer]
        - generic [ref=e31]: ›Page 10
      - generic [ref=e32]:
        - generic [ref=e34]:
          - heading "Page 10" [level=1] [ref=e35]
          - paragraph [ref=e36]: heap · detailed structural view
        - generic [ref=e37]:
          - generic [ref=e38]:
            - heading "Page facts" [level=2] [ref=e39]
            - generic [ref=e40]:
              - generic [ref=e41]:
                - term [ref=e42]: Identity
                - definition [ref=e43]: page:0:10
              - generic [ref=e44]:
                - term [ref=e45]: Sector
                - definition [ref=e46]: "0"
              - generic [ref=e47]:
                - term [ref=e48]: Physical type
                - definition [ref=e49]: heap
              - generic [ref=e50]:
                - term [ref=e51]: Allocation
                - definition [ref=e52]: reserved-unallocated
              - generic [ref=e53]:
                - term [ref=e54]: File
                - definition [ref=e55]: none
              - generic [ref=e56]:
                - term [ref=e57]: File role
                - definition [ref=e58]: none
              - generic [ref=e59]:
                - term [ref=e60]: Class OID
                - definition [ref=e61]: none
              - generic [ref=e62]:
                - term [ref=e63]: Class/table
                - definition [ref=e64]: none
              - generic [ref=e65]:
                - term [ref=e66]: Availability
                - definition [ref=e67]: available
              - generic [ref=e68]:
                - term [ref=e69]: Detail support
                - definition [ref=e70]: semantic
              - generic [ref=e71]:
                - term [ref=e72]: Deep state
                - definition [ref=e73]: not-enriched
              - generic [ref=e74]:
                - term [ref=e75]: TDE
                - definition [ref=e76]: not-encrypted
            - paragraph [ref=e77]: evidence page:0:10 · structural ranges only · bytes withheld
          - region "Selected-page buffer observation" [ref=e78]:
            - heading "Buffer observation" [level=2] [ref=e79]
            - paragraph [ref=e80]: ◉ Observed resident
            - paragraph [ref=e81]: VPID 0:10 · observed-resident
            - generic [ref=e82]:
              - paragraph [ref=e83]: "Shared lists: 2 · Private lists: 3. Indices are incarnation-local."
              - group [ref=e84]:
                - generic "Observed per-list counts in this batch only" [ref=e85] [cursor=pointer]
            - paragraph [ref=e86]: Membership is one sampled tuple. none means no list; invalid means unclassified membership; null means no applicable index. Missing fields remain unknown. Indices identify lists only within this server incarnation.
            - paragraph [ref=e87]: "Conservative age: 29 s · stale (500 ms interval) · paused"
            - paragraph [ref=e88]: Evaluated 1 / requested 1; producer scan complete.
            - generic [ref=e89]:
              - generic [ref=e90]:
                - term [ref=e91]: page kind
                - definition [ref=e92]: oos
              - generic [ref=e93]:
                - term [ref=e94]: latch mode
                - definition [ref=e95]: read
              - generic [ref=e96]:
                - term [ref=e97]: waiter present
                - definition [ref=e98]: "true"
              - generic [ref=e99]:
                - term [ref=e100]: fix count
                - definition [ref=e101]: "2"
              - generic [ref=e102]:
                - term [ref=e103]: dirty
                - definition [ref=e104]: "true"
              - generic [ref=e105]:
                - term [ref=e106]: flushing
                - definition [ref=e107]: "false"
              - generic [ref=e108]:
                - term [ref=e109]: async flush requested
                - definition [ref=e110]: "false"
              - generic [ref=e111]:
                - term [ref=e112]: to vacuum
                - definition [ref=e113]: "true"
              - generic [ref=e114]:
                - term [ref=e115]: lru zone
                - definition [ref=e116]: lru2
              - generic [ref=e117]:
                - term [ref=e118]: lru list kind
                - definition [ref=e119]: private
              - generic [ref=e120]:
                - term [ref=e121]: lru list index
                - definition [ref=e122]: "1"
              - generic [ref=e123]:
                - term [ref=e124]: page lsa
                - definition [ref=e125]: 9223372036854775807:12
              - generic [ref=e126]:
                - term [ref=e127]: oldest unflush lsa
                - definition [ref=e128]: none / not applicable
            - group [ref=e129]:
              - generic "Capture identity and limitations" [ref=e130] [cursor=pointer]
          - generic [ref=e131]:
            - heading "Slotted-page distribution" [level=2] [ref=e132]
            - paragraph [ref=e133]: No validated slot directory is available for this page.
```

# Test source

```ts
  1   | import { expect, test } from "@playwright/test";
  2   | 
  3   | // Firefox can keep document readiness pending alongside the live watch.
  4   | // Wait for navigation commit, then assert rendered controls and observations.
  5   | 
  6   | // Port 41741 uses producer-fixture.py, not an actual CUBRID server.
  7   | test("selected-page observation uses a scripted socket producer, real HTTP and non-color detail", async ({ page, browserName }) => {
  8   |   const errors: string[] = [];
  9   |   page.on("pageerror", (error) => errors.push(error.message));
  10  |   await page.goto("http://127.0.0.1:41741/page/0/10", { waitUntil: "commit" });
  11  |   await expect(page.getByRole("heading", { name: "Page facts" })).toBeVisible();
  12  |   const source = page.getByRole("region", { name: "CUBRID page-buffer observation" });
  13  |   await source.getByRole("button", { name: "Enable observations" }).click();
  14  |   const response = page.waitForResponse((response) => response.url().endsWith("/runtime/page-buffer/observe"));
  15  |   await source.getByRole("button", { name: "Refresh selected-page observation" }).click();
  16  |   const observed = await response;
  17  |   expect(observed.status()).toBe(200);
  18  |   expect(observed.headers()["cache-control"]).toBe("no-store");
  19  |   const detail = page.getByRole("region", { name: "Selected-page buffer observation" });
  20  |   await expect(detail).toContainText("◉ Observed resident");
  21  |   await expect(detail).toContainText("VPID 0:10");
  22  |   await expect(source).toContainText("Observation source: active");
  23  |   await expect(detail).toContainText("latch mode");
  24  |   await expect(detail).toContainText("oldest unflush lsa");
  25  |   await detail.getByText("Capture identity and limitations", { exact: true }).click();
  26  |   await expect(detail).toContainText("records and scans are not atomic");
  27  |   await expect(page.getByRole("heading", { name: "Page facts" })).toBeVisible();
  28  |   await page.getByRole("button", { name: "Pause", exact: true }).click();
  29  |   await expect(source.getByRole("button", { name: "Refresh selected-page observation" })).toBeDisabled();
  30  |   await expect(detail).toContainText("paused");
  31  |   await page.evaluate(() => window.scrollTo(0, 0));
  32  |   await page.screenshot({ path: `../.scratch/pgbuf-overlay-implementation/verification/selected-observation-${browserName}.png`, fullPage: true });
  33  |   await source.getByRole("button", { name: "Disable observations" }).click();
  34  |   await expect(detail).toHaveCount(0);
  35  |   expect(errors).toEqual([]);
  36  | });
  37  | 
  38  | test("automatic polling, paused offers, hidden silence, resume and expiry preserve disk navigation", async ({ page, context, browserName }) => {
  39  |   await page.clock.install();
  40  |   await page.goto("http://127.0.0.1:41741/page/0/10", { waitUntil: "commit" });
  41  |   const source = page.getByRole("region", { name: "CUBRID page-buffer observation" });
  42  |   const detail = page.getByRole("region", { name: "Selected-page buffer observation" });
  43  |   let observations = 0;
  44  |   let metadata = 0;
  45  |   page.on("request", (request) => {
  46  |     if (request.url().endsWith("/page-buffer/observe")) observations += 1;
  47  |     if (request.url().endsWith("/runtime/capabilities")) metadata += 1;
  48  |   });
  49  |   await source.getByRole("button", { name: "Enable observations" }).click();
  50  |   await expect(detail).toContainText("Observed resident");
  51  |   const first = observations;
  52  |   await page.clock.runFor(500);
  53  |   await expect.poll(() => observations).toBeGreaterThan(first);
  54  |   await expect(source.getByRole("button", { name: "Refresh selected-page observation" })).toBeEnabled();
  55  |   await page.getByRole("button", { name: "Pause", exact: true }).click();
  56  |   const pausedRequests = observations;
  57  |   const beforeMetadata = metadata;
  58  |   const other = await context.newPage();
> 59  |   await other.goto("http://127.0.0.1:41741/page/0/10", { waitUntil: "commit" });
      |               ^ Error: page.goto: Test timeout of 30000ms exceeded.
  60  |   const otherSource = other.getByRole("region", { name: "CUBRID page-buffer observation" });
  61  |   await otherSource.getByRole("button", { name: "Enable observations" }).click();
  62  |   await expect(other.getByRole("region", { name: "Selected-page buffer observation" })).toContainText("Observed resident");
  63  |   await other.waitForResponse((response) => response.url().endsWith("/page-buffer/observe"));
  64  |   await page.clock.runFor(5000);
  65  |   await expect(source).toContainText("Newer observation available");
  66  |   expect(observations).toBe(pausedRequests);
  67  |   expect(metadata).toBeGreaterThan(beforeMetadata);
  68  |   await other.close();
  69  | 
  70  |   await page.evaluate(() => {
  71  |     Object.defineProperty(document, "visibilityState", { configurable: true, get: () => "hidden" });
  72  |     document.dispatchEvent(new Event("visibilitychange"));
  73  |   });
  74  |   const hiddenMetadata = metadata;
  75  |   await page.clock.runFor(10000);
  76  |   expect(metadata).toBe(hiddenMetadata);
  77  |   expect(observations).toBe(pausedRequests);
  78  |   await page.evaluate(() => {
  79  |     Object.defineProperty(document, "visibilityState", { configurable: true, get: () => "visible" });
  80  |     document.dispatchEvent(new Event("visibilitychange"));
  81  |   });
  82  |   const resumedRequest = page.waitForRequest((request) => request.url().endsWith("/page-buffer/observe"));
  83  |   await page.getByRole("button", { name: "Resume", exact: true }).click();
  84  |   expect((await resumedRequest).postDataJSON().after_request).toBe(true);
  85  |   await expect(detail).toContainText("Observed resident");
  86  |   await expect(source.getByRole("button", { name: "Refresh selected-page observation" })).toBeEnabled();
  87  |   await page.getByRole("button", { name: "Pause", exact: true }).click();
  88  |   await page.clock.runFor(31000);
  89  |   await expect(detail).toContainText("Observation expired");
  90  |   await expect(page.getByRole("heading", { name: "Page facts" })).toBeVisible();
  91  |   await page.screenshot({ path: `../.scratch/pgbuf-overlay-implementation/verification/lifecycle-expired-${browserName}.png`, fullPage: true });
  92  | });
  93  | 
  94  | test("producer restart while paused clears evidence and requires an explicit retry", async ({ page }) => {
  95  |   const { readFile } = await import("node:fs/promises");
  96  |   await page.clock.install();
  97  |   await page.goto("http://127.0.0.1:41741/page/0/10", { waitUntil: "commit" });
  98  |   const source = page.getByRole("region", { name: "CUBRID page-buffer observation" });
  99  |   const detail = page.getByRole("region", { name: "Selected-page buffer observation" });
  100 |   await source.getByRole("button", { name: "Enable observations" }).click();
  101 |   await expect(detail).toContainText("Observed resident");
  102 |   await page.getByRole("button", { name: "Pause", exact: true }).click();
  103 |   const pid = Number((await readFile("/tmp/volmap-browser-producer-41741.pid", "utf8")).trim());
  104 |   process.kill(pid, "SIGHUP");
  105 |   await page.clock.runFor(5000);
  106 |   await expect(source).toContainText("incarnation-changed");
  107 |   await expect(detail).not.toContainText("Observed resident");
  108 |   await page.getByRole("button", { name: "Resume", exact: true }).click();
  109 |   await expect(source).toContainText("Automatic retry stopped");
  110 |   await source.getByRole("button", { name: "Refresh selected-page observation" }).click();
  111 |   await expect(detail).toContainText("Observed resident");
  112 |   await expect(page.getByRole("heading", { name: "Page facts" })).toBeVisible();
  113 | });
  114 | 
  115 | test("transient browser retries back off and protocol incompatibility waits for explicit retry", async ({ page }) => {
  116 |   await page.addInitScript(() => { Math.random = () => 0.5; });
  117 |   await page.clock.install();
  118 |   let requests = 0;
  119 |   await page.route("**/runtime/page-buffer/observe", async (route) => {
  120 |     requests += 1;
  121 |     if (requests <= 2) await route.abort("failed");
  122 |     else if (requests === 3) await route.fulfill({ json: { schema: "unsupported" } });
  123 |     else await route.continue();
  124 |   });
  125 |   await page.goto("http://127.0.0.1:41741/page/0/10", { waitUntil: "commit" });
  126 |   const source = page.getByRole("region", { name: "CUBRID page-buffer observation" });
  127 |   await source.getByRole("button", { name: "Enable observations" }).click();
  128 |   await expect(source).toContainText("Observation unavailable");
  129 |   expect(requests).toBe(1);
  130 |   await page.clock.runFor(500);
  131 |   await expect.poll(() => requests).toBe(2);
  132 |   await expect(source).toContainText("Observation unavailable");
  133 |   await page.clock.runFor(1000);
  134 |   await expect(source).toContainText("Automatic retry stopped");
  135 |   expect(requests).toBe(3);
  136 |   await page.clock.runFor(10000);
  137 |   expect(requests).toBe(3);
  138 |   await source.getByRole("button", { name: "Refresh selected-page observation" }).click();
  139 |   await expect(page.getByRole("region", { name: "Selected-page buffer observation" })).toContainText("Observed resident");
  140 |   await expect(page.getByRole("heading", { name: "Page facts" })).toBeVisible();
  141 | });
  142 | 
  143 | test("Volume and Sector show bounded coverage, semantic rows and independent cadences across tabs", async ({ page, context, browserName }) => {
  144 |   await page.goto("http://127.0.0.1:41741/volume/0", { waitUntil: "commit" });
  145 |   const source = page.getByRole("region", { name: "CUBRID page-buffer observation" });
  146 |   const request = page.waitForRequest((request) => request.url().endsWith("/page-buffer/observe"));
  147 |   await source.getByRole("button", { name: "Enable observations" }).click();
  148 |   const visible = (await request).postDataJSON();
  149 |   expect(visible.cadence_ms).toBe(2000);
  150 |   expect(visible.pages.length).toBeGreaterThan(1);
  151 |   expect(visible.pages.length).toBeLessThanOrEqual(512);
  152 |   const coverage = page.getByRole("region", { name: "Visible-page buffer observations" });
  153 |   await expect(coverage).toContainText("Evaluated");
  154 |   await expect(coverage).toContainText("producer scan complete");
  155 |   await expect(coverage).toContainText("2000 ms interval");
  156 |   const selected = await context.newPage();
  157 |   await selected.goto("http://127.0.0.1:41741/page/0/10", { waitUntil: "commit" });
  158 |   await selected.getByRole("button", { name: "Enable observations" }).click();
  159 |   await expect(selected.getByRole("region", { name: "Selected-page buffer observation" })).toContainText("Observed resident");
```