import { defineConfig } from "@playwright/test";
import base from "./playwright.density.config";
export default defineConfig({ ...base, testMatch: "**/memory-probe.spec.ts", outputDir: "../.scratch/pgbuf-overlay-implementation/verification/06-allocation-profile/probe-results", projects: base.projects?.filter((project) => project.name === "chromium") });
