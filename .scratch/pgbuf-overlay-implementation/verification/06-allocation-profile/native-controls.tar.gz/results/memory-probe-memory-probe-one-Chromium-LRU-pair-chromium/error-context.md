# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: memory-probe.spec.ts >> memory probe: one Chromium LRU pair
- Location: e2e/memory-probe.spec.ts:45:1

# Error details

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 33554432
Received:    45744128
```

# Test source

```ts
  77  |         while (sampling) {
  78  |           samples.push({ elapsedMs: performance.now() - started, rss: await rssTree(pid) });
  79  |           await new Promise((resolve) => setTimeout(resolve, 50));
  80  |         }
  81  |       })().catch((error: unknown) => { samplingError = error; });
  82  |       try {
  83  |         page = await browser.newPage({ viewport });
  84  |         const cdp = await page.context().newCDPSession(page);
  85  |         await cdp.send("Performance.enable");
  86  |         phaseProbe = async (phase) => { const processes: object[] = []; await rssTree(pid, processes); phases.push({ processes, phase, elapsedMs: performance.now() - started, rss: await rssTree(pid), performance: await cdp.send("Performance.getMetrics"), dom: await cdp.send("Memory.getDOMCounters") }); };
  87  |         await page.goto("http://127.0.0.1:41742/volume/0", { waitUntil: "commit" });
  88  |         const cells = page.locator("[data-observation-page]");
  89  |         // Exercise real collection pagination; never inject a synthetic model.
  90  |         await loadVolumeCells(page, 12288);
  91  |         await page.evaluate(() => window.scrollTo(0, 0));
  92  |         rendered = await cells.evaluateAll((elements) => ({
  93  |           count: elements.filter((element) => element.getClientRects().length > 0).length,
  94  |           inViewport: elements.filter((element) => {
  95  |             const box = element.getBoundingClientRect();
  96  |             return box.top >= 0 && box.bottom <= innerHeight && box.left >= 0 && box.right <= innerWidth;
  97  |           }).length,
  98  |         }));
  99  |         expect(rendered.count).toBe(12288);
  100 |         await phaseProbe("loaded");
  101 |         await cdp.send("HeapProfiler.startSampling", { samplingInterval: 16384, includeObjectsCollectedByMajorGC: true, includeObjectsCollectedByMinorGC: true });
  102 |         if (enabled) {
  103 |           await page.evaluate(() => { const button = [...document.querySelectorAll("button")].find((element) => element.textContent === "Enable observations"); if (!button) throw new Error("Missing enable button"); button.click(); });
  104 |           await page.waitForFunction(() => document.querySelector("[aria-label=\"Visible-page buffer observations\"]")?.textContent?.includes("Evaluated 512 / requested 512"));
  105 |           await page.evaluate((mode) => { const select = document.querySelector<HTMLSelectElement>(".runtime-mode select"); if (!select) throw new Error("Missing color mode"); select.value = mode; select.dispatchEvent(new Event("change", { bubbles: true })); }, mode);
  106 |         }
  107 |         await phaseProbe("configured");
  108 |         await writeFile(testInfo.outputPath(`alloc-${enabled}-setup.json`), JSON.stringify(await cdp.send("HeapProfiler.stopSampling")));
  109 |         await cdp.send("HeapProfiler.startSampling", { samplingInterval: 16384, includeObjectsCollectedByMajorGC: true, includeObjectsCollectedByMinorGC: true });
  110 |         // Same keyboard focus changes, viewport and DOM workload in both arms.
  111 |         // The second animation frame gives a conservative post-paint bound.
  112 |         await page.evaluate(() => {
  113 |           const samples: number[] = [];
  114 |           Object.assign(window, { densityInputSamples: samples });
  115 |           document.addEventListener("keydown", (event) => {
  116 |             if (event.key !== "Tab") return;
  117 |             const start = event.timeStamp;
  118 |             if (!Number.isFinite(start) || start < 0 || start > performance.now()) throw new Error("Invalid input timestamp clock");
  119 |             const before = document.activeElement;
  120 |             requestAnimationFrame(() => requestAnimationFrame(() => {
  121 |               const active = document.activeElement;
  122 |               if (active === before || !(active instanceof HTMLElement)) return;
  123 |               const rect = active.getBoundingClientRect();
  124 |               if (rect.width > 0 && rect.height > 0 && rect.bottom > 54 && rect.top < innerHeight && rect.right > 0 && rect.left < innerWidth && getComputedStyle(active).outlineStyle !== "none") samples.push(performance.now() - start);
  125 |             }));
  126 |           }, true);
  127 |         });
  128 |         await page.evaluate(() => { const sector = document.getElementById("sector-0"); if (!sector) throw new Error("Missing sector"); sector.focus(); });
  129 |         for (let index = 0; index < 1; index += 1) {
  130 |           await page.keyboard.press("Tab");
  131 |           await page.evaluate(() => new Promise<void>((resolve) => requestAnimationFrame(() => requestAnimationFrame(() => resolve()))));
  132 |         }
  133 |         await phaseProbe("interacted");
  134 |         await writeFile(testInfo.outputPath(`alloc-${enabled}-interaction.json`), JSON.stringify(await cdp.send("HeapProfiler.stopSampling")));
  135 |         interaction = await page.evaluate(() => Reflect.get(window, "densityInputSamples") as number[]);
  136 |         expect(interaction).toHaveLength(1);
  137 |         const sorted = [...interaction].sort((a, b) => a - b);
  138 |         const p95 = sorted[Math.ceil(sorted.length * 0.95) - 1]!;
  139 |         if (enabled) p95PerArm.push(p95);
  140 |         sampling = false;
  141 |         await sampler;
  142 |         const peak = Math.max(...samples.map((sample) => sample.rss));
  143 |         peaks[enabled ? "enabled" : "disabled"]!.push(peak);
  144 |         runs.push({ pair, mode, enabled, p95Ms: p95, browserVersion: browser.version(), rendered, viewport, interactionMs: interaction, rssSamples: samples, peakRssBytes: peak });
  145 |       } catch (error) {
  146 |         armError = error;
  147 |         throw error;
  148 |       } finally {
  149 |         sampling = false;
  150 |         await sampler;
  151 |         if (page && !page.isClosed()) {
  152 |           try { interaction = await page.evaluate(() => Reflect.get(window, "densityInputSamples") as number[] ?? []); }
  153 |           catch (error) { armError ??= error; }
  154 |         }
  155 |         const raw = testInfo.outputPath(`rss-${browserName}-${pair}-${enabled ? "enabled" : "disabled"}.json`);
  156 |         await writeFile(raw, JSON.stringify({ ...provenance, browserVersion: browser.version(), pair, mode, enabled, viewport, rendered, interaction, phases, armError: armError === undefined ? null : String(armError), samples, samplingError: samplingError === undefined ? null : String(samplingError), completedRuns: runs }, null, 2));
  157 |         await testInfo.attach("density-arm-raw", { path: raw, contentType: "application/json" });
  158 |         await browser.close();
  159 |         await server.close();
  160 |       }
  161 |       if (samplingError !== undefined) throw samplingError;
  162 |       if (armError !== undefined) throw armError;
  163 |     }
  164 |   }
  165 |   const p95 = Math.max(...p95PerArm);
  166 |   const increments = peaks.enabled!.map((peak, index) => peak - peaks.disabled![index]!);
  167 |   const report = {
  168 |     ...provenance,
  169 |     method: "One dedicated browser tree/tab per arm; 50ms sampled summed process RSS from launch through identical 40 Tab interactions. Two order-alternated pairs (state marks, LRU); worst per-arm p95 reported, never averaged across cases. Input keydown to visible outlined focus, bounded by second animation frame. Local diagnostic; manual and dedicated-host qualification remain separate.",
  170 |     p95Ms: p95, incrementalPeakRssBytes: increments, runs,
  171 |     timingPass: p95 <= 100, memoryPass: increments.every((increment) => increment <= 32 * 1024 * 1024),
  172 |   };
  173 |   const output = testInfo.outputPath(`density-${browserName}.json`);
  174 |   await writeFile(output, JSON.stringify(report, null, 2));
  175 |   await testInfo.attach("density-raw", { path: output, contentType: "application/json" });
  176 |   expect(p95).toBeLessThanOrEqual(100);
> 177 |   for (const increment of increments) expect(increment).toBeLessThanOrEqual(32 * 1024 * 1024);
      |                                                         ^ Error: expect(received).toBeLessThanOrEqual(expected)
  178 | });
  179 | 
```