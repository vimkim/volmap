# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: memory-probe.spec.ts >> memory probe: one Chromium LRU pair
- Location: e2e/memory-probe.spec.ts:40:1

# Error details

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 33554432
Received:    59658240
```

# Test source

```ts
  72  |         while (sampling) {
  73  |           samples.push({ elapsedMs: performance.now() - started, rss: await rssTree(pid) });
  74  |           await new Promise((resolve) => setTimeout(resolve, 50));
  75  |         }
  76  |       })().catch((error: unknown) => { samplingError = error; });
  77  |       try {
  78  |         page = await browser.newPage({ viewport });
  79  |         const cdp = await page.context().newCDPSession(page);
  80  |         await cdp.send("Performance.enable");
  81  |         phaseProbe = async (phase) => { phases.push({ phase, elapsedMs: performance.now() - started, rss: await rssTree(pid), performance: await cdp.send("Performance.getMetrics"), dom: await cdp.send("Memory.getDOMCounters") }); };
  82  |         await page.goto("http://127.0.0.1:41742/volume/0", { waitUntil: "commit" });
  83  |         const cells = page.locator("[data-observation-page]");
  84  |         // Exercise real collection pagination; never inject a synthetic model.
  85  |         await loadVolumeCells(page, 12288);
  86  |         await page.evaluate(() => window.scrollTo(0, 0));
  87  |         rendered = await cells.evaluateAll((elements) => ({
  88  |           count: elements.filter((element) => element.getClientRects().length > 0).length,
  89  |           inViewport: elements.filter((element) => {
  90  |             const box = element.getBoundingClientRect();
  91  |             return box.top >= 0 && box.bottom <= innerHeight && box.left >= 0 && box.right <= innerWidth;
  92  |           }).length,
  93  |         }));
  94  |         expect(rendered.count).toBe(12288);
  95  |         await phaseProbe("loaded");
  96  |         await cdp.send("HeapProfiler.startSampling", { samplingInterval: 16384, includeObjectsCollectedByMajorGC: true, includeObjectsCollectedByMinorGC: true });
  97  |         if (enabled) {
  98  |           await page.locator("button").filter({ hasText: /^Enable observations$/ }).click();
  99  |           await expect(page.locator("[aria-label=\"Visible-page buffer observations\"]")).toContainText("Evaluated 512 / requested 512");
  100 |           await page.locator(".runtime-mode select").selectOption(mode);
  101 |         }
  102 |         await phaseProbe("configured");
  103 |         await writeFile(testInfo.outputPath(`alloc-${enabled}-setup.json`), JSON.stringify(await cdp.send("HeapProfiler.stopSampling")));
  104 |         await cdp.send("HeapProfiler.startSampling", { samplingInterval: 16384, includeObjectsCollectedByMajorGC: true, includeObjectsCollectedByMinorGC: true });
  105 |         // Same keyboard focus changes, viewport and DOM workload in both arms.
  106 |         // The second animation frame gives a conservative post-paint bound.
  107 |         await page.evaluate(() => {
  108 |           const samples: number[] = [];
  109 |           Object.assign(window, { densityInputSamples: samples });
  110 |           document.addEventListener("keydown", (event) => {
  111 |             if (event.key !== "Tab") return;
  112 |             const start = event.timeStamp;
  113 |             if (!Number.isFinite(start) || start < 0 || start > performance.now()) throw new Error("Invalid input timestamp clock");
  114 |             const before = document.activeElement;
  115 |             requestAnimationFrame(() => requestAnimationFrame(() => {
  116 |               const active = document.activeElement;
  117 |               if (active === before || !(active instanceof HTMLElement)) return;
  118 |               const rect = active.getBoundingClientRect();
  119 |               if (rect.width > 0 && rect.height > 0 && rect.bottom > 54 && rect.top < innerHeight && rect.right > 0 && rect.left < innerWidth && getComputedStyle(active).outlineStyle !== "none") samples.push(performance.now() - start);
  120 |             }));
  121 |           }, true);
  122 |         });
  123 |         await page.locator("#sector-0").focus();
  124 |         for (let index = 0; index < 1; index += 1) {
  125 |           await page.keyboard.press("Tab");
  126 |           await page.evaluate(() => new Promise<void>((resolve) => requestAnimationFrame(() => requestAnimationFrame(() => resolve()))));
  127 |         }
  128 |         await phaseProbe("interacted");
  129 |         await writeFile(testInfo.outputPath(`alloc-${enabled}-interaction.json`), JSON.stringify(await cdp.send("HeapProfiler.stopSampling")));
  130 |         interaction = await page.evaluate(() => Reflect.get(window, "densityInputSamples") as number[]);
  131 |         expect(interaction).toHaveLength(1);
  132 |         const sorted = [...interaction].sort((a, b) => a - b);
  133 |         const p95 = sorted[Math.ceil(sorted.length * 0.95) - 1]!;
  134 |         if (enabled) p95PerArm.push(p95);
  135 |         sampling = false;
  136 |         await sampler;
  137 |         const peak = Math.max(...samples.map((sample) => sample.rss));
  138 |         peaks[enabled ? "enabled" : "disabled"]!.push(peak);
  139 |         runs.push({ pair, mode, enabled, p95Ms: p95, browserVersion: browser.version(), rendered, viewport, interactionMs: interaction, rssSamples: samples, peakRssBytes: peak });
  140 |       } catch (error) {
  141 |         armError = error;
  142 |         throw error;
  143 |       } finally {
  144 |         sampling = false;
  145 |         await sampler;
  146 |         if (page && !page.isClosed()) {
  147 |           try { interaction = await page.evaluate(() => Reflect.get(window, "densityInputSamples") as number[] ?? []); }
  148 |           catch (error) { armError ??= error; }
  149 |         }
  150 |         const raw = testInfo.outputPath(`rss-${browserName}-${pair}-${enabled ? "enabled" : "disabled"}.json`);
  151 |         await writeFile(raw, JSON.stringify({ ...provenance, browserVersion: browser.version(), pair, mode, enabled, viewport, rendered, interaction, phases, armError: armError === undefined ? null : String(armError), samples, samplingError: samplingError === undefined ? null : String(samplingError), completedRuns: runs }, null, 2));
  152 |         await testInfo.attach("density-arm-raw", { path: raw, contentType: "application/json" });
  153 |         await browser.close();
  154 |         await server.close();
  155 |       }
  156 |       if (samplingError !== undefined) throw samplingError;
  157 |       if (armError !== undefined) throw armError;
  158 |     }
  159 |   }
  160 |   const p95 = Math.max(...p95PerArm);
  161 |   const increments = peaks.enabled!.map((peak, index) => peak - peaks.disabled![index]!);
  162 |   const report = {
  163 |     ...provenance,
  164 |     method: "One dedicated browser tree/tab per arm; 50ms sampled summed process RSS from launch through identical 40 Tab interactions. Two order-alternated pairs (state marks, LRU); worst per-arm p95 reported, never averaged across cases. Input keydown to visible outlined focus, bounded by second animation frame. Local diagnostic; manual and dedicated-host qualification remain separate.",
  165 |     p95Ms: p95, incrementalPeakRssBytes: increments, runs,
  166 |     timingPass: p95 <= 100, memoryPass: increments.every((increment) => increment <= 32 * 1024 * 1024),
  167 |   };
  168 |   const output = testInfo.outputPath(`density-${browserName}.json`);
  169 |   await writeFile(output, JSON.stringify(report, null, 2));
  170 |   await testInfo.attach("density-raw", { path: output, contentType: "application/json" });
  171 |   expect(p95).toBeLessThanOrEqual(100);
> 172 |   for (const increment of increments) expect(increment).toBeLessThanOrEqual(32 * 1024 * 1024);
      |                                                         ^ Error: expect(received).toBeLessThanOrEqual(expected)
  173 | });
  174 | 
```