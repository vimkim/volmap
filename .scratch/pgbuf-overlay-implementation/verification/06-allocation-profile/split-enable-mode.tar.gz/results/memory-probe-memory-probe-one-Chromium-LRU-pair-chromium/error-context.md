# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: memory-probe.spec.ts >> memory probe: one Chromium LRU pair
- Location: e2e/memory-probe.spec.ts:45:1

# Error details

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 33554432
Received:    58208256
```

# Test source

```ts
  80  |         }
  81  |       })().catch((error: unknown) => { samplingError = error; });
  82  |       try {
  83  |         page = await browser.newPage({ viewport });
  84  |         const cdp = await page.context().newCDPSession(page);
  85  |         await cdp.send("Performance.enable");
  86  |         phaseProbe = async (phase) => { const processes: object[] = []; await rssTree(pid, processes); phases.push({ processes, phase, elapsedMs: performance.now() - started, rss: await rssTree(pid), performance: await cdp.send("Performance.getMetrics"), dom: await cdp.send("Memory.getDOMCounters") }); };
  87  |         await page.goto("http://127.0.0.1:41742/volume/0", { waitUntil: "commit" });
  88  |         const cells = page.locator("[data-observation-page]");
  89  |         // Exercise real collection pagination; never inject a synthetic model.
  90  |         await loadVolumeCells(page, 12288);
  91  |         await page.evaluate(() => window.scrollTo(0, 0));
  92  |         rendered = await cells.evaluateAll((elements) => ({
  93  |           count: elements.filter((element) => element.getClientRects().length > 0).length,
  94  |           inViewport: elements.filter((element) => {
  95  |             const box = element.getBoundingClientRect();
  96  |             return box.top >= 0 && box.bottom <= innerHeight && box.left >= 0 && box.right <= innerWidth;
  97  |           }).length,
  98  |         }));
  99  |         expect(rendered.count).toBe(12288);
  100 |         await phaseProbe("loaded");
  101 |         await cdp.send("HeapProfiler.startSampling", { samplingInterval: 16384, includeObjectsCollectedByMajorGC: true, includeObjectsCollectedByMinorGC: true });
  102 |         if (enabled) {
  103 |           await page.evaluate(() => { const button = [...document.querySelectorAll("button")].find((element) => element.textContent === "Enable observations"); if (!button) throw new Error("Missing enable button"); button.click(); });
  104 |           await page.waitForFunction(() => document.querySelector("[aria-label=\"Visible-page buffer observations\"]")?.textContent?.includes("Evaluated 512 / requested 512"));
  105 |           await phaseProbe("enabled-before-mode");
  106 |           await writeFile(testInfo.outputPath(`alloc-${enabled}-enable.json`), JSON.stringify(await cdp.send("HeapProfiler.stopSampling")));
  107 |           await cdp.send("HeapProfiler.startSampling", { samplingInterval: 16384, includeObjectsCollectedByMajorGC: true, includeObjectsCollectedByMinorGC: true });
  108 |           await page.evaluate((mode) => { const select = document.querySelector<HTMLSelectElement>(".runtime-mode select"); if (!select) throw new Error("Missing color mode"); select.value = mode; select.dispatchEvent(new Event("change", { bubbles: true })); }, mode);
  109 |         }
  110 |         await phaseProbe("configured");
  111 |         await writeFile(testInfo.outputPath(`alloc-${enabled}-setup.json`), JSON.stringify(await cdp.send("HeapProfiler.stopSampling")));
  112 |         await cdp.send("HeapProfiler.startSampling", { samplingInterval: 16384, includeObjectsCollectedByMajorGC: true, includeObjectsCollectedByMinorGC: true });
  113 |         // Same keyboard focus changes, viewport and DOM workload in both arms.
  114 |         // The second animation frame gives a conservative post-paint bound.
  115 |         await page.evaluate(() => {
  116 |           const samples: number[] = [];
  117 |           Object.assign(window, { densityInputSamples: samples });
  118 |           document.addEventListener("keydown", (event) => {
  119 |             if (event.key !== "Tab") return;
  120 |             const start = event.timeStamp;
  121 |             if (!Number.isFinite(start) || start < 0 || start > performance.now()) throw new Error("Invalid input timestamp clock");
  122 |             const before = document.activeElement;
  123 |             requestAnimationFrame(() => requestAnimationFrame(() => {
  124 |               const active = document.activeElement;
  125 |               if (active === before || !(active instanceof HTMLElement)) return;
  126 |               const rect = active.getBoundingClientRect();
  127 |               if (rect.width > 0 && rect.height > 0 && rect.bottom > 54 && rect.top < innerHeight && rect.right > 0 && rect.left < innerWidth && getComputedStyle(active).outlineStyle !== "none") samples.push(performance.now() - start);
  128 |             }));
  129 |           }, true);
  130 |         });
  131 |         await page.evaluate(() => { const sector = document.getElementById("sector-0"); if (!sector) throw new Error("Missing sector"); sector.focus(); });
  132 |         for (let index = 0; index < 1; index += 1) {
  133 |           await page.keyboard.press("Tab");
  134 |           await page.evaluate(() => new Promise<void>((resolve) => requestAnimationFrame(() => requestAnimationFrame(() => resolve()))));
  135 |         }
  136 |         await phaseProbe("interacted");
  137 |         await writeFile(testInfo.outputPath(`alloc-${enabled}-interaction.json`), JSON.stringify(await cdp.send("HeapProfiler.stopSampling")));
  138 |         interaction = await page.evaluate(() => Reflect.get(window, "densityInputSamples") as number[]);
  139 |         expect(interaction).toHaveLength(1);
  140 |         const sorted = [...interaction].sort((a, b) => a - b);
  141 |         const p95 = sorted[Math.ceil(sorted.length * 0.95) - 1]!;
  142 |         if (enabled) p95PerArm.push(p95);
  143 |         sampling = false;
  144 |         await sampler;
  145 |         const peak = Math.max(...samples.map((sample) => sample.rss));
  146 |         peaks[enabled ? "enabled" : "disabled"]!.push(peak);
  147 |         runs.push({ pair, mode, enabled, p95Ms: p95, browserVersion: browser.version(), rendered, viewport, interactionMs: interaction, rssSamples: samples, peakRssBytes: peak });
  148 |       } catch (error) {
  149 |         armError = error;
  150 |         throw error;
  151 |       } finally {
  152 |         sampling = false;
  153 |         await sampler;
  154 |         if (page && !page.isClosed()) {
  155 |           try { interaction = await page.evaluate(() => Reflect.get(window, "densityInputSamples") as number[] ?? []); }
  156 |           catch (error) { armError ??= error; }
  157 |         }
  158 |         const raw = testInfo.outputPath(`rss-${browserName}-${pair}-${enabled ? "enabled" : "disabled"}.json`);
  159 |         await writeFile(raw, JSON.stringify({ ...provenance, browserVersion: browser.version(), pair, mode, enabled, viewport, rendered, interaction, phases, armError: armError === undefined ? null : String(armError), samples, samplingError: samplingError === undefined ? null : String(samplingError), completedRuns: runs }, null, 2));
  160 |         await testInfo.attach("density-arm-raw", { path: raw, contentType: "application/json" });
  161 |         await browser.close();
  162 |         await server.close();
  163 |       }
  164 |       if (samplingError !== undefined) throw samplingError;
  165 |       if (armError !== undefined) throw armError;
  166 |     }
  167 |   }
  168 |   const p95 = Math.max(...p95PerArm);
  169 |   const increments = peaks.enabled!.map((peak, index) => peak - peaks.disabled![index]!);
  170 |   const report = {
  171 |     ...provenance,
  172 |     method: "One dedicated browser tree/tab per arm; 50ms sampled summed process RSS from launch through identical 40 Tab interactions. Two order-alternated pairs (state marks, LRU); worst per-arm p95 reported, never averaged across cases. Input keydown to visible outlined focus, bounded by second animation frame. Local diagnostic; manual and dedicated-host qualification remain separate.",
  173 |     p95Ms: p95, incrementalPeakRssBytes: increments, runs,
  174 |     timingPass: p95 <= 100, memoryPass: increments.every((increment) => increment <= 32 * 1024 * 1024),
  175 |   };
  176 |   const output = testInfo.outputPath(`density-${browserName}.json`);
  177 |   await writeFile(output, JSON.stringify(report, null, 2));
  178 |   await testInfo.attach("density-raw", { path: output, contentType: "application/json" });
  179 |   expect(p95).toBeLessThanOrEqual(100);
> 180 |   for (const increment of increments) expect(increment).toBeLessThanOrEqual(32 * 1024 * 1024);
      |                                                         ^ Error: expect(received).toBeLessThanOrEqual(expected)
  181 | });
  182 | 
```