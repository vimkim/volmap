# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: overlay-density.spec.ts >> 12288 rendered page cells: per-browser visible latency and paired RSS
- Location: e2e/overlay-density.spec.ts:39:1

# Error details

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 33554432
Received:    155594752
```

# Test source

```ts
  56  |       const pid = server.process().pid;
  57  |       if (pid === undefined) throw new Error("No browser PID for RSS accounting");
  58  |       const browser = await browserType.connect(server.wsEndpoint());
  59  |       const samples: { elapsedMs: number; rss: number }[] = [];
  60  |       const started = performance.now();
  61  |       let sampling = true;
  62  |       let samplingError: unknown;
  63  |       let armError: unknown;
  64  |       let page: Page | undefined;
  65  |       let interaction: number[] = [];
  66  |       let rendered: { count: number; inViewport: number } | null = null;
  67  |       const sampler = (async () => {
  68  |         while (sampling) {
  69  |           samples.push({ elapsedMs: performance.now() - started, rss: await rssTree(pid) });
  70  |           await new Promise((resolve) => setTimeout(resolve, 50));
  71  |         }
  72  |       })().catch((error: unknown) => { samplingError = error; });
  73  |       try {
  74  |         page = await browser.newPage({ viewport });
  75  |         await page.goto("http://127.0.0.1:41742/volume/0", { waitUntil: "commit" });
  76  |         const cells = page.locator("[data-observation-page]");
  77  |         // Exercise real collection pagination; never inject a synthetic model.
  78  |         while (await cells.count() < 12288) {
  79  |           await page.getByRole("button", { name: "Load more sectors" }).click();
  80  |         }
  81  |         await expect(cells).toHaveCount(12288);
  82  |         await page.evaluate(() => window.scrollTo(0, 0));
  83  |         rendered = await cells.evaluateAll((elements) => ({
  84  |           count: elements.filter((element) => element.getClientRects().length > 0).length,
  85  |           inViewport: elements.filter((element) => {
  86  |             const box = element.getBoundingClientRect();
  87  |             return box.top >= 0 && box.bottom <= innerHeight && box.left >= 0 && box.right <= innerWidth;
  88  |           }).length,
  89  |         }));
  90  |         expect(rendered.count).toBe(12288);
  91  |         if (enabled) {
  92  |           await page.getByRole("button", { name: "Enable observations" }).click();
  93  |           await expect(page.getByRole("region", { name: "Visible-page buffer observations" })).toContainText("Evaluated 512 / requested 512");
  94  |         }
  95  |         // Same keyboard focus changes, viewport and DOM workload in both arms.
  96  |         // The second animation frame gives a conservative post-paint bound.
  97  |         await page.evaluate(() => {
  98  |           const samples: number[] = [];
  99  |           Object.assign(window, { densityInputSamples: samples });
  100 |           document.addEventListener("keydown", (event) => {
  101 |             if (event.key !== "Tab") return;
  102 |             const start = event.timeStamp;
  103 |             if (!Number.isFinite(start) || start < 0 || start > performance.now()) throw new Error("Invalid input timestamp clock");
  104 |             const before = document.activeElement;
  105 |             requestAnimationFrame(() => requestAnimationFrame(() => {
  106 |               const active = document.activeElement;
  107 |               if (active === before || !(active instanceof HTMLElement)) return;
  108 |               const rect = active.getBoundingClientRect();
  109 |               if (rect.width > 0 && rect.height > 0 && rect.bottom > 54 && rect.top < innerHeight && rect.right > 0 && rect.left < innerWidth && getComputedStyle(active).outlineStyle !== "none") samples.push(performance.now() - start);
  110 |             }));
  111 |           }, true);
  112 |         });
  113 |         await page.getByRole("button", { name: /^Sector 0,/ }).focus();
  114 |         for (let index = 0; index < 40; index += 1) {
  115 |           await page.keyboard.press("Tab");
  116 |           await page.evaluate(() => new Promise<void>((resolve) => requestAnimationFrame(() => requestAnimationFrame(() => resolve()))));
  117 |         }
  118 |         interaction = await page.evaluate(() => Reflect.get(window, "densityInputSamples") as number[]);
  119 |         expect(interaction).toHaveLength(40);
  120 |         if (enabled) timings.push(...interaction);
  121 |         const peak = Math.max(...samples.map((sample) => sample.rss));
  122 |         peaks[enabled ? "enabled" : "disabled"]!.push(peak);
  123 |         runs.push({ pair, enabled, browserVersion: browser.version(), rendered, viewport, interactionMs: interaction, rssSamples: samples, peakRssBytes: peak });
  124 |       } catch (error) {
  125 |         armError = error;
  126 |         throw error;
  127 |       } finally {
  128 |         sampling = false;
  129 |         await sampler;
  130 |         if (page && !page.isClosed()) {
  131 |           try { interaction = await page.evaluate(() => Reflect.get(window, "densityInputSamples") as number[] ?? []); }
  132 |           catch (error) { armError ??= error; }
  133 |         }
  134 |         const raw = testInfo.outputPath(`rss-${browserName}-${pair}-${enabled ? "enabled" : "disabled"}.json`);
  135 |         await writeFile(raw, JSON.stringify({ ...provenance, browserVersion: browser.version(), pair, enabled, viewport, rendered, interaction, armError: armError === undefined ? null : String(armError), samples, samplingError: samplingError === undefined ? null : String(samplingError), completedRuns: runs }, null, 2));
  136 |         await testInfo.attach("density-arm-raw", { path: raw, contentType: "application/json" });
  137 |         await browser.close();
  138 |         await server.close();
  139 |       }
  140 |       if (samplingError !== undefined) throw samplingError;
  141 |     }
  142 |   }
  143 |   const sorted = [...timings].sort((a, b) => a - b);
  144 |   const p95 = sorted[Math.ceil(sorted.length * 0.95) - 1]!;
  145 |   const increments = peaks.enabled!.map((peak, index) => peak - peaks.disabled![index]!);
  146 |   const report = {
  147 |     ...provenance,
  148 |     method: "One dedicated browser tree/tab per arm; 50ms sampled summed process RSS from launch through identical 40 Tab interactions. Two order-alternated pairs. Input keydown to visible outlined focus, bounded by second animation frame. Local diagnostic; manual and dedicated-host qualification remain separate.",
  149 |     p95Ms: p95, incrementalPeakRssBytes: increments, runs,
  150 |     timingPass: p95 <= 100, memoryPass: increments.every((increment) => increment <= 32 * 1024 * 1024),
  151 |   };
  152 |   const output = testInfo.outputPath(`density-${browserName}.json`);
  153 |   await writeFile(output, JSON.stringify(report, null, 2));
  154 |   await testInfo.attach("density-raw", { path: output, contentType: "application/json" });
  155 |   expect(p95).toBeLessThanOrEqual(100);
> 156 |   for (const increment of increments) expect(increment).toBeLessThanOrEqual(32 * 1024 * 1024);
      |                                                         ^ Error: expect(received).toBeLessThanOrEqual(expected)
  157 | });
  158 | 
```