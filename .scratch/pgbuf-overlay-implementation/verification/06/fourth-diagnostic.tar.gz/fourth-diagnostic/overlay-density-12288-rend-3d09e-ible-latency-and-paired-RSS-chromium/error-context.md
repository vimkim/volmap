# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: overlay-density.spec.ts >> 12288 rendered page cells: per-browser visible latency and paired RSS
- Location: e2e/overlay-density.spec.ts:40:1

# Error details

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 33554432
Received:    63287296
```

# Test source

```ts
  58  |       const pid = server.process().pid;
  59  |       if (pid === undefined) throw new Error("No browser PID for RSS accounting");
  60  |       const browser = await browserType.connect(server.wsEndpoint());
  61  |       const samples: { elapsedMs: number; rss: number }[] = [];
  62  |       const started = performance.now();
  63  |       let sampling = true;
  64  |       let samplingError: unknown;
  65  |       let armError: unknown;
  66  |       let page: Page | undefined;
  67  |       let interaction: number[] = [];
  68  |       let rendered: { count: number; inViewport: number } | null = null;
  69  |       const sampler = (async () => {
  70  |         while (sampling) {
  71  |           samples.push({ elapsedMs: performance.now() - started, rss: await rssTree(pid) });
  72  |           await new Promise((resolve) => setTimeout(resolve, 50));
  73  |         }
  74  |       })().catch((error: unknown) => { samplingError = error; });
  75  |       try {
  76  |         page = await browser.newPage({ viewport });
  77  |         await page.goto("http://127.0.0.1:41742/volume/0", { waitUntil: "commit" });
  78  |         const cells = page.locator("[data-observation-page]");
  79  |         // Exercise real collection pagination; never inject a synthetic model.
  80  |         await loadVolumeCells(page, 12288);
  81  |         await page.evaluate(() => window.scrollTo(0, 0));
  82  |         rendered = await cells.evaluateAll((elements) => ({
  83  |           count: elements.filter((element) => element.getClientRects().length > 0).length,
  84  |           inViewport: elements.filter((element) => {
  85  |             const box = element.getBoundingClientRect();
  86  |             return box.top >= 0 && box.bottom <= innerHeight && box.left >= 0 && box.right <= innerWidth;
  87  |           }).length,
  88  |         }));
  89  |         expect(rendered.count).toBe(12288);
  90  |         if (enabled) {
  91  |           await page.getByRole("button", { name: "Enable observations" }).click();
  92  |           await expect(page.getByRole("region", { name: "Visible-page buffer observations" })).toContainText("Evaluated 512 / requested 512");
  93  |           await page.getByRole("combobox", { name: "Runtime color mode" }).selectOption(mode);
  94  |         }
  95  |         // Same keyboard focus changes, viewport and DOM workload in both arms.
  96  |         // The second animation frame gives a conservative post-paint bound.
  97  |         await page.evaluate(() => {
  98  |           const samples: number[] = [];
  99  |           Object.assign(window, { densityInputSamples: samples });
  100 |           document.addEventListener("keydown", (event) => {
  101 |             if (event.key !== "Tab") return;
  102 |             const start = event.timeStamp;
  103 |             if (!Number.isFinite(start) || start < 0 || start > performance.now()) throw new Error("Invalid input timestamp clock");
  104 |             const before = document.activeElement;
  105 |             requestAnimationFrame(() => requestAnimationFrame(() => {
  106 |               const active = document.activeElement;
  107 |               if (active === before || !(active instanceof HTMLElement)) return;
  108 |               const rect = active.getBoundingClientRect();
  109 |               if (rect.width > 0 && rect.height > 0 && rect.bottom > 54 && rect.top < innerHeight && rect.right > 0 && rect.left < innerWidth && getComputedStyle(active).outlineStyle !== "none") samples.push(performance.now() - start);
  110 |             }));
  111 |           }, true);
  112 |         });
  113 |         await page.getByRole("button", { name: /^Sector 0,/ }).focus();
  114 |         for (let index = 0; index < 40; index += 1) {
  115 |           await page.keyboard.press("Tab");
  116 |           await page.evaluate(() => new Promise<void>((resolve) => requestAnimationFrame(() => requestAnimationFrame(() => resolve()))));
  117 |         }
  118 |         interaction = await page.evaluate(() => Reflect.get(window, "densityInputSamples") as number[]);
  119 |         expect(interaction).toHaveLength(40);
  120 |         const sorted = [...interaction].sort((a, b) => a - b);
  121 |         const p95 = sorted[Math.ceil(sorted.length * 0.95) - 1]!;
  122 |         if (enabled) p95PerArm.push(p95);
  123 |         const peak = Math.max(...samples.map((sample) => sample.rss));
  124 |         peaks[enabled ? "enabled" : "disabled"]!.push(peak);
  125 |         runs.push({ pair, mode, enabled, p95Ms: p95, browserVersion: browser.version(), rendered, viewport, interactionMs: interaction, rssSamples: samples, peakRssBytes: peak });
  126 |       } catch (error) {
  127 |         armError = error;
  128 |         throw error;
  129 |       } finally {
  130 |         sampling = false;
  131 |         await sampler;
  132 |         if (page && !page.isClosed()) {
  133 |           try { interaction = await page.evaluate(() => Reflect.get(window, "densityInputSamples") as number[] ?? []); }
  134 |           catch (error) { armError ??= error; }
  135 |         }
  136 |         const raw = testInfo.outputPath(`rss-${browserName}-${pair}-${enabled ? "enabled" : "disabled"}.json`);
  137 |         await writeFile(raw, JSON.stringify({ ...provenance, browserVersion: browser.version(), pair, mode, enabled, viewport, rendered, interaction, armError: armError === undefined ? null : String(armError), samples, samplingError: samplingError === undefined ? null : String(samplingError), completedRuns: runs }, null, 2));
  138 |         await testInfo.attach("density-arm-raw", { path: raw, contentType: "application/json" });
  139 |         await browser.close();
  140 |         await server.close();
  141 |       }
  142 |       if (samplingError !== undefined) throw samplingError;
  143 |       if (armError !== undefined) throw armError;
  144 |     }
  145 |   }
  146 |   const p95 = Math.max(...p95PerArm);
  147 |   const increments = peaks.enabled!.map((peak, index) => peak - peaks.disabled![index]!);
  148 |   const report = {
  149 |     ...provenance,
  150 |     method: "One dedicated browser tree/tab per arm; 50ms sampled summed process RSS from launch through identical 40 Tab interactions. Two order-alternated pairs (state marks, LRU); worst per-arm p95 reported, never averaged across cases. Input keydown to visible outlined focus, bounded by second animation frame. Local diagnostic; manual and dedicated-host qualification remain separate.",
  151 |     p95Ms: p95, incrementalPeakRssBytes: increments, runs,
  152 |     timingPass: p95 <= 100, memoryPass: increments.every((increment) => increment <= 32 * 1024 * 1024),
  153 |   };
  154 |   const output = testInfo.outputPath(`density-${browserName}.json`);
  155 |   await writeFile(output, JSON.stringify(report, null, 2));
  156 |   await testInfo.attach("density-raw", { path: output, contentType: "application/json" });
  157 |   expect(p95).toBeLessThanOrEqual(100);
> 158 |   for (const increment of increments) expect(increment).toBeLessThanOrEqual(32 * 1024 * 1024);
      |                                                         ^ Error: expect(received).toBeLessThanOrEqual(expected)
  159 | });
  160 | 
```