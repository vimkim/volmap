# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: overlay-density.spec.ts >> 12288 rendered page cells: per-browser visible latency and paired RSS
- Location: e2e/overlay-density.spec.ts:40:1

# Error details

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 100
Received:    279.5
```

# Test source

```ts
  53  |   // Alternate order to expose warm-cache/order effects; retain each pair.
  54  |   for (let pair = 0; pair < 2; pair += 1) {
  55  |     for (const enabled of pair === 0 ? [false, true] : [true, false]) {
  56  |       const server = await browserType.launchServer({ headless: true });
  57  |       const pid = server.process().pid;
  58  |       if (pid === undefined) throw new Error("No browser PID for RSS accounting");
  59  |       const browser = await browserType.connect(server.wsEndpoint());
  60  |       const samples: { elapsedMs: number; rss: number }[] = [];
  61  |       const started = performance.now();
  62  |       let sampling = true;
  63  |       let samplingError: unknown;
  64  |       let armError: unknown;
  65  |       let page: Page | undefined;
  66  |       let interaction: number[] = [];
  67  |       let rendered: { count: number; inViewport: number } | null = null;
  68  |       const sampler = (async () => {
  69  |         while (sampling) {
  70  |           samples.push({ elapsedMs: performance.now() - started, rss: await rssTree(pid) });
  71  |           await new Promise((resolve) => setTimeout(resolve, 50));
  72  |         }
  73  |       })().catch((error: unknown) => { samplingError = error; });
  74  |       try {
  75  |         page = await browser.newPage({ viewport });
  76  |         await page.goto("http://127.0.0.1:41742/volume/0", { waitUntil: "commit" });
  77  |         const cells = page.locator("[data-observation-page]");
  78  |         // Exercise real collection pagination; never inject a synthetic model.
  79  |         await loadVolumeCells(page, 12288);
  80  |         await page.evaluate(() => window.scrollTo(0, 0));
  81  |         rendered = await cells.evaluateAll((elements) => ({
  82  |           count: elements.filter((element) => element.getClientRects().length > 0).length,
  83  |           inViewport: elements.filter((element) => {
  84  |             const box = element.getBoundingClientRect();
  85  |             return box.top >= 0 && box.bottom <= innerHeight && box.left >= 0 && box.right <= innerWidth;
  86  |           }).length,
  87  |         }));
  88  |         expect(rendered.count).toBe(12288);
  89  |         if (enabled) {
  90  |           await page.getByRole("button", { name: "Enable observations" }).click();
  91  |           await expect(page.getByRole("region", { name: "Visible-page buffer observations" })).toContainText("Evaluated 512 / requested 512");
  92  |         }
  93  |         // Same keyboard focus changes, viewport and DOM workload in both arms.
  94  |         // The second animation frame gives a conservative post-paint bound.
  95  |         await page.evaluate(() => {
  96  |           const samples: number[] = [];
  97  |           Object.assign(window, { densityInputSamples: samples });
  98  |           document.addEventListener("keydown", (event) => {
  99  |             if (event.key !== "Tab") return;
  100 |             const start = event.timeStamp;
  101 |             if (!Number.isFinite(start) || start < 0 || start > performance.now()) throw new Error("Invalid input timestamp clock");
  102 |             const before = document.activeElement;
  103 |             requestAnimationFrame(() => requestAnimationFrame(() => {
  104 |               const active = document.activeElement;
  105 |               if (active === before || !(active instanceof HTMLElement)) return;
  106 |               const rect = active.getBoundingClientRect();
  107 |               if (rect.width > 0 && rect.height > 0 && rect.bottom > 54 && rect.top < innerHeight && rect.right > 0 && rect.left < innerWidth && getComputedStyle(active).outlineStyle !== "none") samples.push(performance.now() - start);
  108 |             }));
  109 |           }, true);
  110 |         });
  111 |         await page.getByRole("button", { name: /^Sector 0,/ }).focus();
  112 |         for (let index = 0; index < 40; index += 1) {
  113 |           await page.keyboard.press("Tab");
  114 |           await page.evaluate(() => new Promise<void>((resolve) => requestAnimationFrame(() => requestAnimationFrame(() => resolve()))));
  115 |         }
  116 |         interaction = await page.evaluate(() => Reflect.get(window, "densityInputSamples") as number[]);
  117 |         expect(interaction).toHaveLength(40);
  118 |         if (enabled) timings.push(...interaction);
  119 |         const peak = Math.max(...samples.map((sample) => sample.rss));
  120 |         peaks[enabled ? "enabled" : "disabled"]!.push(peak);
  121 |         runs.push({ pair, enabled, browserVersion: browser.version(), rendered, viewport, interactionMs: interaction, rssSamples: samples, peakRssBytes: peak });
  122 |       } catch (error) {
  123 |         armError = error;
  124 |         throw error;
  125 |       } finally {
  126 |         sampling = false;
  127 |         await sampler;
  128 |         if (page && !page.isClosed()) {
  129 |           try { interaction = await page.evaluate(() => Reflect.get(window, "densityInputSamples") as number[] ?? []); }
  130 |           catch (error) { armError ??= error; }
  131 |         }
  132 |         const raw = testInfo.outputPath(`rss-${browserName}-${pair}-${enabled ? "enabled" : "disabled"}.json`);
  133 |         await writeFile(raw, JSON.stringify({ ...provenance, browserVersion: browser.version(), pair, enabled, viewport, rendered, interaction, armError: armError === undefined ? null : String(armError), samples, samplingError: samplingError === undefined ? null : String(samplingError), completedRuns: runs }, null, 2));
  134 |         await testInfo.attach("density-arm-raw", { path: raw, contentType: "application/json" });
  135 |         await browser.close();
  136 |         await server.close();
  137 |       }
  138 |       if (samplingError !== undefined) throw samplingError;
  139 |     }
  140 |   }
  141 |   const sorted = [...timings].sort((a, b) => a - b);
  142 |   const p95 = sorted[Math.ceil(sorted.length * 0.95) - 1]!;
  143 |   const increments = peaks.enabled!.map((peak, index) => peak - peaks.disabled![index]!);
  144 |   const report = {
  145 |     ...provenance,
  146 |     method: "One dedicated browser tree/tab per arm; 50ms sampled summed process RSS from launch through identical 40 Tab interactions. Two order-alternated pairs. Input keydown to visible outlined focus, bounded by second animation frame. Local diagnostic; manual and dedicated-host qualification remain separate.",
  147 |     p95Ms: p95, incrementalPeakRssBytes: increments, runs,
  148 |     timingPass: p95 <= 100, memoryPass: increments.every((increment) => increment <= 32 * 1024 * 1024),
  149 |   };
  150 |   const output = testInfo.outputPath(`density-${browserName}.json`);
  151 |   await writeFile(output, JSON.stringify(report, null, 2));
  152 |   await testInfo.attach("density-raw", { path: output, contentType: "application/json" });
> 153 |   expect(p95).toBeLessThanOrEqual(100);
      |               ^ Error: expect(received).toBeLessThanOrEqual(expected)
  154 |   for (const increment of increments) expect(increment).toBeLessThanOrEqual(32 * 1024 * 1024);
  155 | });
  156 | 
```