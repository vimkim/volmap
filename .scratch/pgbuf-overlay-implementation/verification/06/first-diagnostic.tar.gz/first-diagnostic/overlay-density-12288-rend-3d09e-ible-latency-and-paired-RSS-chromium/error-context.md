# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: overlay-density.spec.ts >> 12288 rendered page cells: per-browser visible latency and paired RSS
- Location: e2e/overlay-density.spec.ts:35:1

# Error details

```
Error: Missing RSS for browser process 1227419
```

# Test source

```ts
  1   | import { chromium, firefox, expect, test, type Page } from "@playwright/test";
  2   | import { readFile, readdir, writeFile } from "node:fs/promises";
  3   | import { execFileSync } from "node:child_process";
  4   | import { cpus, hostname, release, totalmem } from "node:os";
  5   | import { createHash } from "node:crypto";
  6   | 
  7   | // A dedicated browser process tree with one tab. Summed RSS includes shared
  8   | // pages in each process; this is conservative accounting, not JS heap size.
  9   | async function rssTree(root: number): Promise<number> {
  10  |   const processes = await Promise.all((await readdir("/proc")).filter((name) => /^\d+$/.test(name)).map(async (name) => {
  11  |     try {
  12  |       const status = await readFile(`/proc/${name}/status`, "utf8");
  13  |       const rss = status.match(/^VmRSS:\s+(\d+)/m)?.[1];
  14  |       if (Number(name) === root && (rss === undefined || Number(rss) <= 0)) throw new Error("Browser root has no resident memory");
  15  |       return { pid: Number(name), parent: Number(status.match(/^PPid:\s+(\d+)/m)?.[1]), rss: rss === undefined ? (/^State:\s+Z/m.test(status) ? 0 : null) : Number(rss) * 1024 };
  16  |     } catch (error) {
  17  |       if (Number(name) !== root && ["ENOENT", "ESRCH"].includes((error as NodeJS.ErrnoException).code ?? "")) return null;
  18  |       throw error;
  19  |     }
  20  |   }));
  21  |   if (!processes.some((process) => process?.pid === root)) throw new Error("Browser root missing from RSS sample");
  22  |   const members = new Set([root]);
  23  |   let previous = 0;
  24  |   while (previous !== members.size) {
  25  |     previous = members.size;
  26  |     for (const process of processes) if (process && members.has(process.parent)) members.add(process.pid);
  27  |   }
  28  |   return processes.reduce((sum, process) => {
  29  |     if (!process || !members.has(process.pid)) return sum;
> 30  |     if (process.rss === null) throw new Error(`Missing RSS for browser process ${process.pid}`);
      |                                     ^ Error: Missing RSS for browser process 1227419
  31  |     return sum + process.rss;
  32  |   }, 0);
  33  | }
  34  | 
  35  | test("12288 rendered page cells: per-browser visible latency and paired RSS", async ({ browserName }, testInfo) => {
  36  |   const browserType = browserName === "chromium" ? chromium : firefox;
  37  |   const viewport = { width: 1920, height: 1080 };
  38  |   const provenance = {
  39  |     consumerCommit: execFileSync("git", ["rev-parse", "HEAD"], { encoding: "utf8" }).trim(),
  40  |     dirtyDiffSha256: createHash("sha256").update(execFileSync("git", ["diff", "HEAD"])).digest("hex"),
  41  |     corpusSha256: createHash("sha256").update(await readFile("../fixtures/pgbuf-inspector/v1/corpus/exchanges/complete/stream.jsonl")).digest("hex"),
  42  |     host: { name: hostname(), kernel: release(), cpu: cpus()[0]?.model, logicalCpus: cpus().length, memoryBytes: totalmem() },
  43  |     build: "release", browserName, command: "playwright test --config playwright.density.config.ts",
  44  |   };
  45  |   const runs: object[] = [];
  46  |   const peaks: Record<string, number[]> = { enabled: [], disabled: [] };
  47  |   const timings: number[] = [];
  48  |   // Alternate order to expose warm-cache/order effects; retain each pair.
  49  |   for (let pair = 0; pair < 2; pair += 1) {
  50  |     for (const enabled of pair === 0 ? [false, true] : [true, false]) {
  51  |       const server = await browserType.launchServer({ headless: true });
  52  |       const pid = server.process().pid;
  53  |       if (pid === undefined) throw new Error("No browser PID for RSS accounting");
  54  |       const browser = await browserType.connect(server.wsEndpoint());
  55  |       const samples: { elapsedMs: number; rss: number }[] = [];
  56  |       const started = performance.now();
  57  |       let sampling = true;
  58  |       let samplingError: unknown;
  59  |       let armError: unknown;
  60  |       let page: Page | undefined;
  61  |       let interaction: number[] = [];
  62  |       let rendered: { count: number; inViewport: number } | null = null;
  63  |       const sampler = (async () => {
  64  |         while (sampling) {
  65  |           samples.push({ elapsedMs: performance.now() - started, rss: await rssTree(pid) });
  66  |           await new Promise((resolve) => setTimeout(resolve, 50));
  67  |         }
  68  |       })().catch((error: unknown) => { samplingError = error; });
  69  |       try {
  70  |         page = await browser.newPage({ viewport });
  71  |         await page.goto("http://127.0.0.1:41742/volume/0", { waitUntil: "commit" });
  72  |         const cells = page.locator("[data-observation-page]");
  73  |         // Exercise real collection pagination; never inject a synthetic model.
  74  |         while (await cells.count() < 12288) {
  75  |           await page.getByRole("button", { name: "Load more sectors" }).click();
  76  |         }
  77  |         await expect(cells).toHaveCount(12288);
  78  |         await page.evaluate(() => window.scrollTo(0, 0));
  79  |         rendered = await cells.evaluateAll((elements) => ({
  80  |           count: elements.filter((element) => element.getClientRects().length > 0).length,
  81  |           inViewport: elements.filter((element) => {
  82  |             const box = element.getBoundingClientRect();
  83  |             return box.top >= 0 && box.bottom <= innerHeight && box.left >= 0 && box.right <= innerWidth;
  84  |           }).length,
  85  |         }));
  86  |         expect(rendered.count).toBe(12288);
  87  |         if (enabled) {
  88  |           await page.getByRole("button", { name: "Enable observations" }).click();
  89  |           await expect(page.getByRole("region", { name: "Visible-page buffer observations" })).toContainText("Evaluated 512 / requested 512");
  90  |         }
  91  |         // Same keyboard focus changes, viewport and DOM workload in both arms.
  92  |         // The second animation frame gives a conservative post-paint bound.
  93  |         await page.evaluate(() => {
  94  |           const samples: number[] = [];
  95  |           Object.assign(window, { densityInputSamples: samples });
  96  |           document.addEventListener("keydown", (event) => {
  97  |             if (event.key !== "Tab") return;
  98  |             const start = event.timeStamp;
  99  |             if (!Number.isFinite(start) || start < 0 || start > performance.now()) throw new Error("Invalid input timestamp clock");
  100 |             const before = document.activeElement;
  101 |             requestAnimationFrame(() => requestAnimationFrame(() => {
  102 |               const active = document.activeElement;
  103 |               if (active === before || !(active instanceof HTMLElement)) return;
  104 |               const rect = active.getBoundingClientRect();
  105 |               if (rect.width > 0 && rect.height > 0 && rect.top >= 0 && rect.bottom <= innerHeight && getComputedStyle(active).outlineStyle !== "none") samples.push(performance.now() - start);
  106 |             }));
  107 |           }, true);
  108 |         });
  109 |         await page.getByRole("button", { name: /^Sector 0,/ }).focus();
  110 |         for (let index = 0; index < 40; index += 1) {
  111 |           await page.keyboard.press("Tab");
  112 |           await page.evaluate(() => new Promise<void>((resolve) => requestAnimationFrame(() => requestAnimationFrame(() => resolve()))));
  113 |         }
  114 |         interaction = await page.evaluate(() => Reflect.get(window, "densityInputSamples") as number[]);
  115 |         expect(interaction).toHaveLength(40);
  116 |         if (enabled) timings.push(...interaction);
  117 |         const peak = Math.max(...samples.map((sample) => sample.rss));
  118 |         peaks[enabled ? "enabled" : "disabled"]!.push(peak);
  119 |         runs.push({ pair, enabled, browserVersion: browser.version(), rendered, viewport, interactionMs: interaction, rssSamples: samples, peakRssBytes: peak });
  120 |       } catch (error) {
  121 |         armError = error;
  122 |         throw error;
  123 |       } finally {
  124 |         sampling = false;
  125 |         await sampler;
  126 |         if (page && !page.isClosed()) {
  127 |           try { interaction = await page.evaluate(() => Reflect.get(window, "densityInputSamples") as number[] ?? []); }
  128 |           catch (error) { armError ??= error; }
  129 |         }
  130 |         const raw = testInfo.outputPath(`rss-${browserName}-${pair}-${enabled ? "enabled" : "disabled"}.json`);
```