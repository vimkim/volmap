import pathlib,re,os,signal,time,sys,shutil
pid=int(sys.argv[1]);destination=pathlib.Path(sys.argv[2]);status=pathlib.Path(f'/proc/{pid}/status').read_text();caught=int(re.search(r'^SigCgt:\s*(\w+)',status,re.M)[1],16)
assert caught & (1 << (signal.SIGRTMIN-1)), 'Dedicated Firefox process has no SIGRTMIN handler'
existing=set(pathlib.Path('/tmp').glob(f'unified-memory-report-*-{pid}.json.gz'))
os.kill(pid,signal.SIGRTMIN)
for _ in range(300):
 matches=set(pathlib.Path('/tmp').glob(f'unified-memory-report-*-{pid}.json.gz'))-existing
 if matches:
  assert len(matches)==1
  shutil.move(str(matches.pop()),destination)
  break
 time.sleep(.1)
else:raise RuntimeError('Firefox report did not complete')
