import pathlib,re,json,sys,collections,os
root=int(sys.argv[1]);pending=[root];seen=set();result=[]
while pending:
 pid=pending.pop()
 if pid in seen:continue
 seen.add(pid)
 try:
  process=pathlib.Path('/proc')/str(pid)
  for task in (process/'task').iterdir():
   try:pending.extend(map(int,(task/'children').read_text().split()))
   except FileNotFoundError:pass
  command=(process/'cmdline').read_bytes().decode(errors='replace')
  kind=re.search(r'--type=([^\0 ]+)',command)
  kind=kind.group(1) if kind else 'content' if '-contentproc' in command else pathlib.Path(command.split('\0')[0]).name
  grouped=collections.defaultdict(collections.Counter);name='[anonymous]'
  for line in (process/'smaps').read_text().splitlines():
   header=re.match(r'^[0-9a-f]+-[0-9a-f]+\s+\S+\s+\S+\s+\S+\s+\d+\s*(.*)$',line)
   if header:name=os.path.basename(header[1]) or '[anonymous]'
   else:
    value=re.match(r'^(Rss|Pss|Private_Dirty|Private_Clean|Anonymous):\s+(\d+) kB$',line)
    if value:grouped[name][value[1]]+=int(value[2])*1024
  result.append({'pid':pid,'kind':kind,'mappings':grouped})
 except (FileNotFoundError,ProcessLookupError):
  if pid==root:raise
print(json.dumps(result))
