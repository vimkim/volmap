import { defineConfig } from "@playwright/test";
import density from "./playwright.density.config";
export default defineConfig({ ...density, testMatch: "**/shared-glyph-density.spec.ts" });
