# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: observations.spec.ts >> Volume nonresident circles preserve known and unknown occupancy backgrounds
- Location: e2e/observations.spec.ts:449:1

# Error details

```
Error: expect(locator).toHaveCSS(expected) failed

Locator:  locator('[data-observation-page="0:11"]')
Expected: "rgb(55, 65, 81)"
Received: "rgba(0, 0, 0, 0)"
Timeout:  5000ms

Call log:
  - Expect "toHaveCSS" with timeout 5000ms
  - waiting for locator('[data-observation-page="0:11"]')
    14 × locator resolved to <i aria-hidden="true" data-observation-page="0:11" data-runtime-state="not-resident" title="Page 11: ○ Observed not resident" class="page preview-page allocated occupancy-known runtime-lru zone-unknown"></i>
       - unexpected value "rgba(0, 0, 0, 0)"

```

# Page snapshot

```yaml
- generic [ref=e2]:
  - banner [ref=e3]:
    - strong [ref=e4]: VOLMAP
    - generic [ref=e5]: snapshot 2bbfbefd6444 · revision 0
    - generic [ref=e6]:
      - generic [ref=e7]: "paused at gen 0 · newer: gen 0"
      - button "Resume" [active] [pressed] [ref=e8] [cursor=pointer]
    - button "About & licenses" [ref=e9] [cursor=pointer]
    - generic [ref=e10]: success-limited
  - main [ref=e11]:
    - complementary [ref=e12]:
      - region "CUBRID page-buffer observation" [ref=e13]:
        - heading "CUBRID page-buffer observation" [level=2] [ref=e14]
        - button "Disable observations" [pressed] [ref=e15] [cursor=pointer]
        - generic [ref=e16]:
          - text: Runtime color mode
          - combobox "Runtime color mode" [ref=e17]:
            - option "State marks"
            - option "LRU topology" [selected]
        - button "Refresh visible-page observations" [disabled] [ref=e18]
        - paragraph [ref=e19]: Visible-page observations available
        - paragraph [ref=e20]: "Observation source: active"
      - region "Runtime overlay legend" [ref=e21]:
        - paragraph [ref=e22]: "LRU topology colors replace storage colors: 1 lru1 · 2 lru2 · 3 lru3 · V void · ! invalid · ? unknown. Private membership has a dashed edge."
        - paragraph [ref=e23]: "○ observed not resident · ? unknown / not evaluated · ≠ duplicate ambiguity. Pages outside this batch have no runtime glyph. No usable source or expired evidence: storage colors only, no runtime marks. Sampled states, not events or durability evidence."
        - paragraph [ref=e24]: "Conservative age: 6 s · stale (2000 ms interval) · paused"
        - paragraph [ref=e25]: "Source: active · Paused adoption · Visible-page observations available"
      - region "Visible-page buffer observations" [ref=e26]:
        - heading "Visible-page buffer observations" [level=2] [ref=e27]
        - paragraph [ref=e28]: Visible-page observations available
        - paragraph [ref=e29]: "512 admitted / 960 visible pages. Reduced admission: non-selected pages rotate at the 512-VPID limit. Other pages are not evaluated in this batch."
        - generic [ref=e30]:
          - paragraph [ref=e31]: "Shared lists: 2 · Private lists: 3. Indices are incarnation-local."
          - group [ref=e32]:
            - generic "Observed per-list counts in this batch only" [ref=e33] [cursor=pointer]
        - paragraph [ref=e34]: "Conservative age: 6 s · stale (2000 ms interval) · paused"
        - paragraph [ref=e35]: Evaluated 512 / requested 512; producer scan complete.
        - paragraph [ref=e36]: 1 observed resident · 511 observed not resident · 0 unknown.
        - group [ref=e37]:
          - generic "Available page observations and capture limitations" [ref=e38] [cursor=pointer]
      - heading "Snapshot hierarchy" [level=2] [ref=e39]
      - button "volume 0 · 64 sectors" [ref=e41] [cursor=pointer]
    - generic [ref=e42]:
      - navigation "Inspection hierarchy" [ref=e43]:
        - generic [ref=e44]: Volume 0
      - generic [ref=e46]:
        - generic [ref=e48]:
          - heading "Volume 0 · full map" [level=1] [ref=e49]
          - paragraph [ref=e50]: 64 sectors · 64 pages per sector · revision 0
        - generic "Full volume sector map" [ref=e51]:
          - 'button "Sector 0, reserved, 64 pages, buffer observations: 63 ○ Observed not resident; 1 observed resident" [ref=e52] [cursor=pointer]':
            - generic [ref=e53]:
              - strong [ref=e54]: Sector 0
              - generic [ref=e55]: reserved
            - generic [ref=e56]: 2D
          - 'button "Sector 1, unreserved, 64 pages, buffer observations: 64 ○ Observed not resident" [ref=e121] [cursor=pointer]':
            - generic [ref=e122]:
              - strong [ref=e123]: Sector 1
              - generic [ref=e124]: unreserved
          - 'button "Sector 2, unreserved, 64 pages, buffer observations: 64 ○ Observed not resident" [ref=e190] [cursor=pointer]':
            - generic [ref=e191]:
              - strong [ref=e192]: Sector 2
              - generic [ref=e193]: unreserved
          - 'button "Sector 3, unreserved, 64 pages, buffer observations: 64 ○ Observed not resident" [ref=e259] [cursor=pointer]':
            - generic [ref=e260]:
              - strong [ref=e261]: Sector 3
              - generic [ref=e262]: unreserved
          - 'button "Sector 4, unreserved, 64 pages, buffer observations: 64 ○ Observed not resident" [ref=e328] [cursor=pointer]':
            - generic [ref=e329]:
              - strong [ref=e330]: Sector 4
              - generic [ref=e331]: unreserved
          - 'button "Sector 5, unreserved, 64 pages, buffer observations: 64 ○ Observed not resident" [ref=e397] [cursor=pointer]':
            - generic [ref=e398]:
              - strong [ref=e399]: Sector 5
              - generic [ref=e400]: unreserved
          - 'button "Sector 6, unreserved, 64 pages, buffer observations: 64 ○ Observed not resident" [ref=e466] [cursor=pointer]':
            - generic [ref=e467]:
              - strong [ref=e468]: Sector 6
              - generic [ref=e469]: unreserved
          - 'button "Sector 7, unreserved, 64 pages, buffer observations: 64 ○ Observed not resident" [ref=e535] [cursor=pointer]':
            - generic [ref=e536]:
              - strong [ref=e537]: Sector 7
              - generic [ref=e538]: unreserved
          - 'button "Sector 8, unreserved, 64 pages, buffer observations: 64 ? Not evaluated" [ref=e604] [cursor=pointer]':
            - generic [ref=e605]:
              - strong [ref=e606]: Sector 8
              - generic [ref=e607]: unreserved
          - 'button "Sector 9, unreserved, 64 pages, buffer observations: 64 ? Not evaluated" [ref=e673] [cursor=pointer]':
            - generic [ref=e674]:
              - strong [ref=e675]: Sector 9
              - generic [ref=e676]: unreserved
          - 'button "Sector 10, unreserved, 64 pages, buffer observations: 64 ? Not evaluated" [ref=e742] [cursor=pointer]':
            - generic [ref=e743]:
              - strong [ref=e744]: Sector 10
              - generic [ref=e745]: unreserved
          - 'button "Sector 11, unreserved, 64 pages, buffer observations: 64 ? Not evaluated" [ref=e811] [cursor=pointer]':
            - generic [ref=e812]:
              - strong [ref=e813]: Sector 11
              - generic [ref=e814]: unreserved
          - 'button "Sector 12, unreserved, 64 pages, buffer observations: 64 ? Not evaluated" [ref=e880] [cursor=pointer]':
            - generic [ref=e881]:
              - strong [ref=e882]: Sector 12
              - generic [ref=e883]: unreserved
          - 'button "Sector 13, unreserved, 64 pages, buffer observations: 64 ? Not evaluated" [ref=e949] [cursor=pointer]':
            - generic [ref=e950]:
              - strong [ref=e951]: Sector 13
              - generic [ref=e952]: unreserved
          - 'button "Sector 14, unreserved, 64 pages, buffer observations: 64 ? Not evaluated" [ref=e1018] [cursor=pointer]':
            - generic [ref=e1019]:
              - strong [ref=e1020]: Sector 14
              - generic [ref=e1021]: unreserved
          - 'button "Sector 15, unreserved, 64 pages, buffer observations: 64 ? Not evaluated" [ref=e1087] [cursor=pointer]':
            - generic [ref=e1088]:
              - strong [ref=e1089]: Sector 15
              - generic [ref=e1090]: unreserved
          - 'button "Sector 16, unreserved, 64 pages, buffer observations: 64 ? Not evaluated" [ref=e1156] [cursor=pointer]':
            - generic [ref=e1157]:
              - strong [ref=e1158]: Sector 16
              - generic [ref=e1159]: unreserved
          - 'button "Sector 17, unreserved, 64 pages, buffer observations: 64 ? Not evaluated" [ref=e1225] [cursor=pointer]':
            - generic [ref=e1226]:
              - strong [ref=e1227]: Sector 17
              - generic [ref=e1228]: unreserved
          - 'button "Sector 18, unreserved, 64 pages, buffer observations: 64 ? Not evaluated" [ref=e1294] [cursor=pointer]':
            - generic [ref=e1295]:
              - strong [ref=e1296]: Sector 18
              - generic [ref=e1297]: unreserved
          - 'button "Sector 19, unreserved, 64 pages, buffer observations: 64 ? Not evaluated" [ref=e1363] [cursor=pointer]':
            - generic [ref=e1364]:
              - strong [ref=e1365]: Sector 19
              - generic [ref=e1366]: unreserved
          - 'button "Sector 20, unreserved, 64 pages, buffer observations: 64 ? Not evaluated" [ref=e1432] [cursor=pointer]':
            - generic [ref=e1433]:
              - strong [ref=e1434]: Sector 20
              - generic [ref=e1435]: unreserved
          - 'button "Sector 21, unreserved, 64 pages, buffer observations: 64 ? Not evaluated" [ref=e1501] [cursor=pointer]':
            - generic [ref=e1502]:
              - strong [ref=e1503]: Sector 21
              - generic [ref=e1504]: unreserved
          - 'button "Sector 22, unreserved, 64 pages, buffer observations: 64 ? Not evaluated" [ref=e1570] [cursor=pointer]':
            - generic [ref=e1571]:
              - strong [ref=e1572]: Sector 22
              - generic [ref=e1573]: unreserved
          - 'button "Sector 23, unreserved, 64 pages, buffer observations: 64 ? Not evaluated" [ref=e1639] [cursor=pointer]':
            - generic [ref=e1640]:
              - strong [ref=e1641]: Sector 23
              - generic [ref=e1642]: unreserved
        - status [ref=e1708]: Showing 24 of 64 sectors · scroll to continue
        - button "Load more sectors" [ref=e1710] [cursor=pointer]
```

# Test source

```ts
  385 |   await source.getByRole("button", { name: "Enable observations" }).click();
  386 |   await pending;
  387 |   try {
  388 |     await expect(source).toContainText("Observing visible pages");
  389 |     const refresh = source.getByRole("button", { name: "Refresh visible-page observations" });
  390 |     await expect(refresh).toBeDisabled();
  391 |     await expect(refresh).toHaveCSS("opacity", "1");
  392 |     await expect(refresh).toHaveCSS("outline-style", "dashed");
  393 |     await expect(page.locator('.preview-page[data-runtime-state="unavailable"]')).toHaveCount(0);
  394 |     await expect(page.locator(".sector-card").first()).toHaveAccessibleName(/source unavailable/);
  395 |   } finally {
  396 |     releaseCapture();
  397 |   }
  398 |   await expect(source).toContainText("Observation unavailable");
  399 |   await expect(page.locator('.preview-page[data-runtime-state="unavailable"]').first()).toHaveAttribute("title", /No usable observation/);
  400 |   await page.unroute("**/runtime/page-buffer/observe");
  401 |   await source.getByRole("button", { name: "Refresh visible-page observations" }).click();
  402 |   await expect(source).toContainText("Observation source: active");
  403 |   await expect(page.locator('.preview-page[data-runtime-state="resident"]').first()).toHaveAttribute("title", /Observed resident/);
  404 | });
  405 | 
  406 | test("enabling Volume observations keeps the map in place and the legend available", async ({ page }) => {
  407 |   await page.goto("http://127.0.0.1:41741/volume/0", { waitUntil: "commit" });
  408 |   const map = page.locator("#volumeMap");
  409 |   await expect(map).toBeVisible();
  410 |   const top = await map.evaluate((element) => element.getBoundingClientRect().top + window.scrollY);
  411 |   await page.getByRole("button", { name: "Enable observations", exact: true }).click();
  412 |   const legend = page.getByRole("region", { name: "Runtime overlay legend" });
  413 |   await expect(legend).toBeVisible();
  414 |   await expect(legend).toContainText("Pages outside this batch have no runtime glyph");
  415 |   expect(await map.evaluate((element) => element.getBoundingClientRect().top + window.scrollY)).toBe(top);
  416 |   await page.getByRole("combobox", { name: "Runtime color mode" }).selectOption("lru");
  417 |   await expect(legend).toContainText("LRU topology colors replace storage colors");
  418 |   expect(await map.evaluate((element) => element.getBoundingClientRect().top + window.scrollY)).toBe(top);
  419 | });
  420 | 
  421 | test("Volume nonresident markers share an image and retain a forced-color glyph", async ({ page, browserName }) => {
  422 |   await page.clock.install();
  423 |   await page.goto("http://127.0.0.1:41741/volume/0", { waitUntil: "commit" });
  424 |   await page.getByRole("button", { name: "Enable observations", exact: true }).click();
  425 |   const cell = page.locator('.preview-page[data-runtime-state="not-resident"]').first();
  426 |   await expect(cell).toHaveAttribute("title", /Observed not resident/);
  427 |   await page.getByRole("button", { name: "Pause", exact: true }).click();
  428 |   const bounds = await cell.boundingBox();
  429 |   await expect(cell).toHaveCSS("background-image", /data:image\/svg\+xml/);
  430 |   await expect(cell.locator(".runtime-glyph")).toHaveCount(0);
  431 |   await cell.locator("../..").screenshot({ path: `../.scratch/pgbuf-overlay-implementation/verification/06-shared-glyph/normal-sector-${browserName}.png` });
  432 |   await page.getByRole("combobox", { name: "Runtime color mode" }).selectOption("lru");
  433 |   await expect(cell).toHaveCSS("background-image", /data:image\/svg\+xml/);
  434 |   await expect(cell).toHaveCSS("background-color", "rgb(55, 65, 81)");
  435 |   await page.emulateMedia({ forcedColors: "active" });
  436 |   await expect(cell).toHaveCSS("background-image", "none");
  437 |   expect(await cell.evaluate((element) => getComputedStyle(element, "::after").content)).toBe('"○"');
  438 |   expect(await cell.boundingBox()).toEqual(bounds);
  439 |   await cell.locator("../..").screenshot({ path: `../.scratch/pgbuf-overlay-implementation/verification/06-shared-glyph/forced-sector-${browserName}.png` });
  440 |   await expect(page.getByRole("region", { name: "Runtime overlay legend" })).toContainText("○ observed not resident");
  441 |   const identity = await cell.getAttribute("data-observation-page");
  442 |   await page.getByRole("button", { name: "Disable observations", exact: true }).click();
  443 |   const cleared = page.locator(`[data-observation-page="${identity}"]`);
  444 |   await expect(cleared).not.toHaveAttribute("data-runtime-state");
  445 |   await expect(cleared).toHaveCSS("background-image", "none");
  446 |   expect(await cleared.evaluate((element) => getComputedStyle(element, "::after").content)).toBe("none");
  447 | });
  448 | 
  449 | test("Volume nonresident circles preserve known and unknown occupancy backgrounds", async ({ page }) => {
  450 |   await page.clock.install();
  451 |   await page.route(/\/api\/v1\/sectors\/0\?/, async (route) => {
  452 |     const response = await route.fetch();
  453 |     const body = await response.json();
  454 |     // Exercise both storage projections through the actual HTTP decoder.
  455 |     for (const sector of body.data.items) {
  456 |       for (const item of sector.pages) {
  457 |         if (![11, 12].includes(item.page_id)) continue;
  458 |         item.allocation = "allocated";
  459 |         item.occupancy = item.page_id === 11
  460 |           ? { state: "known", occupied_percent: 35, free_percent: 65 }
  461 |           : { state: "unknown" };
  462 |       }
  463 |     }
  464 |     await route.fulfill({ response, json: body });
  465 |   });
  466 |   await page.goto("http://127.0.0.1:41741/volume/0", { waitUntil: "commit" });
  467 |   const cells = [11, 12].map((id) => page.locator(`[data-observation-page="0:${id}"]`));
  468 |   const storage = [];
  469 |   for (const cell of cells) {
  470 |     await expect(cell).toHaveClass(/allocated occupancy-/);
  471 |     storage.push(await cell.evaluate((element) => getComputedStyle(element).backgroundImage));
  472 |   }
  473 |   await page.getByRole("button", { name: "Enable observations", exact: true }).click();
  474 |   for (const cell of cells) await expect(cell).toHaveAttribute("data-runtime-state", "not-resident");
  475 |   await page.getByRole("button", { name: "Pause", exact: true }).click();
  476 |   for (const [index, cell] of cells.entries()) {
  477 |     await expect(cell).toHaveCSS("background-image", /data:image\/svg\+xml/);
  478 |     expect(await cell.evaluate((element) => getComputedStyle(element).backgroundImage)).toContain(storage[index]);
  479 |     await expect(cell).toHaveCSS("background-size", /5px 9px, auto/);
  480 |   }
  481 |   await page.getByRole("combobox", { name: "Runtime color mode" }).selectOption("lru");
  482 |   for (const cell of cells) {
  483 |     await expect(cell).toHaveCSS("background-image", /data:image\/svg\+xml/);
  484 |     await expect(cell).not.toHaveCSS("background-image", /gradient/);
> 485 |     await expect(cell).toHaveCSS("background-color", "rgb(55, 65, 81)");
      |                        ^ Error: expect(locator).toHaveCSS(expected) failed
  486 |   }
  487 |   await page.getByRole("button", { name: "Disable observations", exact: true }).click();
  488 |   for (const [index, cell] of cells.entries()) {
  489 |     await expect(cell).toHaveCSS("background-image", storage[index]!);
  490 |     await expect(cell).toHaveCSS("background-size", "auto");
  491 |   }
  492 | });
  493 | 
```