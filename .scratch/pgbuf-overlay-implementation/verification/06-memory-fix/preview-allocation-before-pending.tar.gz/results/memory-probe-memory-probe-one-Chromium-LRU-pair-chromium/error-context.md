# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: memory-probe.spec.ts >> memory probe: one Chromium LRU pair
- Location: e2e/memory-probe.spec.ts:45:1

# Error details

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 33554432
Received:    45699072
```

# Test source

```ts
  81  |           await new Promise((resolve) => setTimeout(resolve, 50));
  82  |         }
  83  |       })().catch((error: unknown) => { samplingError = error; });
  84  |       try {
  85  |         page = await browser.newPage({ viewport });
  86  |         await page.route("**/app.js", (route) => route.fulfill({ contentType: "application/javascript", body: candidateJavascript }));
  87  |         await page.route("**/app.css", (route) => route.fulfill({ contentType: "text/css", body: candidateCss }));
  88  |         const cdp = await page.context().newCDPSession(page);
  89  |         await cdp.send("Performance.enable");
  90  |         phaseProbe = async (phase) => { const processes: object[] = []; await rssTree(pid, processes); phases.push({ processes, phase, elapsedMs: performance.now() - started, rss: await rssTree(pid), performance: await cdp.send("Performance.getMetrics"), dom: await cdp.send("Memory.getDOMCounters") }); };
  91  |         await page.goto("http://127.0.0.1:41742/volume/0", { waitUntil: "commit" });
  92  |         const cells = page.locator("[data-observation-page]");
  93  |         // Exercise real collection pagination; never inject a synthetic model.
  94  |         await loadVolumeCells(page, 12288);
  95  |         await page.evaluate(() => window.scrollTo(0, 0));
  96  |         rendered = await cells.evaluateAll((elements) => ({
  97  |           count: elements.filter((element) => element.getClientRects().length > 0).length,
  98  |           inViewport: elements.filter((element) => {
  99  |             const box = element.getBoundingClientRect();
  100 |             return box.top >= 0 && box.bottom <= innerHeight && box.left >= 0 && box.right <= innerWidth;
  101 |           }).length,
  102 |         }));
  103 |         expect(rendered.count).toBe(12288);
  104 |         await phaseProbe("loaded");
  105 |         await cdp.send("HeapProfiler.startSampling", { samplingInterval: 16384, includeObjectsCollectedByMajorGC: true, includeObjectsCollectedByMinorGC: true });
  106 |         if (enabled) {
  107 |           await page.evaluate(() => { const button = [...document.querySelectorAll("button")].find((element) => element.textContent === "Enable observations"); if (!button) throw new Error("Missing enable button"); button.click(); });
  108 |           await page.waitForFunction(() => document.querySelector("[aria-label=\"Visible-page buffer observations\"]")?.textContent?.includes("Evaluated 512 / requested 512"));
  109 |           await page.evaluate((mode) => { const select = document.querySelector<HTMLSelectElement>(".runtime-mode select"); if (!select) throw new Error("Missing color mode"); select.value = mode; select.dispatchEvent(new Event("change", { bubbles: true })); }, mode);
  110 |         }
  111 |         await phaseProbe("configured");
  112 |         await writeFile(testInfo.outputPath(`alloc-${enabled}-setup.json`), JSON.stringify(await cdp.send("HeapProfiler.stopSampling")));
  113 |         await cdp.send("HeapProfiler.startSampling", { samplingInterval: 16384, includeObjectsCollectedByMajorGC: true, includeObjectsCollectedByMinorGC: true });
  114 |         // Same keyboard focus changes, viewport and DOM workload in both arms.
  115 |         // The second animation frame gives a conservative post-paint bound.
  116 |         await page.evaluate(() => {
  117 |           const samples: number[] = [];
  118 |           Object.assign(window, { densityInputSamples: samples });
  119 |           document.addEventListener("keydown", (event) => {
  120 |             if (event.key !== "Tab") return;
  121 |             const start = event.timeStamp;
  122 |             if (!Number.isFinite(start) || start < 0 || start > performance.now()) throw new Error("Invalid input timestamp clock");
  123 |             const before = document.activeElement;
  124 |             requestAnimationFrame(() => requestAnimationFrame(() => {
  125 |               const active = document.activeElement;
  126 |               if (active === before || !(active instanceof HTMLElement)) return;
  127 |               const rect = active.getBoundingClientRect();
  128 |               if (rect.width > 0 && rect.height > 0 && rect.bottom > 54 && rect.top < innerHeight && rect.right > 0 && rect.left < innerWidth && getComputedStyle(active).outlineStyle !== "none") samples.push(performance.now() - start);
  129 |             }));
  130 |           }, true);
  131 |         });
  132 |         await page.evaluate(() => { const sector = document.getElementById("sector-0"); if (!sector) throw new Error("Missing sector"); sector.focus(); });
  133 |         for (let index = 0; index < 1; index += 1) {
  134 |           await page.keyboard.press("Tab");
  135 |           await page.evaluate(() => new Promise<void>((resolve) => requestAnimationFrame(() => requestAnimationFrame(() => resolve()))));
  136 |         }
  137 |         await phaseProbe("interacted");
  138 |         await writeFile(testInfo.outputPath(`alloc-${enabled}-interaction.json`), JSON.stringify(await cdp.send("HeapProfiler.stopSampling")));
  139 |         interaction = await page.evaluate(() => Reflect.get(window, "densityInputSamples") as number[]);
  140 |         expect(interaction).toHaveLength(1);
  141 |         const sorted = [...interaction].sort((a, b) => a - b);
  142 |         const p95 = sorted[Math.ceil(sorted.length * 0.95) - 1]!;
  143 |         if (enabled) p95PerArm.push(p95);
  144 |         sampling = false;
  145 |         await sampler;
  146 |         const peak = Math.max(...samples.map((sample) => sample.rss));
  147 |         peaks[enabled ? "enabled" : "disabled"]!.push(peak);
  148 |         runs.push({ pair, mode, enabled, p95Ms: p95, browserVersion: browser.version(), rendered, viewport, interactionMs: interaction, rssSamples: samples, peakRssBytes: peak });
  149 |       } catch (error) {
  150 |         armError = error;
  151 |         throw error;
  152 |       } finally {
  153 |         sampling = false;
  154 |         await sampler;
  155 |         if (page && !page.isClosed()) {
  156 |           try { interaction = await page.evaluate(() => Reflect.get(window, "densityInputSamples") as number[] ?? []); }
  157 |           catch (error) { armError ??= error; }
  158 |         }
  159 |         const raw = testInfo.outputPath(`rss-${browserName}-${pair}-${enabled ? "enabled" : "disabled"}.json`);
  160 |         await writeFile(raw, JSON.stringify({ ...provenance, browserVersion: browser.version(), pair, mode, enabled, viewport, rendered, interaction, phases, armError: armError === undefined ? null : String(armError), samples, samplingError: samplingError === undefined ? null : String(samplingError), completedRuns: runs }, null, 2));
  161 |         await testInfo.attach("density-arm-raw", { path: raw, contentType: "application/json" });
  162 |         await browser.close();
  163 |         await server.close();
  164 |       }
  165 |       if (samplingError !== undefined) throw samplingError;
  166 |       if (armError !== undefined) throw armError;
  167 |     }
  168 |   }
  169 |   const p95 = Math.max(...p95PerArm);
  170 |   const increments = peaks.enabled!.map((peak, index) => peak - peaks.disabled![index]!);
  171 |   const report = {
  172 |     ...provenance,
  173 |     method: "One dedicated browser tree/tab per arm; 50ms sampled summed process RSS from launch through identical 40 Tab interactions. Two order-alternated pairs (state marks, LRU); worst per-arm p95 reported, never averaged across cases. Input keydown to visible outlined focus, bounded by second animation frame. Local diagnostic; manual and dedicated-host qualification remain separate.",
  174 |     p95Ms: p95, incrementalPeakRssBytes: increments, runs,
  175 |     timingPass: p95 <= 100, memoryPass: increments.every((increment) => increment <= 32 * 1024 * 1024),
  176 |   };
  177 |   const output = testInfo.outputPath(`density-${browserName}.json`);
  178 |   await writeFile(output, JSON.stringify(report, null, 2));
  179 |   await testInfo.attach("density-raw", { path: output, contentType: "application/json" });
  180 |   expect(p95).toBeLessThanOrEqual(100);
> 181 |   for (const increment of increments) expect(increment).toBeLessThanOrEqual(32 * 1024 * 1024);
      |                                                         ^ Error: expect(received).toBeLessThanOrEqual(expected)
  182 | });
  183 | 
```