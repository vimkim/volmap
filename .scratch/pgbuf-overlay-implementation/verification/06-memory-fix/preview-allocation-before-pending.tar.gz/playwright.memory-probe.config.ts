import { defineConfig } from "@playwright/test";
import base from "./playwright.density.config";
export default defineConfig({ ...base, testMatch: "**/memory-probe.spec.ts", projects: base.projects?.filter((project) => project.name === "chromium"), outputDir: "../.scratch/pgbuf-overlay-implementation/verification/06-memory-fix/asset-probe-results", webServer: (Array.isArray(base.webServer) ? base.webServer : []).map((server) => ({ ...server, reuseExistingServer: true })) });
