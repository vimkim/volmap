# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: memory-probe.spec.ts >> 12288 rendered page cells: per-browser visible latency and paired RSS
- Location: e2e/memory-probe.spec.ts:40:1

# Error details

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 33554432
Received:    51974144
```

# Test source

```ts
  68  |       let page: Page | undefined;
  69  |       let interaction: number[] = [];
  70  |       let rendered: { count: number; inViewport: number } | null = null;
  71  |       const sampler = (async () => {
  72  |         while (sampling) {
  73  |           samples.push({ elapsedMs: performance.now() - started, rss: await rssTree(pid) });
  74  |           await new Promise((resolve) => setTimeout(resolve, 50));
  75  |         }
  76  |       })().catch((error: unknown) => { samplingError = error; });
  77  |       try {
  78  |         page = await browser.newPage({ viewport });
  79  |         await page.route("**/app.css", async (route) => {
  80  |           const response = await route.fetch();
  81  |           await route.fulfill({ response, body: `${await response.text()}\n#volumeMap { will-change: contents; }\n` });
  82  |         });
  83  |         await page.route("**/app.js", (route) => route.fulfill({ contentType: "application/javascript", body: candidateJavascript }));
  84  |         await page.goto("http://127.0.0.1:41742/volume/0", { waitUntil: "commit" });
  85  |         const cells = page.locator("[data-observation-page]");
  86  |         // Exercise real collection pagination; never inject a synthetic model.
  87  |         await loadVolumeCells(page, 12288);
  88  |         await page.evaluate(() => window.scrollTo(0, 0));
  89  |         rendered = await cells.evaluateAll((elements) => ({
  90  |           count: elements.filter((element) => element.getClientRects().length > 0).length,
  91  |           inViewport: elements.filter((element) => {
  92  |             const box = element.getBoundingClientRect();
  93  |             return box.top >= 0 && box.bottom <= innerHeight && box.left >= 0 && box.right <= innerWidth;
  94  |           }).length,
  95  |         }));
  96  |         expect(rendered.count).toBe(12288);
  97  |         await expect(page.locator("#volumeMap")).toHaveCSS("will-change", "contents");
  98  |         if (enabled) {
  99  |           await page.locator(".observation-controls").getByRole("button", { name: "Enable observations" }).click();
  100 |           await expect(page.locator(".observation-detail[aria-label=\"Visible-page buffer observations\"]")).toContainText("Evaluated 512 / requested 512");
  101 |           await page.locator(".observation-controls").getByRole("combobox", { name: "Runtime color mode" }).selectOption(mode);
  102 |         }
  103 |         // Same keyboard focus changes, viewport and DOM workload in both arms.
  104 |         // The second animation frame gives a conservative post-paint bound.
  105 |         await page.evaluate(() => {
  106 |           const samples: number[] = [];
  107 |           Object.assign(window, { densityInputSamples: samples });
  108 |           document.addEventListener("keydown", (event) => {
  109 |             if (event.key !== "Tab") return;
  110 |             const start = event.timeStamp;
  111 |             if (!Number.isFinite(start) || start < 0 || start > performance.now()) throw new Error("Invalid input timestamp clock");
  112 |             const before = document.activeElement;
  113 |             requestAnimationFrame(() => requestAnimationFrame(() => {
  114 |               const active = document.activeElement;
  115 |               if (active === before || !(active instanceof HTMLElement)) return;
  116 |               const rect = active.getBoundingClientRect();
  117 |               if (rect.width > 0 && rect.height > 0 && rect.bottom > 54 && rect.top < innerHeight && rect.right > 0 && rect.left < innerWidth && getComputedStyle(active).outlineStyle !== "none") samples.push(performance.now() - start);
  118 |             }));
  119 |           }, true);
  120 |         });
  121 |         await page.locator("#sector-0").focus();
  122 |         for (let index = 0; index < 40; index += 1) {
  123 |           await page.keyboard.press("Tab");
  124 |           await page.evaluate(() => new Promise<void>((resolve) => requestAnimationFrame(() => requestAnimationFrame(() => resolve()))));
  125 |         }
  126 |         interaction = await page.evaluate(() => Reflect.get(window, "densityInputSamples") as number[]);
  127 |         expect(interaction).toHaveLength(40);
  128 |         const sorted = [...interaction].sort((a, b) => a - b);
  129 |         const p95 = sorted[Math.ceil(sorted.length * 0.95) - 1]!;
  130 |         if (enabled) p95PerArm.push(p95);
  131 |         sampling = false;
  132 |         await sampler;
  133 |         const peak = Math.max(...samples.map((sample) => sample.rss));
  134 |         peaks[enabled ? "enabled" : "disabled"]!.push(peak);
  135 |         runs.push({ pair, mode, enabled, p95Ms: p95, browserVersion: browser.version(), rendered, viewport, interactionMs: interaction, rssSamples: samples, peakRssBytes: peak });
  136 |       } catch (error) {
  137 |         armError = error;
  138 |         throw error;
  139 |       } finally {
  140 |         sampling = false;
  141 |         await sampler;
  142 |         if (page && !page.isClosed()) {
  143 |           try { interaction = await page.evaluate(() => Reflect.get(window, "densityInputSamples") as number[] ?? []); }
  144 |           catch (error) { armError ??= error; }
  145 |         }
  146 |         const raw = testInfo.outputPath(`rss-${browserName}-${pair}-${enabled ? "enabled" : "disabled"}.json`);
  147 |         await writeFile(raw, JSON.stringify({ ...provenance, browserVersion: browser.version(), pair, mode, enabled, viewport, rendered, interaction, armError: armError === undefined ? null : String(armError), samples, samplingError: samplingError === undefined ? null : String(samplingError), completedRuns: runs }, null, 2));
  148 |         await testInfo.attach("density-arm-raw", { path: raw, contentType: "application/json" });
  149 |         await browser.close();
  150 |         await server.close();
  151 |       }
  152 |       if (samplingError !== undefined) throw samplingError;
  153 |       if (armError !== undefined) throw armError;
  154 |     }
  155 |   }
  156 |   const p95 = Math.max(...p95PerArm);
  157 |   const increments = peaks.enabled!.map((peak, index) => peak - peaks.disabled![index]!);
  158 |   const report = {
  159 |     ...provenance,
  160 |     method: "One dedicated browser tree/tab per arm; 50ms sampled summed process RSS from launch through identical 40 Tab interactions. Two order-alternated pairs (state marks, LRU); worst per-arm p95 reported, never averaged across cases. Input keydown to visible outlined focus, bounded by second animation frame. Local diagnostic; manual and dedicated-host qualification remain separate.",
  161 |     p95Ms: p95, incrementalPeakRssBytes: increments, runs,
  162 |     timingPass: p95 <= 100, memoryPass: increments.every((increment) => increment <= 32 * 1024 * 1024),
  163 |   };
  164 |   const output = testInfo.outputPath(`density-${browserName}.json`);
  165 |   await writeFile(output, JSON.stringify(report, null, 2));
  166 |   await testInfo.attach("density-raw", { path: output, contentType: "application/json" });
  167 |   expect(p95).toBeLessThanOrEqual(100);
> 168 |   for (const increment of increments) expect(increment).toBeLessThanOrEqual(32 * 1024 * 1024);
      |                                                         ^ Error: expect(received).toBeLessThanOrEqual(expected)
  169 | });
  170 | 
```