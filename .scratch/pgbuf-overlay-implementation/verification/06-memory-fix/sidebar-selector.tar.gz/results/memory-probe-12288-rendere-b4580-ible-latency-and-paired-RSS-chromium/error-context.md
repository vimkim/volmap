# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: memory-probe.spec.ts >> 12288 rendered page cells: per-browser visible latency and paired RSS
- Location: e2e/memory-probe.spec.ts:40:1

# Error details

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 33554432
Received:    50569216
```

# Test source

```ts
  67  |       let sampling = true;
  68  |       let samplingError: unknown;
  69  |       let armError: unknown;
  70  |       let page: Page | undefined;
  71  |       let interaction: number[] = [];
  72  |       let rendered: { count: number; inViewport: number } | null = null;
  73  |       const sampler = (async () => {
  74  |         while (sampling) {
  75  |           samples.push({ elapsedMs: performance.now() - started, rss: await rssTree(pid) });
  76  |           await new Promise((resolve) => setTimeout(resolve, 50));
  77  |         }
  78  |       })().catch((error: unknown) => { samplingError = error; });
  79  |       try {
  80  |         page = await browser.newPage({ viewport });
  81  |         await page.route("**/app.js", (route) => route.fulfill({ contentType: "application/javascript", body: candidateJavascript }));
  82  |         await page.route("**/app.css", (route) => route.fulfill({ contentType: "text/css", body: candidateCss }));
  83  |         await page.goto("http://127.0.0.1:41742/volume/0", { waitUntil: "commit" });
  84  |         const cells = page.locator("[data-observation-page]");
  85  |         // Exercise real collection pagination; never inject a synthetic model.
  86  |         await loadVolumeCells(page, 12288);
  87  |         await page.evaluate(() => window.scrollTo(0, 0));
  88  |         rendered = await cells.evaluateAll((elements) => ({
  89  |           count: elements.filter((element) => element.getClientRects().length > 0).length,
  90  |           inViewport: elements.filter((element) => {
  91  |             const box = element.getBoundingClientRect();
  92  |             return box.top >= 0 && box.bottom <= innerHeight && box.left >= 0 && box.right <= innerWidth;
  93  |           }).length,
  94  |         }));
  95  |         expect(rendered.count).toBe(12288);
  96  |         if (enabled) {
  97  |           await page.locator(".observation-controls").getByRole("button", { name: "Enable observations" }).click();
  98  |           await expect(page.locator(".observation-detail[aria-label=\"Visible-page buffer observations\"]")).toContainText("Evaluated 512 / requested 512");
  99  |           await page.locator(".observation-controls").getByRole("combobox", { name: "Runtime color mode" }).selectOption(mode);
  100 |         }
  101 |         if (enabled && mode === "lru") await expect(page.locator(".preview-page:not([data-runtime-state])").first()).toHaveCSS("background-color", "rgb(55, 65, 81)");
  102 |         // Same keyboard focus changes, viewport and DOM workload in both arms.
  103 |         // The second animation frame gives a conservative post-paint bound.
  104 |         await page.evaluate(() => {
  105 |           const samples: number[] = [];
  106 |           Object.assign(window, { densityInputSamples: samples });
  107 |           document.addEventListener("keydown", (event) => {
  108 |             if (event.key !== "Tab") return;
  109 |             const start = event.timeStamp;
  110 |             if (!Number.isFinite(start) || start < 0 || start > performance.now()) throw new Error("Invalid input timestamp clock");
  111 |             const before = document.activeElement;
  112 |             requestAnimationFrame(() => requestAnimationFrame(() => {
  113 |               const active = document.activeElement;
  114 |               if (active === before || !(active instanceof HTMLElement)) return;
  115 |               const rect = active.getBoundingClientRect();
  116 |               if (rect.width > 0 && rect.height > 0 && rect.bottom > 54 && rect.top < innerHeight && rect.right > 0 && rect.left < innerWidth && getComputedStyle(active).outlineStyle !== "none") samples.push(performance.now() - start);
  117 |             }));
  118 |           }, true);
  119 |         });
  120 |         await page.locator("#sector-0").focus();
  121 |         for (let index = 0; index < 40; index += 1) {
  122 |           await page.keyboard.press("Tab");
  123 |           await page.evaluate(() => new Promise<void>((resolve) => requestAnimationFrame(() => requestAnimationFrame(() => resolve()))));
  124 |         }
  125 |         interaction = await page.evaluate(() => Reflect.get(window, "densityInputSamples") as number[]);
  126 |         expect(interaction).toHaveLength(40);
  127 |         const sorted = [...interaction].sort((a, b) => a - b);
  128 |         const p95 = sorted[Math.ceil(sorted.length * 0.95) - 1]!;
  129 |         if (enabled) p95PerArm.push(p95);
  130 |         sampling = false;
  131 |         await sampler;
  132 |         const peak = Math.max(...samples.map((sample) => sample.rss));
  133 |         peaks[enabled ? "enabled" : "disabled"]!.push(peak);
  134 |         runs.push({ pair, mode, enabled, p95Ms: p95, browserVersion: browser.version(), rendered, viewport, interactionMs: interaction, rssSamples: samples, peakRssBytes: peak });
  135 |       } catch (error) {
  136 |         armError = error;
  137 |         throw error;
  138 |       } finally {
  139 |         sampling = false;
  140 |         await sampler;
  141 |         if (page && !page.isClosed()) {
  142 |           try { interaction = await page.evaluate(() => Reflect.get(window, "densityInputSamples") as number[] ?? []); }
  143 |           catch (error) { armError ??= error; }
  144 |         }
  145 |         const raw = testInfo.outputPath(`rss-${browserName}-${pair}-${enabled ? "enabled" : "disabled"}.json`);
  146 |         await writeFile(raw, JSON.stringify({ ...provenance, browserVersion: browser.version(), pair, mode, enabled, viewport, rendered, interaction, armError: armError === undefined ? null : String(armError), samples, samplingError: samplingError === undefined ? null : String(samplingError), completedRuns: runs }, null, 2));
  147 |         await testInfo.attach("density-arm-raw", { path: raw, contentType: "application/json" });
  148 |         await browser.close();
  149 |         await server.close();
  150 |       }
  151 |       if (samplingError !== undefined) throw samplingError;
  152 |       if (armError !== undefined) throw armError;
  153 |     }
  154 |   }
  155 |   const p95 = Math.max(...p95PerArm);
  156 |   const increments = peaks.enabled!.map((peak, index) => peak - peaks.disabled![index]!);
  157 |   const report = {
  158 |     ...provenance,
  159 |     method: "One dedicated browser tree/tab per arm; 50ms sampled summed process RSS from launch through identical 40 Tab interactions. Two order-alternated pairs (state marks, LRU); worst per-arm p95 reported, never averaged across cases. Input keydown to visible outlined focus, bounded by second animation frame. Local diagnostic; manual and dedicated-host qualification remain separate.",
  160 |     p95Ms: p95, incrementalPeakRssBytes: increments, runs,
  161 |     timingPass: p95 <= 100, memoryPass: increments.every((increment) => increment <= 32 * 1024 * 1024),
  162 |   };
  163 |   const output = testInfo.outputPath(`density-${browserName}.json`);
  164 |   await writeFile(output, JSON.stringify(report, null, 2));
  165 |   await testInfo.attach("density-raw", { path: output, contentType: "application/json" });
  166 |   expect(p95).toBeLessThanOrEqual(100);
> 167 |   for (const increment of increments) expect(increment).toBeLessThanOrEqual(32 * 1024 * 1024);
      |                                                         ^ Error: expect(received).toBeLessThanOrEqual(expected)
  168 | });
  169 | 
```