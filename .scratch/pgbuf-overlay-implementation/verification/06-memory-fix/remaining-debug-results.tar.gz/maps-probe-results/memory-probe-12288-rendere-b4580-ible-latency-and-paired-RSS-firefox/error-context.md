# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: memory-probe.spec.ts >> 12288 rendered page cells: per-browser visible latency and paired RSS
- Location: e2e/memory-probe.spec.ts:40:1

# Error details

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 33554432
Received:    42307584
```

# Test source

```ts
  66  |       let samplingError: unknown;
  67  |       let armError: unknown;
  68  |       let page: Page | undefined;
  69  |       let interaction: number[] = [];
  70  |       let rendered: { count: number; inViewport: number } | null = null;
  71  |       const sampler = (async () => {
  72  |         while (sampling) {
  73  |           samples.push({ elapsedMs: performance.now() - started, rss: await rssTree(pid) });
  74  |           await new Promise((resolve) => setTimeout(resolve, 50));
  75  |         }
  76  |       })().catch((error: unknown) => { samplingError = error; });
  77  |       try {
  78  |         page = await browser.newPage({ viewport });
  79  |         await page.goto("http://127.0.0.1:41742/volume/0", { waitUntil: "commit" });
  80  |         const cells = page.locator("[data-observation-page]");
  81  |         // Exercise real collection pagination; never inject a synthetic model.
  82  |         await loadVolumeCells(page, 12288);
  83  |         await page.evaluate(() => window.scrollTo(0, 0));
  84  |         rendered = await cells.evaluateAll((elements) => ({
  85  |           count: elements.filter((element) => element.getClientRects().length > 0).length,
  86  |           inViewport: elements.filter((element) => {
  87  |             const box = element.getBoundingClientRect();
  88  |             return box.top >= 0 && box.bottom <= innerHeight && box.left >= 0 && box.right <= innerWidth;
  89  |           }).length,
  90  |         }));
  91  |         expect(rendered.count).toBe(12288);
  92  |         phase("loaded");
  93  |         if (enabled) {
  94  |           await page.locator(".observation-controls").getByRole("button", { name: "Enable observations" }).click();
  95  |           await expect(page.locator(".observation-detail[aria-label=\"Visible-page buffer observations\"]")).toContainText("Evaluated 512 / requested 512");
  96  |           await page.locator(".observation-controls").getByRole("combobox", { name: "Runtime color mode" }).selectOption(mode);
  97  |         }
  98  |         phase("configured");
  99  |         // Same keyboard focus changes, viewport and DOM workload in both arms.
  100 |         // The second animation frame gives a conservative post-paint bound.
  101 |         await page.evaluate(() => {
  102 |           const samples: number[] = [];
  103 |           Object.assign(window, { densityInputSamples: samples });
  104 |           document.addEventListener("keydown", (event) => {
  105 |             if (event.key !== "Tab") return;
  106 |             const start = event.timeStamp;
  107 |             if (!Number.isFinite(start) || start < 0 || start > performance.now()) throw new Error("Invalid input timestamp clock");
  108 |             const before = document.activeElement;
  109 |             requestAnimationFrame(() => requestAnimationFrame(() => {
  110 |               const active = document.activeElement;
  111 |               if (active === before || !(active instanceof HTMLElement)) return;
  112 |               const rect = active.getBoundingClientRect();
  113 |               if (rect.width > 0 && rect.height > 0 && rect.bottom > 54 && rect.top < innerHeight && rect.right > 0 && rect.left < innerWidth && getComputedStyle(active).outlineStyle !== "none") samples.push(performance.now() - start);
  114 |             }));
  115 |           }, true);
  116 |         });
  117 |         await page.locator("#sector-0").focus();
  118 |         for (let index = 0; index < 40; index += 1) {
  119 |           await page.keyboard.press("Tab");
  120 |           await page.evaluate(() => new Promise<void>((resolve) => requestAnimationFrame(() => requestAnimationFrame(() => resolve()))));
  121 |         }
  122 |         phase("interacted");
  123 |         interaction = await page.evaluate(() => Reflect.get(window, "densityInputSamples") as number[]);
  124 |         expect(interaction).toHaveLength(40);
  125 |         const sorted = [...interaction].sort((a, b) => a - b);
  126 |         const p95 = sorted[Math.ceil(sorted.length * 0.95) - 1]!;
  127 |         if (enabled) p95PerArm.push(p95);
  128 |         sampling = false;
  129 |         await sampler;
  130 |         execFileSync("python3", ["/tmp/volmap-dump-ff.py", String(pid), testInfo.outputPath(`firefox-memory-${enabled}.json.gz`)], { timeout: 35000 });
  131 |         const peak = Math.max(...samples.map((sample) => sample.rss));
  132 |         peaks[enabled ? "enabled" : "disabled"]!.push(peak);
  133 |         runs.push({ pair, mode, enabled, p95Ms: p95, browserVersion: browser.version(), rendered, viewport, interactionMs: interaction, rssSamples: samples, peakRssBytes: peak });
  134 |       } catch (error) {
  135 |         armError = error;
  136 |         throw error;
  137 |       } finally {
  138 |         sampling = false;
  139 |         await sampler;
  140 |         if (page && !page.isClosed()) {
  141 |           try { interaction = await page.evaluate(() => Reflect.get(window, "densityInputSamples") as number[] ?? []); }
  142 |           catch (error) { armError ??= error; }
  143 |         }
  144 |         const raw = testInfo.outputPath(`rss-${browserName}-${pair}-${enabled ? "enabled" : "disabled"}.json`);
  145 |         await writeFile(raw, JSON.stringify({ ...provenance, browserVersion: browser.version(), pair, mode, enabled, viewport, rendered, interaction, phases, armError: armError === undefined ? null : String(armError), samples, samplingError: samplingError === undefined ? null : String(samplingError), completedRuns: runs }, null, 2));
  146 |         await testInfo.attach("density-arm-raw", { path: raw, contentType: "application/json" });
  147 |         await browser.close();
  148 |         await server.close();
  149 |       }
  150 |       if (samplingError !== undefined) throw samplingError;
  151 |       if (armError !== undefined) throw armError;
  152 |     }
  153 |   }
  154 |   const p95 = Math.max(...p95PerArm);
  155 |   const increments = peaks.enabled!.map((peak, index) => peak - peaks.disabled![index]!);
  156 |   const report = {
  157 |     ...provenance,
  158 |     method: "One dedicated browser tree/tab per arm; 50ms sampled summed process RSS from launch through identical 40 Tab interactions. Two order-alternated pairs (state marks, LRU); worst per-arm p95 reported, never averaged across cases. Input keydown to visible outlined focus, bounded by second animation frame. Local diagnostic; manual and dedicated-host qualification remain separate.",
  159 |     p95Ms: p95, incrementalPeakRssBytes: increments, runs,
  160 |     timingPass: p95 <= 100, memoryPass: increments.every((increment) => increment <= 32 * 1024 * 1024),
  161 |   };
  162 |   const output = testInfo.outputPath(`density-${browserName}.json`);
  163 |   await writeFile(output, JSON.stringify(report, null, 2));
  164 |   await testInfo.attach("density-raw", { path: output, contentType: "application/json" });
  165 |   expect(p95).toBeLessThanOrEqual(100);
> 166 |   for (const increment of increments) expect(increment).toBeLessThanOrEqual(32 * 1024 * 1024);
      |                                                         ^ Error: expect(received).toBeLessThanOrEqual(expected)
  167 | });
  168 | 
```