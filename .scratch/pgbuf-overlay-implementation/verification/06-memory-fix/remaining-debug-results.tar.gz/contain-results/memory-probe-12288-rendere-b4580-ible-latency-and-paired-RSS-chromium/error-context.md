# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: memory-probe.spec.ts >> 12288 rendered page cells: per-browser visible latency and paired RSS
- Location: e2e/memory-probe.spec.ts:40:1

# Error details

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 33554432
Received:    41377792
```

# Test source

```ts
  66  |       let page: Page | undefined;
  67  |       let interaction: number[] = [];
  68  |       let rendered: { count: number; inViewport: number } | null = null;
  69  |       const sampler = (async () => {
  70  |         while (sampling) {
  71  |           samples.push({ elapsedMs: performance.now() - started, rss: await rssTree(pid) });
  72  |           await new Promise((resolve) => setTimeout(resolve, 50));
  73  |         }
  74  |       })().catch((error: unknown) => { samplingError = error; });
  75  |       try {
  76  |         page = await browser.newPage({ viewport });
  77  |         await page.route("**/app.css", async (route) => {
  78  |           const response = await route.fetch();
  79  |           await route.fulfill({ response, body: `${await response.text()}\n.sector-card:has(.runtime-resident) .sector-preview-pages { contain: paint; }\n` });
  80  |         });
  81  |         await page.goto("http://127.0.0.1:41742/volume/0", { waitUntil: "commit" });
  82  |         const cells = page.locator("[data-observation-page]");
  83  |         // Exercise real collection pagination; never inject a synthetic model.
  84  |         await loadVolumeCells(page, 12288);
  85  |         await page.evaluate(() => window.scrollTo(0, 0));
  86  |         rendered = await cells.evaluateAll((elements) => ({
  87  |           count: elements.filter((element) => element.getClientRects().length > 0).length,
  88  |           inViewport: elements.filter((element) => {
  89  |             const box = element.getBoundingClientRect();
  90  |             return box.top >= 0 && box.bottom <= innerHeight && box.left >= 0 && box.right <= innerWidth;
  91  |           }).length,
  92  |         }));
  93  |         expect(rendered.count).toBe(12288);
  94  | 
  95  |         if (enabled) {
  96  |           await page.locator(".observation-controls").getByRole("button", { name: "Enable observations" }).click();
  97  |           await expect(page.locator(".observation-detail[aria-label=\"Visible-page buffer observations\"]")).toContainText("Evaluated 512 / requested 512");
  98  |           await page.locator(".observation-controls").getByRole("combobox", { name: "Runtime color mode" }).selectOption(mode);
  99  |         }
  100 |         if (enabled) await expect(page.locator(".sector-card:has(.runtime-resident) .sector-preview-pages").first()).toHaveCSS("contain", "paint");
  101 |         // Same keyboard focus changes, viewport and DOM workload in both arms.
  102 |         // The second animation frame gives a conservative post-paint bound.
  103 |         await page.evaluate(() => {
  104 |           const samples: number[] = [];
  105 |           Object.assign(window, { densityInputSamples: samples });
  106 |           document.addEventListener("keydown", (event) => {
  107 |             if (event.key !== "Tab") return;
  108 |             const start = event.timeStamp;
  109 |             if (!Number.isFinite(start) || start < 0 || start > performance.now()) throw new Error("Invalid input timestamp clock");
  110 |             const before = document.activeElement;
  111 |             requestAnimationFrame(() => requestAnimationFrame(() => {
  112 |               const active = document.activeElement;
  113 |               if (active === before || !(active instanceof HTMLElement)) return;
  114 |               const rect = active.getBoundingClientRect();
  115 |               if (rect.width > 0 && rect.height > 0 && rect.bottom > 54 && rect.top < innerHeight && rect.right > 0 && rect.left < innerWidth && getComputedStyle(active).outlineStyle !== "none") samples.push(performance.now() - start);
  116 |             }));
  117 |           }, true);
  118 |         });
  119 |         await page.locator("#sector-0").focus();
  120 |         for (let index = 0; index < 40; index += 1) {
  121 |           await page.keyboard.press("Tab");
  122 |           await page.evaluate(() => new Promise<void>((resolve) => requestAnimationFrame(() => requestAnimationFrame(() => resolve()))));
  123 |         }
  124 |         interaction = await page.evaluate(() => Reflect.get(window, "densityInputSamples") as number[]);
  125 |         expect(interaction).toHaveLength(40);
  126 |         const sorted = [...interaction].sort((a, b) => a - b);
  127 |         const p95 = sorted[Math.ceil(sorted.length * 0.95) - 1]!;
  128 |         if (enabled) p95PerArm.push(p95);
  129 |         sampling = false;
  130 |         await sampler;
  131 |         const peak = Math.max(...samples.map((sample) => sample.rss));
  132 |         peaks[enabled ? "enabled" : "disabled"]!.push(peak);
  133 |         runs.push({ pair, mode, enabled, p95Ms: p95, browserVersion: browser.version(), rendered, viewport, interactionMs: interaction, rssSamples: samples, peakRssBytes: peak });
  134 |       } catch (error) {
  135 |         armError = error;
  136 |         throw error;
  137 |       } finally {
  138 |         sampling = false;
  139 |         await sampler;
  140 |         if (page && !page.isClosed()) {
  141 |           try { interaction = await page.evaluate(() => Reflect.get(window, "densityInputSamples") as number[] ?? []); }
  142 |           catch (error) { armError ??= error; }
  143 |         }
  144 |         const raw = testInfo.outputPath(`rss-${browserName}-${pair}-${enabled ? "enabled" : "disabled"}.json`);
  145 |         await writeFile(raw, JSON.stringify({ ...provenance, browserVersion: browser.version(), pair, mode, enabled, viewport, rendered, interaction, armError: armError === undefined ? null : String(armError), samples, samplingError: samplingError === undefined ? null : String(samplingError), completedRuns: runs }, null, 2));
  146 |         await testInfo.attach("density-arm-raw", { path: raw, contentType: "application/json" });
  147 |         await browser.close();
  148 |         await server.close();
  149 |       }
  150 |       if (samplingError !== undefined) throw samplingError;
  151 |       if (armError !== undefined) throw armError;
  152 |     }
  153 |   }
  154 |   const p95 = Math.max(...p95PerArm);
  155 |   const increments = peaks.enabled!.map((peak, index) => peak - peaks.disabled![index]!);
  156 |   const report = {
  157 |     ...provenance,
  158 |     method: "One dedicated browser tree/tab per arm; 50ms sampled summed process RSS from launch through identical 40 Tab interactions. Two order-alternated pairs (state marks, LRU); worst per-arm p95 reported, never averaged across cases. Input keydown to visible outlined focus, bounded by second animation frame. Local diagnostic; manual and dedicated-host qualification remain separate.",
  159 |     p95Ms: p95, incrementalPeakRssBytes: increments, runs,
  160 |     timingPass: p95 <= 100, memoryPass: increments.every((increment) => increment <= 32 * 1024 * 1024),
  161 |   };
  162 |   const output = testInfo.outputPath(`density-${browserName}.json`);
  163 |   await writeFile(output, JSON.stringify(report, null, 2));
  164 |   await testInfo.attach("density-raw", { path: output, contentType: "application/json" });
  165 |   expect(p95).toBeLessThanOrEqual(100);
> 166 |   for (const increment of increments) expect(increment).toBeLessThanOrEqual(32 * 1024 * 1024);
      |                                                         ^ Error: expect(received).toBeLessThanOrEqual(expected)
  167 | });
  168 | 
```