# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: observations.spec.ts >> cached unavailable metadata does not turn a pending first capture into page failures
- Location: e2e/observations.spec.ts:368:1

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  locator('.preview-page[data-runtime-state="unavailable"]')
Expected: 0
Received: 1536
Timeout:  5000ms

Call log:
  - Expect "toHaveCount" with timeout 5000ms
  - waiting for locator('.preview-page[data-runtime-state="unavailable"]')
    14 × locator resolved to 1536 elements
       - unexpected value "1536"

```

# Page snapshot

```yaml
- generic [ref=e2]:
  - banner [ref=e3]:
    - strong [ref=e4]: VOLMAP
    - generic [ref=e5]: snapshot aebacb8db657 · revision 0
    - generic [ref=e6]:
      - generic [ref=e7]: live · gen 0 · 6s ago · disk 19:54
      - button "Pause" [ref=e8] [cursor=pointer]
    - button "About & licenses" [ref=e9] [cursor=pointer]
    - generic [ref=e10]: success-limited
  - main [ref=e11]:
    - complementary [ref=e12]:
      - region "CUBRID page-buffer observation" [ref=e13]:
        - heading "CUBRID page-buffer observation" [level=2] [ref=e14]
        - button "Disable observations" [active] [pressed] [ref=e15] [cursor=pointer]
        - generic [ref=e16]:
          - text: Runtime color mode
          - combobox "Runtime color mode" [ref=e17]:
            - option "State marks" [selected]
            - option "LRU topology"
        - button "Refresh visible-page observations" [ref=e18] [cursor=pointer]
        - paragraph [ref=e19]: Visible-page observations available
        - paragraph [ref=e20]: "Observation source: active"
      - region "Visible-page buffer observations" [ref=e21]:
        - heading "Visible-page buffer observations" [level=2] [ref=e22]
        - paragraph [ref=e23]: Visible-page observations available
        - paragraph [ref=e24]: "512 admitted / 640 visible pages. Reduced admission: non-selected pages rotate at the 512-VPID limit. Other pages are not evaluated in this batch."
        - generic [ref=e25]:
          - paragraph [ref=e26]: "Shared lists: 2 · Private lists: 3. Indices are incarnation-local."
          - group [ref=e27]:
            - generic "Observed per-list counts in this batch only" [ref=e28] [cursor=pointer]
        - paragraph [ref=e29]: "Conservative age: 6 s · stale (2000 ms interval)"
        - paragraph [ref=e30]: Evaluated 512 / requested 512; producer scan complete.
        - paragraph [ref=e31]: 1 observed resident · 511 observed not resident · 0 unknown.
        - group [ref=e32]:
          - generic "Available page observations and capture limitations" [ref=e33] [cursor=pointer]
      - heading "Snapshot hierarchy" [level=2] [ref=e34]
      - button "volume 0 · 64 sectors" [ref=e36] [cursor=pointer]
    - generic [ref=e37]:
      - navigation "Inspection hierarchy" [ref=e38]:
        - generic [ref=e39]: Volume 0
      - generic [ref=e41]:
        - generic [ref=e42]:
          - generic [ref=e43]:
            - heading "Volume 0 · full map" [level=1] [ref=e44]
            - paragraph [ref=e45]: 64 sectors · 64 pages per sector · revision 0
          - generic "Page allocation and occupancy legend" [ref=e46]:
            - generic [ref=e47]: Unreserved
            - generic [ref=e49]: Reserved, unallocated
            - generic [ref=e51]: Occupied
            - generic [ref=e53]: Slotted free
            - generic [ref=e55]: System metadata
            - generic [ref=e57]: Finding outline
        - region "Runtime overlay legend" [ref=e59]:
          - paragraph [ref=e60]: "Storage colors retained. ◉ cyan inset: observed resident · D amber corner: dirty · F static magenta edge: flushing."
          - paragraph [ref=e61]: "○ observed not resident · ? unknown / not evaluated · ≠ duplicate ambiguity. Pages outside this batch have no runtime glyph. No usable source or expired evidence: storage colors only, no runtime marks. Sampled states, not events or durability evidence."
          - paragraph [ref=e62]: "Conservative age: 6 s · stale (2000 ms interval)"
          - paragraph [ref=e63]: "Source: active · Adopting observations · Visible-page observations available"
        - generic "Full volume sector map" [ref=e64]:
          - 'button "Sector 0, reserved, 64 pages, buffer observations: 63 ○ Observed not resident; 1 observed resident" [ref=e65] [cursor=pointer]':
            - generic [ref=e66]:
              - strong [ref=e67]: Sector 0
              - generic [ref=e68]: reserved
            - generic [ref=e69]:
              - generic [ref=e70]: ○
              - generic [ref=e71]: ○
              - generic [ref=e72]: ○
              - generic [ref=e73]: ○
              - generic [ref=e74]: ○
              - generic [ref=e75]: ○
              - generic [ref=e76]: ○
              - generic [ref=e77]: ○
              - generic [ref=e78]: ○
              - generic [ref=e79]: ○
              - generic [ref=e80]: ◉D
              - generic [ref=e81]: ○
              - generic [ref=e82]: ○
              - generic [ref=e83]: ○
              - generic [ref=e84]: ○
              - generic [ref=e85]: ○
              - generic [ref=e86]: ○
              - generic [ref=e87]: ○
              - generic [ref=e88]: ○
              - generic [ref=e89]: ○
              - generic [ref=e90]: ○
              - generic [ref=e91]: ○
              - generic [ref=e92]: ○
              - generic [ref=e93]: ○
              - generic [ref=e94]: ○
              - generic [ref=e95]: ○
              - generic [ref=e96]: ○
              - generic [ref=e97]: ○
              - generic [ref=e98]: ○
              - generic [ref=e99]: ○
              - generic [ref=e100]: ○
              - generic [ref=e101]: ○
              - generic [ref=e102]: ○
              - generic [ref=e103]: ○
              - generic [ref=e104]: ○
              - generic [ref=e105]: ○
              - generic [ref=e106]: ○
              - generic [ref=e107]: ○
              - generic [ref=e108]: ○
              - generic [ref=e109]: ○
              - generic [ref=e110]: ○
              - generic [ref=e111]: ○
              - generic [ref=e112]: ○
              - generic [ref=e113]: ○
              - generic [ref=e114]: ○
              - generic [ref=e115]: ○
              - generic [ref=e116]: ○
              - generic [ref=e117]: ○
              - generic [ref=e118]: ○
              - generic [ref=e119]: ○
              - generic [ref=e120]: ○
              - generic [ref=e121]: ○
              - generic [ref=e122]: ○
              - generic [ref=e123]: ○
              - generic [ref=e124]: ○
              - generic [ref=e125]: ○
              - generic [ref=e126]: ○
              - generic [ref=e127]: ○
              - generic [ref=e128]: ○
              - generic [ref=e129]: ○
              - generic [ref=e130]: ○
              - generic [ref=e131]: ○
              - generic [ref=e132]: ○
              - generic [ref=e133]: ○
          - 'button "Sector 1, unreserved, 64 pages, buffer observations: 64 ○ Observed not resident" [ref=e134] [cursor=pointer]':
            - generic [ref=e135]:
              - strong [ref=e136]: Sector 1
              - generic [ref=e137]: unreserved
            - generic [ref=e138]:
              - generic [ref=e139]: ○
              - generic [ref=e140]: ○
              - generic [ref=e141]: ○
              - generic [ref=e142]: ○
              - generic [ref=e143]: ○
              - generic [ref=e144]: ○
              - generic [ref=e145]: ○
              - generic [ref=e146]: ○
              - generic [ref=e147]: ○
              - generic [ref=e148]: ○
              - generic [ref=e149]: ○
              - generic [ref=e150]: ○
              - generic [ref=e151]: ○
              - generic [ref=e152]: ○
              - generic [ref=e153]: ○
              - generic [ref=e154]: ○
              - generic [ref=e155]: ○
              - generic [ref=e156]: ○
              - generic [ref=e157]: ○
              - generic [ref=e158]: ○
              - generic [ref=e159]: ○
              - generic [ref=e160]: ○
              - generic [ref=e161]: ○
              - generic [ref=e162]: ○
              - generic [ref=e163]: ○
              - generic [ref=e164]: ○
              - generic [ref=e165]: ○
              - generic [ref=e166]: ○
              - generic [ref=e167]: ○
              - generic [ref=e168]: ○
              - generic [ref=e169]: ○
              - generic [ref=e170]: ○
              - generic [ref=e171]: ○
              - generic [ref=e172]: ○
              - generic [ref=e173]: ○
              - generic [ref=e174]: ○
              - generic [ref=e175]: ○
              - generic [ref=e176]: ○
              - generic [ref=e177]: ○
              - generic [ref=e178]: ○
              - generic [ref=e179]: ○
              - generic [ref=e180]: ○
              - generic [ref=e181]: ○
              - generic [ref=e182]: ○
              - generic [ref=e183]: ○
              - generic [ref=e184]: ○
              - generic [ref=e185]: ○
              - generic [ref=e186]: ○
              - generic [ref=e187]: ○
              - generic [ref=e188]: ○
              - generic [ref=e189]: ○
              - generic [ref=e190]: ○
              - generic [ref=e191]: ○
              - generic [ref=e192]: ○
              - generic [ref=e193]: ○
              - generic [ref=e194]: ○
              - generic [ref=e195]: ○
              - generic [ref=e196]: ○
              - generic [ref=e197]: ○
              - generic [ref=e198]: ○
              - generic [ref=e199]: ○
              - generic [ref=e200]: ○
              - generic [ref=e201]: ○
              - generic [ref=e202]: ○
          - 'button "Sector 2, unreserved, 64 pages, buffer observations: 64 ○ Observed not resident" [ref=e203] [cursor=pointer]':
            - generic [ref=e204]:
              - strong [ref=e205]: Sector 2
              - generic [ref=e206]: unreserved
            - generic [ref=e207]:
              - generic [ref=e208]: ○
              - generic [ref=e209]: ○
              - generic [ref=e210]: ○
              - generic [ref=e211]: ○
              - generic [ref=e212]: ○
              - generic [ref=e213]: ○
              - generic [ref=e214]: ○
              - generic [ref=e215]: ○
              - generic [ref=e216]: ○
              - generic [ref=e217]: ○
              - generic [ref=e218]: ○
              - generic [ref=e219]: ○
              - generic [ref=e220]: ○
              - generic [ref=e221]: ○
              - generic [ref=e222]: ○
              - generic [ref=e223]: ○
              - generic [ref=e224]: ○
              - generic [ref=e225]: ○
              - generic [ref=e226]: ○
              - generic [ref=e227]: ○
              - generic [ref=e228]: ○
              - generic [ref=e229]: ○
              - generic [ref=e230]: ○
              - generic [ref=e231]: ○
              - generic [ref=e232]: ○
              - generic [ref=e233]: ○
              - generic [ref=e234]: ○
              - generic [ref=e235]: ○
              - generic [ref=e236]: ○
              - generic [ref=e237]: ○
              - generic [ref=e238]: ○
              - generic [ref=e239]: ○
              - generic [ref=e240]: ○
              - generic [ref=e241]: ○
              - generic [ref=e242]: ○
              - generic [ref=e243]: ○
              - generic [ref=e244]: ○
              - generic [ref=e245]: ○
              - generic [ref=e246]: ○
              - generic [ref=e247]: ○
              - generic [ref=e248]: ○
              - generic [ref=e249]: ○
              - generic [ref=e250]: ○
              - generic [ref=e251]: ○
              - generic [ref=e252]: ○
              - generic [ref=e253]: ○
              - generic [ref=e254]: ○
              - generic [ref=e255]: ○
              - generic [ref=e256]: ○
              - generic [ref=e257]: ○
              - generic [ref=e258]: ○
              - generic [ref=e259]: ○
              - generic [ref=e260]: ○
              - generic [ref=e261]: ○
              - generic [ref=e262]: ○
              - generic [ref=e263]: ○
              - generic [ref=e264]: ○
              - generic [ref=e265]: ○
              - generic [ref=e266]: ○
              - generic [ref=e267]: ○
              - generic [ref=e268]: ○
              - generic [ref=e269]: ○
              - generic [ref=e270]: ○
              - generic [ref=e271]: ○
          - 'button "Sector 3, unreserved, 64 pages, buffer observations: 64 ○ Observed not resident" [ref=e272] [cursor=pointer]':
            - generic [ref=e273]:
              - strong [ref=e274]: Sector 3
              - generic [ref=e275]: unreserved
            - generic [ref=e276]:
              - generic [ref=e277]: ○
              - generic [ref=e278]: ○
              - generic [ref=e279]: ○
              - generic [ref=e280]: ○
              - generic [ref=e281]: ○
              - generic [ref=e282]: ○
              - generic [ref=e283]: ○
              - generic [ref=e284]: ○
              - generic [ref=e285]: ○
              - generic [ref=e286]: ○
              - generic [ref=e287]: ○
              - generic [ref=e288]: ○
              - generic [ref=e289]: ○
              - generic [ref=e290]: ○
              - generic [ref=e291]: ○
              - generic [ref=e292]: ○
              - generic [ref=e293]: ○
              - generic [ref=e294]: ○
              - generic [ref=e295]: ○
              - generic [ref=e296]: ○
              - generic [ref=e297]: ○
              - generic [ref=e298]: ○
              - generic [ref=e299]: ○
              - generic [ref=e300]: ○
              - generic [ref=e301]: ○
              - generic [ref=e302]: ○
              - generic [ref=e303]: ○
              - generic [ref=e304]: ○
              - generic [ref=e305]: ○
              - generic [ref=e306]: ○
              - generic [ref=e307]: ○
              - generic [ref=e308]: ○
              - generic [ref=e309]: ○
              - generic [ref=e310]: ○
              - generic [ref=e311]: ○
              - generic [ref=e312]: ○
              - generic [ref=e313]: ○
              - generic [ref=e314]: ○
              - generic [ref=e315]: ○
              - generic [ref=e316]: ○
              - generic [ref=e317]: ○
              - generic [ref=e318]: ○
              - generic [ref=e319]: ○
              - generic [ref=e320]: ○
              - generic [ref=e321]: ○
              - generic [ref=e322]: ○
              - generic [ref=e323]: ○
              - generic [ref=e324]: ○
              - generic [ref=e325]: ○
              - generic [ref=e326]: ○
              - generic [ref=e327]: ○
              - generic [ref=e328]: ○
              - generic [ref=e329]: ○
              - generic [ref=e330]: ○
              - generic [ref=e331]: ○
              - generic [ref=e332]: ○
              - generic [ref=e333]: ○
              - generic [ref=e334]: ○
              - generic [ref=e335]: ○
              - generic [ref=e336]: ○
              - generic [ref=e337]: ○
              - generic [ref=e338]: ○
              - generic [ref=e339]: ○
              - generic [ref=e340]: ○
          - 'button "Sector 4, unreserved, 64 pages, buffer observations: 64 ○ Observed not resident" [ref=e341] [cursor=pointer]':
            - generic [ref=e342]:
              - strong [ref=e343]: Sector 4
              - generic [ref=e344]: unreserved
            - generic [ref=e345]:
              - generic [ref=e346]: ○
              - generic [ref=e347]: ○
              - generic [ref=e348]: ○
              - generic [ref=e349]: ○
              - generic [ref=e350]: ○
              - generic [ref=e351]: ○
              - generic [ref=e352]: ○
              - generic [ref=e353]: ○
              - generic [ref=e354]: ○
              - generic [ref=e355]: ○
              - generic [ref=e356]: ○
              - generic [ref=e357]: ○
              - generic [ref=e358]: ○
              - generic [ref=e359]: ○
              - generic [ref=e360]: ○
              - generic [ref=e361]: ○
              - generic [ref=e362]: ○
              - generic [ref=e363]: ○
              - generic [ref=e364]: ○
              - generic [ref=e365]: ○
              - generic [ref=e366]: ○
              - generic [ref=e367]: ○
              - generic [ref=e368]: ○
              - generic [ref=e369]: ○
              - generic [ref=e370]: ○
              - generic [ref=e371]: ○
              - generic [ref=e372]: ○
              - generic [ref=e373]: ○
              - generic [ref=e374]: ○
              - generic [ref=e375]: ○
              - generic [ref=e376]: ○
              - generic [ref=e377]: ○
              - generic [ref=e378]: ○
              - generic [ref=e379]: ○
              - generic [ref=e380]: ○
              - generic [ref=e381]: ○
              - generic [ref=e382]: ○
              - generic [ref=e383]: ○
              - generic [ref=e384]: ○
              - generic [ref=e385]: ○
              - generic [ref=e386]: ○
              - generic [ref=e387]: ○
              - generic [ref=e388]: ○
              - generic [ref=e389]: ○
              - generic [ref=e390]: ○
              - generic [ref=e391]: ○
              - generic [ref=e392]: ○
              - generic [ref=e393]: ○
              - generic [ref=e394]: ○
              - generic [ref=e395]: ○
              - generic [ref=e396]: ○
              - generic [ref=e397]: ○
              - generic [ref=e398]: ○
              - generic [ref=e399]: ○
              - generic [ref=e400]: ○
              - generic [ref=e401]: ○
              - generic [ref=e402]: ○
              - generic [ref=e403]: ○
              - generic [ref=e404]: ○
              - generic [ref=e405]: ○
              - generic [ref=e406]: ○
              - generic [ref=e407]: ○
              - generic [ref=e408]: ○
              - generic [ref=e409]: ○
          - 'button "Sector 5, unreserved, 64 pages, buffer observations: 64 ○ Observed not resident" [ref=e410] [cursor=pointer]':
            - generic [ref=e411]:
              - strong [ref=e412]: Sector 5
              - generic [ref=e413]: unreserved
            - generic [ref=e414]:
              - generic [ref=e415]: ○
              - generic [ref=e416]: ○
              - generic [ref=e417]: ○
              - generic [ref=e418]: ○
              - generic [ref=e419]: ○
              - generic [ref=e420]: ○
              - generic [ref=e421]: ○
              - generic [ref=e422]: ○
              - generic [ref=e423]: ○
              - generic [ref=e424]: ○
              - generic [ref=e425]: ○
              - generic [ref=e426]: ○
              - generic [ref=e427]: ○
              - generic [ref=e428]: ○
              - generic [ref=e429]: ○
              - generic [ref=e430]: ○
              - generic [ref=e431]: ○
              - generic [ref=e432]: ○
              - generic [ref=e433]: ○
              - generic [ref=e434]: ○
              - generic [ref=e435]: ○
              - generic [ref=e436]: ○
              - generic [ref=e437]: ○
              - generic [ref=e438]: ○
              - generic [ref=e439]: ○
              - generic [ref=e440]: ○
              - generic [ref=e441]: ○
              - generic [ref=e442]: ○
              - generic [ref=e443]: ○
              - generic [ref=e444]: ○
              - generic [ref=e445]: ○
              - generic [ref=e446]: ○
              - generic [ref=e447]: ○
              - generic [ref=e448]: ○
              - generic [ref=e449]: ○
              - generic [ref=e450]: ○
              - generic [ref=e451]: ○
              - generic [ref=e452]: ○
              - generic [ref=e453]: ○
              - generic [ref=e454]: ○
              - generic [ref=e455]: ○
              - generic [ref=e456]: ○
              - generic [ref=e457]: ○
              - generic [ref=e458]: ○
              - generic [ref=e459]: ○
              - generic [ref=e460]: ○
              - generic [ref=e461]: ○
              - generic [ref=e462]: ○
              - generic [ref=e463]: ○
              - generic [ref=e464]: ○
              - generic [ref=e465]: ○
              - generic [ref=e466]: ○
              - generic [ref=e467]: ○
              - generic [ref=e468]: ○
              - generic [ref=e469]: ○
              - generic [ref=e470]: ○
              - generic [ref=e471]: ○
              - generic [ref=e472]: ○
              - generic [ref=e473]: ○
              - generic [ref=e474]: ○
              - generic [ref=e475]: ○
              - generic [ref=e476]: ○
              - generic [ref=e477]: ○
              - generic [ref=e478]: ○
          - 'button "Sector 6, unreserved, 64 pages, buffer observations: 64 ○ Observed not resident" [ref=e479] [cursor=pointer]':
            - generic [ref=e480]:
              - strong [ref=e481]: Sector 6
              - generic [ref=e482]: unreserved
            - generic [ref=e483]:
              - generic [ref=e484]: ○
              - generic [ref=e485]: ○
              - generic [ref=e486]: ○
              - generic [ref=e487]: ○
              - generic [ref=e488]: ○
              - generic [ref=e489]: ○
              - generic [ref=e490]: ○
              - generic [ref=e491]: ○
              - generic [ref=e492]: ○
              - generic [ref=e493]: ○
              - generic [ref=e494]: ○
              - generic [ref=e495]: ○
              - generic [ref=e496]: ○
              - generic [ref=e497]: ○
              - generic [ref=e498]: ○
              - generic [ref=e499]: ○
              - generic [ref=e500]: ○
              - generic [ref=e501]: ○
              - generic [ref=e502]: ○
              - generic [ref=e503]: ○
              - generic [ref=e504]: ○
              - generic [ref=e505]: ○
              - generic [ref=e506]: ○
              - generic [ref=e507]: ○
              - generic [ref=e508]: ○
              - generic [ref=e509]: ○
              - generic [ref=e510]: ○
              - generic [ref=e511]: ○
              - generic [ref=e512]: ○
              - generic [ref=e513]: ○
              - generic [ref=e514]: ○
              - generic [ref=e515]: ○
              - generic [ref=e516]: ○
              - generic [ref=e517]: ○
              - generic [ref=e518]: ○
              - generic [ref=e519]: ○
              - generic [ref=e520]: ○
              - generic [ref=e521]: ○
              - generic [ref=e522]: ○
              - generic [ref=e523]: ○
              - generic [ref=e524]: ○
              - generic [ref=e525]: ○
              - generic [ref=e526]: ○
              - generic [ref=e527]: ○
              - generic [ref=e528]: ○
              - generic [ref=e529]: ○
              - generic [ref=e530]: ○
              - generic [ref=e531]: ○
              - generic [ref=e532]: ○
              - generic [ref=e533]: ○
              - generic [ref=e534]: ○
              - generic [ref=e535]: ○
              - generic [ref=e536]: ○
              - generic [ref=e537]: ○
              - generic [ref=e538]: ○
              - generic [ref=e539]: ○
              - generic [ref=e540]: ○
              - generic [ref=e541]: ○
              - generic [ref=e542]: ○
              - generic [ref=e543]: ○
              - generic [ref=e544]: ○
              - generic [ref=e545]: ○
              - generic [ref=e546]: ○
              - generic [ref=e547]: ○
          - 'button "Sector 7, unreserved, 64 pages, buffer observations: 64 ○ Observed not resident" [ref=e548] [cursor=pointer]':
            - generic [ref=e549]:
              - strong [ref=e550]: Sector 7
              - generic [ref=e551]: unreserved
            - generic [ref=e552]:
              - generic [ref=e553]: ○
              - generic [ref=e554]: ○
              - generic [ref=e555]: ○
              - generic [ref=e556]: ○
              - generic [ref=e557]: ○
              - generic [ref=e558]: ○
              - generic [ref=e559]: ○
              - generic [ref=e560]: ○
              - generic [ref=e561]: ○
              - generic [ref=e562]: ○
              - generic [ref=e563]: ○
              - generic [ref=e564]: ○
              - generic [ref=e565]: ○
              - generic [ref=e566]: ○
              - generic [ref=e567]: ○
              - generic [ref=e568]: ○
              - generic [ref=e569]: ○
              - generic [ref=e570]: ○
              - generic [ref=e571]: ○
              - generic [ref=e572]: ○
              - generic [ref=e573]: ○
              - generic [ref=e574]: ○
              - generic [ref=e575]: ○
              - generic [ref=e576]: ○
              - generic [ref=e577]: ○
              - generic [ref=e578]: ○
              - generic [ref=e579]: ○
              - generic [ref=e580]: ○
              - generic [ref=e581]: ○
              - generic [ref=e582]: ○
              - generic [ref=e583]: ○
              - generic [ref=e584]: ○
              - generic [ref=e585]: ○
              - generic [ref=e586]: ○
              - generic [ref=e587]: ○
              - generic [ref=e588]: ○
              - generic [ref=e589]: ○
              - generic [ref=e590]: ○
              - generic [ref=e591]: ○
              - generic [ref=e592]: ○
              - generic [ref=e593]: ○
              - generic [ref=e594]: ○
              - generic [ref=e595]: ○
              - generic [ref=e596]: ○
              - generic [ref=e597]: ○
              - generic [ref=e598]: ○
              - generic [ref=e599]: ○
              - generic [ref=e600]: ○
              - generic [ref=e601]: ○
              - generic [ref=e602]: ○
              - generic [ref=e603]: ○
              - generic [ref=e604]: ○
              - generic [ref=e605]: ○
              - generic [ref=e606]: ○
              - generic [ref=e607]: ○
              - generic [ref=e608]: ○
              - generic [ref=e609]: ○
              - generic [ref=e610]: ○
              - generic [ref=e611]: ○
              - generic [ref=e612]: ○
              - generic [ref=e613]: ○
              - generic [ref=e614]: ○
              - generic [ref=e615]: ○
              - generic [ref=e616]: ○
          - 'button "Sector 8, unreserved, 64 pages, buffer observations: 64 ? Not evaluated" [ref=e617] [cursor=pointer]':
            - generic [ref=e618]:
              - strong [ref=e619]: Sector 8
              - generic [ref=e620]: unreserved
          - 'button "Sector 9, unreserved, 64 pages, buffer observations: 64 ? Not evaluated" [ref=e686] [cursor=pointer]':
            - generic [ref=e687]:
              - strong [ref=e688]: Sector 9
              - generic [ref=e689]: unreserved
          - 'button "Sector 10, unreserved, 64 pages, buffer observations: 64 ? Not evaluated" [ref=e755] [cursor=pointer]':
            - generic [ref=e756]:
              - strong [ref=e757]: Sector 10
              - generic [ref=e758]: unreserved
          - 'button "Sector 11, unreserved, 64 pages, buffer observations: 64 ? Not evaluated" [ref=e824] [cursor=pointer]':
            - generic [ref=e825]:
              - strong [ref=e826]: Sector 11
              - generic [ref=e827]: unreserved
          - 'button "Sector 12, unreserved, 64 pages, buffer observations: 64 ? Not evaluated" [ref=e893] [cursor=pointer]':
            - generic [ref=e894]:
              - strong [ref=e895]: Sector 12
              - generic [ref=e896]: unreserved
          - 'button "Sector 13, unreserved, 64 pages, buffer observations: 64 ? Not evaluated" [ref=e962] [cursor=pointer]':
            - generic [ref=e963]:
              - strong [ref=e964]: Sector 13
              - generic [ref=e965]: unreserved
          - 'button "Sector 14, unreserved, 64 pages, buffer observations: 64 ? Not evaluated" [ref=e1031] [cursor=pointer]':
            - generic [ref=e1032]:
              - strong [ref=e1033]: Sector 14
              - generic [ref=e1034]: unreserved
          - 'button "Sector 15, unreserved, 64 pages, buffer observations: 64 ? Not evaluated" [ref=e1100] [cursor=pointer]':
            - generic [ref=e1101]:
              - strong [ref=e1102]: Sector 15
              - generic [ref=e1103]: unreserved
          - 'button "Sector 16, unreserved, 64 pages, buffer observations: 64 ? Not evaluated" [ref=e1169] [cursor=pointer]':
            - generic [ref=e1170]:
              - strong [ref=e1171]: Sector 16
              - generic [ref=e1172]: unreserved
          - 'button "Sector 17, unreserved, 64 pages, buffer observations: 64 ? Not evaluated" [ref=e1238] [cursor=pointer]':
            - generic [ref=e1239]:
              - strong [ref=e1240]: Sector 17
              - generic [ref=e1241]: unreserved
          - 'button "Sector 18, unreserved, 64 pages, buffer observations: 64 ? Not evaluated" [ref=e1307] [cursor=pointer]':
            - generic [ref=e1308]:
              - strong [ref=e1309]: Sector 18
              - generic [ref=e1310]: unreserved
          - 'button "Sector 19, unreserved, 64 pages, buffer observations: 64 ? Not evaluated" [ref=e1376] [cursor=pointer]':
            - generic [ref=e1377]:
              - strong [ref=e1378]: Sector 19
              - generic [ref=e1379]: unreserved
          - 'button "Sector 20, unreserved, 64 pages, buffer observations: 64 ? Not evaluated" [ref=e1445] [cursor=pointer]':
            - generic [ref=e1446]:
              - strong [ref=e1447]: Sector 20
              - generic [ref=e1448]: unreserved
          - 'button "Sector 21, unreserved, 64 pages, buffer observations: 64 ? Not evaluated" [ref=e1514] [cursor=pointer]':
            - generic [ref=e1515]:
              - strong [ref=e1516]: Sector 21
              - generic [ref=e1517]: unreserved
          - 'button "Sector 22, unreserved, 64 pages, buffer observations: 64 ? Not evaluated" [ref=e1583] [cursor=pointer]':
            - generic [ref=e1584]:
              - strong [ref=e1585]: Sector 22
              - generic [ref=e1586]: unreserved
          - 'button "Sector 23, unreserved, 64 pages, buffer observations: 64 ? Not evaluated" [ref=e1652] [cursor=pointer]':
            - generic [ref=e1653]:
              - strong [ref=e1654]: Sector 23
              - generic [ref=e1655]: unreserved
        - status [ref=e1721]: Showing 24 of 64 sectors · scroll to continue
        - button "Load more sectors" [ref=e1723] [cursor=pointer]
```

# Test source

```ts
  289 |     expect(await cell(10).evaluate((element) => getComputedStyle(element, "::before").borderStyle)).toBe("dashed");
  290 |     await page.emulateMedia({ forcedColors: "none" });
  291 |     await page.screenshot({ path: `../.scratch/pgbuf-overlay-implementation/verification/05-${scale.split("/")[0]}-${browserName}.png` });
  292 |     await page.clock.runFor(31000);
  293 |     await expect(cell(10)).toHaveAttribute("data-runtime-state", "expired");
  294 |     await expect(cell(10)).not.toHaveClass(/runtime-resident/);
  295 |     await expect(coverage).not.toContainText("private list 1: 1");
  296 |     complete = true;
  297 |     await page.getByRole("button", { name: "Resume", exact: true }).click();
  298 |     await expect(cell(10)).toHaveAttribute("title", /Observed not resident/);
  299 |     await expect(cell(10)).not.toHaveClass(/runtime-resident/);
  300 |     await expect(coverage).toContainText("No exact list membership observed");
  301 |     await expect(page.locator("#crumb")).toHaveText(revision);
  302 |   });
  303 | }
  304 | 
  305 | test("selected detail exposes exact membership and null meanings; inconsistent topology is refused", async ({ page }) => {
  306 |   let variant = "private";
  307 |   await page.route("**/runtime/page-buffer/observe", async (route) => {
  308 |     const response = await route.fetch();
  309 |     const body = await response.json();
  310 |     const row = body.observations[0];
  311 |     if (row.evidence) {
  312 |       row.evidence.lru_list_kind = variant === "out-of-range" ? "private" : variant;
  313 |       row.evidence.lru_list_index = variant === "private" ? 1 : variant === "out-of-range" ? 3 : null;
  314 |       row.evidence.lru_zone = variant === "none" ? "void" : "lru2";
  315 |     }
  316 |     await route.fulfill({ response, json: body });
  317 |   });
  318 |   await page.goto("http://127.0.0.1:41741/page/0/10", { waitUntil: "commit" });
  319 |   await page.getByRole("button", { name: "Enable observations" }).click();
  320 |   const detail = page.getByRole("region", { name: "Selected-page buffer observation" });
  321 |   await expect(detail).toContainText("Observed resident");
  322 |   await expect(detail).toContainText("lru list index1");
  323 |   await expect(detail).toContainText("incarnation-local");
  324 |   for (const kind of ["none", "invalid"]) {
  325 |     variant = kind;
  326 |     await expect(detail).toContainText(`lru list kind${kind}`);
  327 |     await expect(detail).toContainText("lru list indexnone / not applicable");
  328 |   }
  329 |   variant = "out-of-range";
  330 |   await expect(page.getByRole("region", { name: "CUBRID page-buffer observation" })).toContainText("Incompatible observation response");
  331 |   await expect(detail).not.toContainText("Observed resident");
  332 | });
  333 | 
  334 | for (const scale of ["volume/0", "sector/0/0"]) {
  335 |   test(`${scale} source failure hides marks and paused incarnation change revokes every list`, async ({ page }) => {
  336 |     await page.clock.install();
  337 |     await page.goto(`http://127.0.0.1:41741/${scale}`, { waitUntil: "commit" });
  338 |     await page.getByRole("button", { name: "Enable observations" }).click();
  339 |     const cell = page.locator('[data-observation-page="0:10"]');
  340 |     await expect(cell).toHaveAttribute("data-runtime-state", "resident");
  341 |     await page.getByRole("button", { name: "Pause", exact: true }).click();
  342 |     await page.route("**/runtime/capabilities", async (route) => {
  343 |       const response = await route.fetch();
  344 |       const body = await response.json();
  345 |       body.incarnation_binding = "a-new-server-incarnation";
  346 |       await route.fulfill({ response, json: body });
  347 |     });
  348 |     await page.clock.runFor(5000);
  349 |     const source = page.getByRole("region", { name: "CUBRID page-buffer observation" });
  350 |     await expect(source).toContainText("incarnation-changed");
  351 |     await expect(cell).not.toHaveClass(/runtime-resident/);
  352 |     await expect(page.getByRole("region", { name: "Visible-page buffer observations" })).not.toContainText("Shared lists:");
  353 |     await page.unroute("**/runtime/capabilities");
  354 |     await page.getByRole("button", { name: "Resume", exact: true }).click();
  355 |     await page.getByRole("button", { name: "Refresh visible-page observations" }).click();
  356 |     await expect(cell).toHaveAttribute("data-runtime-state", "resident");
  357 |     await page.route("**/runtime/page-buffer/observe", (route) => route.abort("failed"));
  358 |     await page.clock.runFor(2000);
  359 |     await expect(source).toContainText("Observation source: unavailable");
  360 |     await expect(cell).toHaveAttribute("data-runtime-state", "unavailable");
  361 |     await expect(cell).not.toHaveClass(/runtime-resident/);
  362 |     await expect(cell).not.toHaveAttribute("title", /Observed not resident/);
  363 |     await expect(page.getByRole("region", { name: "Runtime overlay legend" })).toContainText("Source: unavailable");
  364 |     await expect(page.getByRole("heading", { level: 1 })).toContainText(scale.startsWith("volume") ? "Volume 0" : "Sector 0");
  365 |   });
  366 | }
  367 | 
  368 | test("cached unavailable metadata does not turn a pending first capture into page failures", async ({ page }) => {
  369 |   await page.route("**/runtime/capabilities", (route) => route.fulfill({
  370 |     status: 200, headers: { "cache-control": "no-store" },
  371 |     json: { schema: "volmap.runtime", schema_version: 1, source: "cubrid-page-buffer-observation",
  372 |       state: "unavailable", verification: "unverified", reason: "observation-expired",
  373 |       incarnation_binding: null, capture_identity: null, revision: "0" },
  374 |   }));
  375 |   let releaseCapture!: () => void;
  376 |   const captureGate = new Promise<void>((resolve) => { releaseCapture = resolve; });
  377 |   await page.route("**/runtime/page-buffer/observe", async (route) => {
  378 |     await captureGate;
  379 |     await route.continue();
  380 |   });
  381 |   await page.goto("http://127.0.0.1:41741/volume/0", { waitUntil: "commit" });
  382 |   const source = page.getByRole("region", { name: "CUBRID page-buffer observation" });
  383 |   await expect(source).toContainText("Observation source: unavailable");
  384 |   const pending = page.waitForRequest("**/runtime/page-buffer/observe");
  385 |   await source.getByRole("button", { name: "Enable observations" }).click();
  386 |   await pending;
  387 |   try {
  388 |     await expect(source).toContainText("Observing visible pages");
> 389 |     await expect(page.locator('.preview-page[data-runtime-state="unavailable"]')).toHaveCount(0);
      |                                                                                   ^ Error: expect(locator).toHaveCount(expected) failed
  390 |     await expect(page.locator(".sector-card").first()).toHaveAccessibleName(/source unavailable/);
  391 |   } finally {
  392 |     releaseCapture();
  393 |   }
  394 |   await expect(source).toContainText("Observation source: active");
  395 |   await expect(page.locator('.preview-page[data-runtime-state="resident"]').first()).toHaveAttribute("title", /Observed resident/);
  396 |   await page.route("**/runtime/page-buffer/observe", (route) => route.fulfill({ status: 503, json: { code: "runtime-unavailable" } }));
  397 |   await source.getByRole("button", { name: "Refresh visible-page observations" }).click();
  398 |   await expect(source).toContainText("Observation source: unavailable");
  399 |   await expect(page.locator('.preview-page[data-runtime-state="unavailable"]').first()).toHaveAttribute("title", /No usable observation/);
  400 | });
  401 | 
```