# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: memory-probe.spec.ts >> 12288 rendered page cells: per-browser visible latency and paired RSS
- Location: e2e/memory-probe.spec.ts:40:1

# Error details

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 33554432
Received:    52080640
```

# Test source

```ts
  69  |       let interaction: number[] = [];
  70  |       let rendered: { count: number; inViewport: number } | null = null;
  71  |       const sampler = (async () => {
  72  |         while (sampling) {
  73  |           samples.push({ elapsedMs: performance.now() - started, rss: await rssTree(pid) });
  74  |           await new Promise((resolve) => setTimeout(resolve, 50));
  75  |         }
  76  |       })().catch((error: unknown) => { samplingError = error; });
  77  |       try {
  78  |         page = await browser.newPage({ viewport });
  79  |         await page.route("**/app.css", async (route) => {
  80  |           const response = await route.fetch();
  81  |           await route.fulfill({ response, body: `${await response.text()}\n.page.runtime-resident { will-change: transform; }\n` });
  82  |         });
  83  |         await page.route("**/app.js", (route) => route.fulfill({ contentType: "application/javascript", body: candidateJavascript }));
  84  |         await page.goto("http://127.0.0.1:41742/volume/0", { waitUntil: "commit" });
  85  |         const cells = page.locator("[data-observation-page]");
  86  |         // Exercise real collection pagination; never inject a synthetic model.
  87  |         await loadVolumeCells(page, 12288);
  88  |         await page.evaluate(() => window.scrollTo(0, 0));
  89  |         rendered = await cells.evaluateAll((elements) => ({
  90  |           count: elements.filter((element) => element.getClientRects().length > 0).length,
  91  |           inViewport: elements.filter((element) => {
  92  |             const box = element.getBoundingClientRect();
  93  |             return box.top >= 0 && box.bottom <= innerHeight && box.left >= 0 && box.right <= innerWidth;
  94  |           }).length,
  95  |         }));
  96  |         expect(rendered.count).toBe(12288);
  97  | 
  98  |         if (enabled) {
  99  |           await page.locator(".observation-controls").getByRole("button", { name: "Enable observations" }).click();
  100 |           await expect(page.locator(".observation-detail[aria-label=\"Visible-page buffer observations\"]")).toContainText("Evaluated 512 / requested 512");
  101 |           await page.locator(".observation-controls").getByRole("combobox", { name: "Runtime color mode" }).selectOption(mode);
  102 |         }
  103 |         if (enabled) await expect(page.locator(".runtime-resident").first()).toHaveCSS("will-change", "transform");
  104 |         // Same keyboard focus changes, viewport and DOM workload in both arms.
  105 |         // The second animation frame gives a conservative post-paint bound.
  106 |         await page.evaluate(() => {
  107 |           const samples: number[] = [];
  108 |           Object.assign(window, { densityInputSamples: samples });
  109 |           document.addEventListener("keydown", (event) => {
  110 |             if (event.key !== "Tab") return;
  111 |             const start = event.timeStamp;
  112 |             if (!Number.isFinite(start) || start < 0 || start > performance.now()) throw new Error("Invalid input timestamp clock");
  113 |             const before = document.activeElement;
  114 |             requestAnimationFrame(() => requestAnimationFrame(() => {
  115 |               const active = document.activeElement;
  116 |               if (active === before || !(active instanceof HTMLElement)) return;
  117 |               const rect = active.getBoundingClientRect();
  118 |               if (rect.width > 0 && rect.height > 0 && rect.bottom > 54 && rect.top < innerHeight && rect.right > 0 && rect.left < innerWidth && getComputedStyle(active).outlineStyle !== "none") samples.push(performance.now() - start);
  119 |             }));
  120 |           }, true);
  121 |         });
  122 |         await page.locator("#sector-0").focus();
  123 |         for (let index = 0; index < 40; index += 1) {
  124 |           await page.keyboard.press("Tab");
  125 |           await page.evaluate(() => new Promise<void>((resolve) => requestAnimationFrame(() => requestAnimationFrame(() => resolve()))));
  126 |         }
  127 |         interaction = await page.evaluate(() => Reflect.get(window, "densityInputSamples") as number[]);
  128 |         expect(interaction).toHaveLength(40);
  129 |         const sorted = [...interaction].sort((a, b) => a - b);
  130 |         const p95 = sorted[Math.ceil(sorted.length * 0.95) - 1]!;
  131 |         if (enabled) p95PerArm.push(p95);
  132 |         sampling = false;
  133 |         await sampler;
  134 |         const peak = Math.max(...samples.map((sample) => sample.rss));
  135 |         peaks[enabled ? "enabled" : "disabled"]!.push(peak);
  136 |         runs.push({ pair, mode, enabled, p95Ms: p95, browserVersion: browser.version(), rendered, viewport, interactionMs: interaction, rssSamples: samples, peakRssBytes: peak });
  137 |       } catch (error) {
  138 |         armError = error;
  139 |         throw error;
  140 |       } finally {
  141 |         sampling = false;
  142 |         await sampler;
  143 |         if (page && !page.isClosed()) {
  144 |           try { interaction = await page.evaluate(() => Reflect.get(window, "densityInputSamples") as number[] ?? []); }
  145 |           catch (error) { armError ??= error; }
  146 |         }
  147 |         const raw = testInfo.outputPath(`rss-${browserName}-${pair}-${enabled ? "enabled" : "disabled"}.json`);
  148 |         await writeFile(raw, JSON.stringify({ ...provenance, browserVersion: browser.version(), pair, mode, enabled, viewport, rendered, interaction, armError: armError === undefined ? null : String(armError), samples, samplingError: samplingError === undefined ? null : String(samplingError), completedRuns: runs }, null, 2));
  149 |         await testInfo.attach("density-arm-raw", { path: raw, contentType: "application/json" });
  150 |         await browser.close();
  151 |         await server.close();
  152 |       }
  153 |       if (samplingError !== undefined) throw samplingError;
  154 |       if (armError !== undefined) throw armError;
  155 |     }
  156 |   }
  157 |   const p95 = Math.max(...p95PerArm);
  158 |   const increments = peaks.enabled!.map((peak, index) => peak - peaks.disabled![index]!);
  159 |   const report = {
  160 |     ...provenance,
  161 |     method: "One dedicated browser tree/tab per arm; 50ms sampled summed process RSS from launch through identical 40 Tab interactions. Two order-alternated pairs (state marks, LRU); worst per-arm p95 reported, never averaged across cases. Input keydown to visible outlined focus, bounded by second animation frame. Local diagnostic; manual and dedicated-host qualification remain separate.",
  162 |     p95Ms: p95, incrementalPeakRssBytes: increments, runs,
  163 |     timingPass: p95 <= 100, memoryPass: increments.every((increment) => increment <= 32 * 1024 * 1024),
  164 |   };
  165 |   const output = testInfo.outputPath(`density-${browserName}.json`);
  166 |   await writeFile(output, JSON.stringify(report, null, 2));
  167 |   await testInfo.attach("density-raw", { path: output, contentType: "application/json" });
  168 |   expect(p95).toBeLessThanOrEqual(100);
> 169 |   for (const increment of increments) expect(increment).toBeLessThanOrEqual(32 * 1024 * 1024);
      |                                                         ^ Error: expect(received).toBeLessThanOrEqual(expected)
  170 | });
  171 | 
```