# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: memory-probe.spec.ts >> 12288 rendered page cells: per-browser visible latency and paired RSS
- Location: e2e/memory-probe.spec.ts:40:1

# Error details

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 33554432
Received:    54042624
```

# Test source

```ts
  64  |       const started = performance.now();
  65  |       let sampling = true;
  66  |       let samplingError: unknown;
  67  |       let armError: unknown;
  68  |       let page: Page | undefined;
  69  |       let interaction: number[] = [];
  70  |       let rendered: { count: number; inViewport: number } | null = null;
  71  |       const sampler = (async () => {
  72  |         while (sampling) {
  73  |           samples.push({ elapsedMs: performance.now() - started, rss: await rssTree(pid) });
  74  |           await new Promise((resolve) => setTimeout(resolve, 50));
  75  |         }
  76  |       })().catch((error: unknown) => { samplingError = error; });
  77  |       try {
  78  |         page = await browser.newPage({ viewport });
  79  |         await page.route("**/app.js", (route) => route.fulfill({ contentType: "application/javascript", body: candidateJavascript }));
  80  |         await page.goto("http://127.0.0.1:41742/volume/0", { waitUntil: "commit" });
  81  |         const cells = page.locator("[data-observation-page]");
  82  |         // Exercise real collection pagination; never inject a synthetic model.
  83  |         await loadVolumeCells(page, 12288);
  84  |         await page.evaluate(() => window.scrollTo(0, 0));
  85  |         rendered = await cells.evaluateAll((elements) => ({
  86  |           count: elements.filter((element) => element.getClientRects().length > 0).length,
  87  |           inViewport: elements.filter((element) => {
  88  |             const box = element.getBoundingClientRect();
  89  |             return box.top >= 0 && box.bottom <= innerHeight && box.left >= 0 && box.right <= innerWidth;
  90  |           }).length,
  91  |         }));
  92  |         expect(rendered.count).toBe(12288);
  93  | 
  94  |         if (enabled) {
  95  |           await page.locator(".observation-controls").getByRole("button", { name: "Enable observations" }).click();
  96  |           await expect(page.locator(".observation-detail[aria-label=\"Visible-page buffer observations\"]")).toContainText("Evaluated 512 / requested 512");
  97  |           await page.locator(".observation-controls").getByRole("combobox", { name: "Runtime color mode" }).selectOption(mode);
  98  |         }
  99  |         // Same keyboard focus changes, viewport and DOM workload in both arms.
  100 |         // The second animation frame gives a conservative post-paint bound.
  101 |         await page.evaluate(() => {
  102 |           const samples: number[] = [];
  103 |           Object.assign(window, { densityInputSamples: samples });
  104 |           document.addEventListener("keydown", (event) => {
  105 |             if (event.key !== "Tab") return;
  106 |             const start = event.timeStamp;
  107 |             if (!Number.isFinite(start) || start < 0 || start > performance.now()) throw new Error("Invalid input timestamp clock");
  108 |             const before = document.activeElement;
  109 |             requestAnimationFrame(() => requestAnimationFrame(() => {
  110 |               const active = document.activeElement;
  111 |               if (active === before || !(active instanceof HTMLElement)) return;
  112 |               const rect = active.getBoundingClientRect();
  113 |               if (rect.width > 0 && rect.height > 0 && rect.bottom > 54 && rect.top < innerHeight && rect.right > 0 && rect.left < innerWidth && getComputedStyle(active).outlineStyle !== "none") samples.push(performance.now() - start);
  114 |             }));
  115 |           }, true);
  116 |         });
  117 |         await page.locator("#sector-0").focus();
  118 |         for (let index = 0; index < 40; index += 1) {
  119 |           await page.keyboard.press("Tab");
  120 |           await page.evaluate(() => new Promise<void>((resolve) => requestAnimationFrame(() => requestAnimationFrame(() => resolve()))));
  121 |         }
  122 |         interaction = await page.evaluate(() => Reflect.get(window, "densityInputSamples") as number[]);
  123 |         expect(interaction).toHaveLength(40);
  124 |         const sorted = [...interaction].sort((a, b) => a - b);
  125 |         const p95 = sorted[Math.ceil(sorted.length * 0.95) - 1]!;
  126 |         if (enabled) p95PerArm.push(p95);
  127 |         sampling = false;
  128 |         await sampler;
  129 |         const peak = Math.max(...samples.map((sample) => sample.rss));
  130 |         peaks[enabled ? "enabled" : "disabled"]!.push(peak);
  131 |         runs.push({ pair, mode, enabled, p95Ms: p95, browserVersion: browser.version(), rendered, viewport, interactionMs: interaction, rssSamples: samples, peakRssBytes: peak });
  132 |       } catch (error) {
  133 |         armError = error;
  134 |         throw error;
  135 |       } finally {
  136 |         sampling = false;
  137 |         await sampler;
  138 |         if (page && !page.isClosed()) {
  139 |           try { interaction = await page.evaluate(() => Reflect.get(window, "densityInputSamples") as number[] ?? []); }
  140 |           catch (error) { armError ??= error; }
  141 |         }
  142 |         const raw = testInfo.outputPath(`rss-${browserName}-${pair}-${enabled ? "enabled" : "disabled"}.json`);
  143 |         await writeFile(raw, JSON.stringify({ ...provenance, browserVersion: browser.version(), pair, mode, enabled, viewport, rendered, interaction, armError: armError === undefined ? null : String(armError), samples, samplingError: samplingError === undefined ? null : String(samplingError), completedRuns: runs }, null, 2));
  144 |         await testInfo.attach("density-arm-raw", { path: raw, contentType: "application/json" });
  145 |         await browser.close();
  146 |         await server.close();
  147 |       }
  148 |       if (samplingError !== undefined) throw samplingError;
  149 |       if (armError !== undefined) throw armError;
  150 |     }
  151 |   }
  152 |   const p95 = Math.max(...p95PerArm);
  153 |   const increments = peaks.enabled!.map((peak, index) => peak - peaks.disabled![index]!);
  154 |   const report = {
  155 |     ...provenance,
  156 |     method: "One dedicated browser tree/tab per arm; 50ms sampled summed process RSS from launch through identical 40 Tab interactions. Two order-alternated pairs (state marks, LRU); worst per-arm p95 reported, never averaged across cases. Input keydown to visible outlined focus, bounded by second animation frame. Local diagnostic; manual and dedicated-host qualification remain separate.",
  157 |     p95Ms: p95, incrementalPeakRssBytes: increments, runs,
  158 |     timingPass: p95 <= 100, memoryPass: increments.every((increment) => increment <= 32 * 1024 * 1024),
  159 |   };
  160 |   const output = testInfo.outputPath(`density-${browserName}.json`);
  161 |   await writeFile(output, JSON.stringify(report, null, 2));
  162 |   await testInfo.attach("density-raw", { path: output, contentType: "application/json" });
  163 |   expect(p95).toBeLessThanOrEqual(100);
> 164 |   for (const increment of increments) expect(increment).toBeLessThanOrEqual(32 * 1024 * 1024);
      |                                                         ^ Error: expect(received).toBeLessThanOrEqual(expected)
  165 | });
  166 | 
```