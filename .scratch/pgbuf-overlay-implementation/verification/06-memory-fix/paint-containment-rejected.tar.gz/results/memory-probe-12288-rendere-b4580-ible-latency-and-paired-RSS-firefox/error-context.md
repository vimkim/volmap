# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: memory-probe.spec.ts >> 12288 rendered page cells: per-browser visible latency and paired RSS
- Location: e2e/memory-probe.spec.ts:40:1

# Error details

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 33554432
Received:    54259712
```

# Test source

```ts
  65  |       let armError: unknown;
  66  |       let page: Page | undefined;
  67  |       let interaction: number[] = [];
  68  |       let rendered: { count: number; inViewport: number } | null = null;
  69  |       const sampler = (async () => {
  70  |         while (sampling) {
  71  |           samples.push({ elapsedMs: performance.now() - started, rss: await rssTree(pid) });
  72  |           await new Promise((resolve) => setTimeout(resolve, 50));
  73  |         }
  74  |       })().catch((error: unknown) => { samplingError = error; });
  75  |       try {
  76  |         page = await browser.newPage({ viewport });
  77  |         await page.route("**/app.css", async (route) => {
  78  |           const response = await route.fetch();
  79  |           await route.fulfill({ response, body: `${await response.text()}\n.sector-preview-pages { contain: paint; }\n` });
  80  |         });
  81  |         await page.goto("http://127.0.0.1:41742/volume/0", { waitUntil: "commit" });
  82  |         const cells = page.locator("[data-observation-page]");
  83  |         // Exercise real collection pagination; never inject a synthetic model.
  84  |         await loadVolumeCells(page, 12288);
  85  |         await page.evaluate(() => window.scrollTo(0, 0));
  86  |         rendered = await cells.evaluateAll((elements) => ({
  87  |           count: elements.filter((element) => element.getClientRects().length > 0).length,
  88  |           inViewport: elements.filter((element) => {
  89  |             const box = element.getBoundingClientRect();
  90  |             return box.top >= 0 && box.bottom <= innerHeight && box.left >= 0 && box.right <= innerWidth;
  91  |           }).length,
  92  |         }));
  93  |         expect(rendered.count).toBe(12288);
  94  |         await expect(page.locator(".sector-preview-pages").first()).toHaveCSS("contain", "paint");
  95  |         if (enabled) {
  96  |           await page.locator(".observation-controls").getByRole("button", { name: "Enable observations" }).click();
  97  |           await expect(page.locator(".observation-detail[aria-label=\"Visible-page buffer observations\"]")).toContainText("Evaluated 512 / requested 512");
  98  |           await page.locator(".observation-controls").getByRole("combobox", { name: "Runtime color mode" }).selectOption(mode);
  99  |         }
  100 |         // Same keyboard focus changes, viewport and DOM workload in both arms.
  101 |         // The second animation frame gives a conservative post-paint bound.
  102 |         await page.evaluate(() => {
  103 |           const samples: number[] = [];
  104 |           Object.assign(window, { densityInputSamples: samples });
  105 |           document.addEventListener("keydown", (event) => {
  106 |             if (event.key !== "Tab") return;
  107 |             const start = event.timeStamp;
  108 |             if (!Number.isFinite(start) || start < 0 || start > performance.now()) throw new Error("Invalid input timestamp clock");
  109 |             const before = document.activeElement;
  110 |             requestAnimationFrame(() => requestAnimationFrame(() => {
  111 |               const active = document.activeElement;
  112 |               if (active === before || !(active instanceof HTMLElement)) return;
  113 |               const rect = active.getBoundingClientRect();
  114 |               if (rect.width > 0 && rect.height > 0 && rect.bottom > 54 && rect.top < innerHeight && rect.right > 0 && rect.left < innerWidth && getComputedStyle(active).outlineStyle !== "none") samples.push(performance.now() - start);
  115 |             }));
  116 |           }, true);
  117 |         });
  118 |         await page.locator("#sector-0").focus();
  119 |         for (let index = 0; index < 40; index += 1) {
  120 |           await page.keyboard.press("Tab");
  121 |           await page.evaluate(() => new Promise<void>((resolve) => requestAnimationFrame(() => requestAnimationFrame(() => resolve()))));
  122 |         }
  123 |         interaction = await page.evaluate(() => Reflect.get(window, "densityInputSamples") as number[]);
  124 |         expect(interaction).toHaveLength(40);
  125 |         const sorted = [...interaction].sort((a, b) => a - b);
  126 |         const p95 = sorted[Math.ceil(sorted.length * 0.95) - 1]!;
  127 |         if (enabled) p95PerArm.push(p95);
  128 |         sampling = false;
  129 |         await sampler;
  130 |         const peak = Math.max(...samples.map((sample) => sample.rss));
  131 |         peaks[enabled ? "enabled" : "disabled"]!.push(peak);
  132 |         runs.push({ pair, mode, enabled, p95Ms: p95, browserVersion: browser.version(), rendered, viewport, interactionMs: interaction, rssSamples: samples, peakRssBytes: peak });
  133 |       } catch (error) {
  134 |         armError = error;
  135 |         throw error;
  136 |       } finally {
  137 |         sampling = false;
  138 |         await sampler;
  139 |         if (page && !page.isClosed()) {
  140 |           try { interaction = await page.evaluate(() => Reflect.get(window, "densityInputSamples") as number[] ?? []); }
  141 |           catch (error) { armError ??= error; }
  142 |         }
  143 |         const raw = testInfo.outputPath(`rss-${browserName}-${pair}-${enabled ? "enabled" : "disabled"}.json`);
  144 |         await writeFile(raw, JSON.stringify({ ...provenance, browserVersion: browser.version(), pair, mode, enabled, viewport, rendered, interaction, armError: armError === undefined ? null : String(armError), samples, samplingError: samplingError === undefined ? null : String(samplingError), completedRuns: runs }, null, 2));
  145 |         await testInfo.attach("density-arm-raw", { path: raw, contentType: "application/json" });
  146 |         await browser.close();
  147 |         await server.close();
  148 |       }
  149 |       if (samplingError !== undefined) throw samplingError;
  150 |       if (armError !== undefined) throw armError;
  151 |     }
  152 |   }
  153 |   const p95 = Math.max(...p95PerArm);
  154 |   const increments = peaks.enabled!.map((peak, index) => peak - peaks.disabled![index]!);
  155 |   const report = {
  156 |     ...provenance,
  157 |     method: "One dedicated browser tree/tab per arm; 50ms sampled summed process RSS from launch through identical 40 Tab interactions. Two order-alternated pairs (state marks, LRU); worst per-arm p95 reported, never averaged across cases. Input keydown to visible outlined focus, bounded by second animation frame. Local diagnostic; manual and dedicated-host qualification remain separate.",
  158 |     p95Ms: p95, incrementalPeakRssBytes: increments, runs,
  159 |     timingPass: p95 <= 100, memoryPass: increments.every((increment) => increment <= 32 * 1024 * 1024),
  160 |   };
  161 |   const output = testInfo.outputPath(`density-${browserName}.json`);
  162 |   await writeFile(output, JSON.stringify(report, null, 2));
  163 |   await testInfo.attach("density-raw", { path: output, contentType: "application/json" });
  164 |   expect(p95).toBeLessThanOrEqual(100);
> 165 |   for (const increment of increments) expect(increment).toBeLessThanOrEqual(32 * 1024 * 1024);
      |                                                         ^ Error: expect(received).toBeLessThanOrEqual(expected)
  166 | });
  167 | 
```