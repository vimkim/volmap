import { chromium, firefox } from '@playwright/test';
import { loadVolumeCells } from './e2e/volume-fixture.ts';
import { mkdir, writeFile, readFile } from 'node:fs/promises';
import { execFileSync } from 'node:child_process';
import { gzipSync } from 'node:zlib';
const name = process.argv[2];
const enabled = process.argv[3] === 'enabled';
const variant = process.argv[4] ?? 'base';
const out = `../.scratch/pgbuf-overlay-implementation/verification/06-raster-followup/${name}-${enabled ? 'enabled' : 'disabled'}-${variant}`;
await mkdir(out, { recursive: true });
const server = await ({chromium,firefox}[name]).launchServer({headless:true});
const browser = await ({chromium,firefox}[name]).connect(server.wsEndpoint());
const pid = server.process().pid;
const phases = [];
try {
 const page = await browser.newPage({viewport:{width:1920,height:1080}});
 if (variant !== 'base' && variant !== 'repaint-only' && variant !== 'opacity-only' && variant !== 'shift-only' && variant !== 'recolor-only' && variant !== 'paused-keyboard') {
  const css = await readFile('../src/web/generated/frontend.css', 'utf8');
  const rule = {'nonresident-pseudo':'.preview-page[data-runtime-state=not-resident] > .runtime-glyph { display: none; } .preview-page[data-runtime-state=not-resident]::after { content: "○"; position: absolute; bottom: 2px; right: 2px; color: #fff; background: #071014; font: 8px/1.1 ui-monospace, monospace; pointer-events: none; }','preview-layout':'.sector-preview-pages { contain: layout; }','flow-glyph':'.preview-page:has(> .runtime-glyph) { display: flex; align-items: flex-end; justify-content: flex-end; } .preview-page > .runtime-glyph { position: static; margin: 0 2px 2px 0; }','preview-containment':'.sector-preview-pages { contain: paint; }','legend-hidden':'.runtime-legend { visibility: hidden; }','legend-absent':'.runtime-legend { display: none; }','glyph-hidden':'.preview-page .runtime-glyph { visibility: hidden; }','sidebar-no-scroll':'aside { overflow: visible; }','opaque-disabled':'.observation-controls button:disabled { opacity: 1; }','sidebar-no-detail':'aside .observation-detail { display: none; }','sidebar-hidden':'aside { visibility: hidden; }','sidebar-and-glyphs-hidden':'aside, .preview-page .runtime-glyph { visibility: hidden; }'}[variant];
  if(!rule) throw new Error('Unknown diagnostic variant');
  await page.route('**/app.css', route => route.fulfill({contentType:'text/css',body:css+'\n'+rule}));
 }
 let cdp;
 let layerCdp;
 let layers=[];
 if(name === 'chromium') {
  cdp = await browser.newBrowserCDPSession();
  layerCdp=await page.context().newCDPSession(page);
  layerCdp.on('LayerTree.layerTreeDidChange',event=>{layers=event.layers??[];});
  await layerCdp.send('LayerTree.enable');
  await cdp.send('Tracing.start',{categories:'disabled-by-default-memory-infra,devtools.timeline,cc,gpu',transferMode:'ReturnAsStream'});
 }
 const phase = async (label) => {
  await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));
  const before=performance.now();
  if(cdp) await cdp.send('Tracing.recordClockSyncMarker',{syncId:label});
  const dom=await page.evaluate(()=>({cells:document.querySelectorAll('[data-observation-page]').length,residents:document.querySelectorAll('.preview-page[data-runtime-state=resident]').length,glyphs:document.querySelectorAll('.preview-page .runtime-glyph').length,mode:document.querySelector('#volumeMap')?.getAttribute('data-runtime-mode'),mapTop:document.querySelector('#volumeMap')?.getBoundingClientRect().top,scrollY,sidebar:{height:document.querySelector('aside').clientHeight,scrollHeight:document.querySelector('aside').scrollHeight},source:document.querySelector('.observation-controls')?.textContent,detail:document.querySelector('.observation-detail')?.textContent}));
  const maps=JSON.parse(execFileSync('python3',['/tmp/volmap-raster-maps.py',String(pid)],{encoding:'utf8'}));
  let dump;
  const layerDetails=[];
  if(layerCdp) for(const layer of layers) {
   let reasons; try {reasons=await layerCdp.send('LayerTree.compositingReasons',{layerId:layer.layerId});} catch(error) {reasons={error:String(error)};}
   layerDetails.push({...layer,reasons});
  }
  if(cdp) dump=await cdp.send('Tracing.requestMemoryDump',{deterministic:false,levelOfDetail:'detailed'});
  else execFileSync('python3',['/tmp/volmap-raster-dump-ff.py',String(pid),`${out}/${label}.json.gz`],{timeout:40000});
  phases.push({label,dom,maps,dump,layerDetails,durationMs:performance.now()-before});
  await writeFile(`${out}/phases.json`,JSON.stringify({name,enabled,variant,controlMode:"physical",pid,browserVersion:browser.version(),consumerCommit:execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),phases},null,2));
  process.stdout.write(`${name} ${enabled} ${label}\n`);
 };
 await page.goto('http://127.0.0.1:41744/volume/0',{waitUntil:'commit'});
 await loadVolumeCells(page,12288);
 await page.evaluate(()=>scrollTo(0,0));
 await phase('loaded');
 if(enabled) {
  await page.locator('.observation-controls > button[aria-pressed]').click();
  await page.waitForFunction(()=>document.querySelector('[aria-label="Visible-page buffer observations"]')?.textContent?.includes('Evaluated 512 / requested 512'));
 }
 if(variant === 'shift-only') await page.evaluate(()=>{document.querySelector('#volumeMap').style.marginTop='125.2px';});
 if(variant === 'recolor-only') await page.evaluate(()=>{document.querySelector('#volumeMap').dataset.runtimeMode='lru';});
 if(variant === 'opacity-only') await page.evaluate(()=>{document.querySelector('.observation-controls > button[aria-pressed]').style.opacity='0.55';});
 if(variant === 'repaint-only') await page.evaluate(()=>{document.querySelector('#volumeMap').style.backgroundColor='#101820';});
 await phase('enabled');
 if(enabled) await page.locator('.runtime-mode select').selectOption('lru');
 await phase('lru');
 if(variant === 'paused-keyboard') await page.getByRole('button', {name:'Pause',exact:true}).click();
 await page.locator('#sector-0').focus();
 for(let i=0;i<40;i++) {
  await page.keyboard.press('Tab');
  await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));
 }
 await phase('keyboard');
 if(cdp) {
  const completed=new Promise(resolve=>cdp.once('Tracing.tracingComplete',resolve));
  await cdp.send('Tracing.end');
  const {stream}=await completed;
  let content='';
  for(;;) {const chunk=await cdp.send('IO.read',{handle:stream});content+=chunk.base64Encoded?Buffer.from(chunk.data,'base64').toString():chunk.data;if(chunk.eof)break;}
  await cdp.send('IO.close',{handle:stream});
  await writeFile(`${out}/trace.json.gz`,gzipSync(content));
 }
} finally { await browser.close(); await server.close(); }
