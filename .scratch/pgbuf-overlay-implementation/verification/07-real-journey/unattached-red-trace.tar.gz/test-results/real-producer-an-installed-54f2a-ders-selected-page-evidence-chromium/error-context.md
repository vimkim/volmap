# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: real-producer.spec.ts >> an installed CUBRID producer attaches through HTTP and renders selected-page evidence
- Location: e2e/real-producer.spec.ts:3:1

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByRole('region', { name: 'CUBRID page-buffer observation' })
Expected substring: "Observation source: active"
Received string:    "CUBRID page-buffer observationDisable observationsRuntime color modeState marksLRU topologyRefresh selected-page observationObservation unavailableObservation source: unavailableNo verified producer observation is available. Disk inspection is unaffected."
Timeout: 5000ms

Call log:
  - Expect "toContainText" with timeout 5000ms
  - waiting for getByRole('region', { name: 'CUBRID page-buffer observation' })
    - locator resolved to <section class="observation-controls" aria-label="CUBRID page-buffer observation">…</section>
    - unexpected value "CUBRID page-buffer observationDisable observationsRuntime color modeState marksLRU topologyRefresh selected-page observationObserving selected page…Observation source: disabledNot requested. Enable explicitly when starting a loopback viewer."
    13 × locator resolved to <section class="observation-controls" aria-label="CUBRID page-buffer observation">…</section>
       - unexpected value "CUBRID page-buffer observationDisable observationsRuntime color modeState marksLRU topologyRefresh selected-page observationObservation unavailableObservation source: unavailableNo verified producer observation is available. Disk inspection is unaffected."

```

```yaml
- region "CUBRID page-buffer observation":
  - heading "CUBRID page-buffer observation" [level=2]
  - button "Disable observations" [pressed]
  - text: Runtime color mode
  - combobox "Runtime color mode":
    - option "State marks" [selected]
    - option "LRU topology"
  - button "Refresh selected-page observation"
  - paragraph: Observation unavailable
  - paragraph: "Observation source: unavailable"
  - paragraph: No verified producer observation is available. Disk inspection is unaffected.
```

# Test source

```ts
  1  | import { expect, test } from "@playwright/test";
  2  | 
  3  | test("an installed CUBRID producer attaches through HTTP and renders selected-page evidence", async ({ page }) => {
  4  |   await page.goto("/page/0/0", { waitUntil: "commit" });
  5  |   await expect(page.getByRole("heading", { name: "Page facts" })).toBeVisible();
  6  |   const source = page.getByRole("region", { name: "CUBRID page-buffer observation" });
  7  |   await source.getByRole("button", { name: "Enable observations" }).click();
> 8  |   await expect(source).toContainText("Observation source: active");
     |                        ^ Error: expect(locator).toContainText(expected) failed
  9  |   const detail = page.getByRole("region", { name: "Selected-page buffer observation" });
  10 |   await expect(detail).toContainText("VPID 0:0");
  11 |   await expect(detail).toContainText("Observed resident");
  12 |   const capability = await page.request.get("/api/v1/runtime/capabilities");
  13 |   expect(capability.status()).toBe(200);
  14 |   expect(capability.headers()["cache-control"]).toBe("no-store");
  15 |   expect(await capability.json()).toMatchObject({
  16 |     source: "cubrid-page-buffer-observation", state: "active", verification: "verified",
  17 |   });
  18 | });
  19 | 
```