# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: real-producer.spec.ts >> a real producer restart while paused revokes its incarnation and explicit retry recovers
- Location: e2e/real-producer.spec.ts:44:1

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByRole('region', { name: 'Selected-page buffer observation' })
Expected substring: "Observed resident"
Received string:    "Buffer observationincarnation-changedRefresh to request a separate runtime observation. Disk facts remain independently observed."
Timeout: 5000ms

Call log:
  - Expect "toContainText" with timeout 5000ms
  - waiting for getByRole('region', { name: 'Selected-page buffer observation' })
    14 × locator resolved to <section class="panel observation-detail" aria-label="Selected-page buffer observation">…</section>
       - unexpected value "Buffer observationincarnation-changedRefresh to request a separate runtime observation. Disk facts remain independently observed."

```

```yaml
- region "Selected-page buffer observation":
  - heading "Buffer observation" [level=2]
  - paragraph: incarnation-changed
  - paragraph: Refresh to request a separate runtime observation. Disk facts remain independently observed.
```

# Test source

```ts
  1  | import { expect, test } from "@playwright/test";
  2  | import { execFileSync } from "node:child_process";
  3  | import { appendFileSync, readFileSync } from "node:fs";
  4  | import { join } from "node:path";
  5  | 
  6  | function runtime() {
  7  |   const config = JSON.parse(readFileSync(process.env.VOLMAP_PRODUCER_RUN!, "utf8"));
  8  |   return JSON.parse(readFileSync(join(config.output_directory, "runtime.json"), "utf8"));
  9  | }
  10 | 
  11 | function producerCommand(action: "start" | "stop") {
  12 |   const run = runtime();
  13 |   const output = execFileSync(join(run.producer_install, "bin/cubrid"), ["server", action, "volmap07"], {
  14 |     cwd: run.database_root,
  15 |     env: { ...process.env, CUBRID: run.producer_install,
  16 |       CUBRID_DATABASES: run.database_root, CUBRID_TMP: run.database_root,
  17 |       CUBRID_CONF_FILE: join(run.database_root, "cubrid.conf"),
  18 |       PATH: `${run.producer_install}/bin:${process.env.PATH}`,
  19 |       LD_LIBRARY_PATH: `${run.producer_install}/lib:${run.producer_install}/cci/lib` },
  20 |     timeout: 15_000,
  21 |     encoding: "utf8",
  22 |   });
  23 |   appendFileSync(join(run.output_directory, "browser-lifecycle.log"), `$ cubrid server ${action} volmap07\n${output}\n`);
  24 | }
  25 | 
  26 | test("an installed CUBRID producer attaches through HTTP and renders selected-page evidence", async ({ page }, testInfo) => {
  27 |   await page.goto("/page/0/0", { waitUntil: "commit" });
  28 |   await expect(page.getByRole("heading", { name: "Page facts" })).toBeVisible();
  29 |   const source = page.getByRole("region", { name: "CUBRID page-buffer observation" });
  30 |   await source.getByRole("button", { name: "Enable observations" }).click();
  31 |   await expect(source).toContainText("Observation source: active");
  32 |   const detail = page.getByRole("region", { name: "Selected-page buffer observation" });
  33 |   await expect(detail).toContainText("VPID 0:0");
  34 |   await expect(detail).toContainText("Observed resident");
  35 |   const capability = await page.request.get("/api/v1/runtime/capabilities");
  36 |   expect(capability.status()).toBe(200);
  37 |   expect(capability.headers()["cache-control"]).toBe("no-store");
  38 |   expect(await capability.json()).toMatchObject({
  39 |     source: "cubrid-page-buffer-observation", state: "active", verification: "verified",
  40 |   });
  41 |   await testInfo.attach("selected-page", { body: await page.screenshot({ fullPage: true }), contentType: "image/png" });
  42 | });
  43 | 
  44 | test("a real producer restart while paused revokes its incarnation and explicit retry recovers", async ({ page }) => {
  45 |   test.setTimeout(45_000);
  46 |   await page.goto("/page/0/0", { waitUntil: "commit" });
  47 |   const source = page.getByRole("region", { name: "CUBRID page-buffer observation" });
  48 |   const detail = page.getByRole("region", { name: "Selected-page buffer observation" });
  49 |   await source.getByRole("button", { name: "Enable observations" }).click();
> 50 |   await expect(detail).toContainText("Observed resident");
     |                        ^ Error: expect(locator).toContainText(expected) failed
  51 |   const before = await (await page.request.get("/api/v1/runtime/capabilities")).json();
  52 |   await page.getByRole("button", { name: "Pause", exact: true }).click();
  53 |   producerCommand("stop");
  54 |   producerCommand("start");
  55 |   await expect(source).toContainText("incarnation-changed", { timeout: 10_000 });
  56 |   await expect(detail).not.toContainText("Observed resident");
  57 |   await expect(page.getByRole("heading", { name: "Page facts" })).toBeVisible();
  58 |   await page.getByRole("button", { name: "Resume", exact: true }).click();
  59 |   await expect(source).toContainText("Automatic retry stopped");
  60 |   await source.getByRole("button", { name: "Refresh selected-page observation" }).click();
  61 |   await expect(detail).toContainText("Observed resident");
  62 |   const after = await (await page.request.get("/api/v1/runtime/capabilities")).json();
  63 |   expect(after.state).toBe("active");
  64 |   expect(after.incarnation_binding).not.toBe(before.incarnation_binding);
  65 | });
  66 | 
```