# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: real-producer.spec.ts >> a real producer restart while paused revokes its incarnation and explicit retry recovers
- Location: e2e/real-producer.spec.ts:44:1

# Error details

```
Error: spawnSync /home/vimkim/.cub/install/CBRD-27398-pgbuf-inspector-contract/debug_gcc/bin/cubrid ETIMEDOUT
```

# Page snapshot

```yaml
- generic [ref=e2]:
  - banner [ref=e3]:
    - strong [ref=e4]: VOLMAP
    - generic [ref=e5]: snapshot 4484ceb3ec55 · revision 0
    - generic [ref=e6]:
      - generic [ref=e7]: "paused at gen 0 · newer: gen 0"
      - button "Resume" [active] [pressed] [ref=e8] [cursor=pointer]
    - button "About & licenses" [ref=e9] [cursor=pointer]
    - generic [ref=e10]: success-limited
  - main [ref=e11]:
    - complementary [ref=e12]:
      - region "CUBRID page-buffer observation" [ref=e13]:
        - heading "CUBRID page-buffer observation" [level=2] [ref=e14]
        - button "Disable observations" [pressed] [ref=e15] [cursor=pointer]
        - generic [ref=e16]:
          - text: Runtime color mode
          - combobox "Runtime color mode" [ref=e17]:
            - option "State marks" [selected]
            - option "LRU topology"
        - button "Refresh selected-page observation" [disabled] [ref=e18]
        - paragraph [ref=e19]: incarnation-changed
        - paragraph [ref=e20]: Automatic retry stopped · Refresh explicitly to retry attachment.
        - paragraph [ref=e21]: "Observation source: refused"
      - heading "Snapshot hierarchy" [level=2] [ref=e22]
      - generic [ref=e23]:
        - button "volume 0 · 64 sectors" [ref=e24] [cursor=pointer]
        - button "volume 1 · 128 sectors" [ref=e25] [cursor=pointer]
    - generic [ref=e26]:
      - navigation "Inspection hierarchy" [ref=e27]:
        - button "← Back" [ref=e28] [cursor=pointer]
        - button "Volume 0" [ref=e30] [cursor=pointer]
        - generic [ref=e31]:
          - text: ›
          - button "Sector 0" [ref=e32] [cursor=pointer]
        - generic [ref=e33]: ›Page 0
      - generic [ref=e34]:
        - generic [ref=e36]:
          - heading "Page 0" [level=1] [ref=e37]
          - paragraph [ref=e38]: volume-header · detailed structural view
        - generic [ref=e39]:
          - generic [ref=e40]:
            - heading "Page facts" [level=2] [ref=e41]
            - generic [ref=e42]:
              - generic [ref=e43]:
                - term [ref=e44]: Identity
                - definition [ref=e45]: page:0:0
              - generic [ref=e46]:
                - term [ref=e47]: Sector
                - definition [ref=e48]: "0"
              - generic [ref=e49]:
                - term [ref=e50]: Physical type
                - definition [ref=e51]: volume-header
              - generic [ref=e52]:
                - term [ref=e53]: Allocation
                - definition [ref=e54]: system-metadata
              - generic [ref=e55]:
                - term [ref=e56]: File
                - definition [ref=e57]: none
              - generic [ref=e58]:
                - term [ref=e59]: File role
                - definition [ref=e60]: none
              - generic [ref=e61]:
                - term [ref=e62]: Class OID
                - definition [ref=e63]: none
              - generic [ref=e64]:
                - term [ref=e65]: Class/table
                - definition [ref=e66]: none
              - generic [ref=e67]:
                - term [ref=e68]: Availability
                - definition [ref=e69]: available
              - generic [ref=e70]:
                - term [ref=e71]: Detail support
                - definition [ref=e72]: semantic
              - generic [ref=e73]:
                - term [ref=e74]: Deep state
                - definition [ref=e75]: not-enriched
              - generic [ref=e76]:
                - term [ref=e77]: TDE
                - definition [ref=e78]: not-encrypted
            - paragraph [ref=e79]: evidence page:0:0 · structural ranges only · bytes withheld
          - region "Selected-page buffer observation" [ref=e80]:
            - heading "Buffer observation" [level=2] [ref=e81]
            - paragraph [ref=e82]: incarnation-changed
            - paragraph [ref=e83]: Refresh to request a separate runtime observation. Disk facts remain independently observed.
          - generic [ref=e84]:
            - heading "Slotted-page distribution" [level=2] [ref=e85]
            - paragraph [ref=e86]: No validated slot directory is available for this page.
```

# Test source

```ts
  1  | import { expect, test } from "@playwright/test";
  2  | import { execFileSync } from "node:child_process";
  3  | import { appendFileSync, readFileSync } from "node:fs";
  4  | import { join } from "node:path";
  5  | 
  6  | function runtime() {
  7  |   const config = JSON.parse(readFileSync(process.env.VOLMAP_PRODUCER_RUN!, "utf8"));
  8  |   return JSON.parse(readFileSync(join(config.output_directory, "runtime.json"), "utf8"));
  9  | }
  10 | 
  11 | function producerCommand(action: "start" | "stop") {
  12 |   const run = runtime();
> 13 |   const output = execFileSync(join(run.producer_install, "bin/cubrid"), ["server", action, "volmap07"], {
     |                  ^ Error: spawnSync /home/vimkim/.cub/install/CBRD-27398-pgbuf-inspector-contract/debug_gcc/bin/cubrid ETIMEDOUT
  14 |     cwd: run.database_root,
  15 |     env: { ...process.env, CUBRID: run.producer_install,
  16 |       CUBRID_DATABASES: run.database_root, CUBRID_TMP: run.database_root,
  17 |       CUBRID_CONF_FILE: join(run.database_root, "cubrid.conf"),
  18 |       PATH: `${run.producer_install}/bin:${process.env.PATH}`,
  19 |       LD_LIBRARY_PATH: `${run.producer_install}/lib:${run.producer_install}/cci/lib` },
  20 |     timeout: 15_000,
  21 |     encoding: "utf8",
  22 |   });
  23 |   appendFileSync(join(run.output_directory, "browser-lifecycle.log"), `$ cubrid server ${action} volmap07\n${output}\n`);
  24 | }
  25 | 
  26 | test("an installed CUBRID producer attaches through HTTP and renders selected-page evidence", async ({ page }, testInfo) => {
  27 |   await page.goto("/page/0/0", { waitUntil: "commit" });
  28 |   await expect(page.getByRole("heading", { name: "Page facts" })).toBeVisible();
  29 |   const source = page.getByRole("region", { name: "CUBRID page-buffer observation" });
  30 |   await source.getByRole("button", { name: "Enable observations" }).click();
  31 |   await expect(source).toContainText("Observation source: active");
  32 |   const detail = page.getByRole("region", { name: "Selected-page buffer observation" });
  33 |   await expect(detail).toContainText("VPID 0:0");
  34 |   await expect(detail).toContainText("Observed resident");
  35 |   const capability = await page.request.get("/api/v1/runtime/capabilities");
  36 |   expect(capability.status()).toBe(200);
  37 |   expect(capability.headers()["cache-control"]).toBe("no-store");
  38 |   expect(await capability.json()).toMatchObject({
  39 |     source: "cubrid-page-buffer-observation", state: "active", verification: "verified",
  40 |   });
  41 |   await testInfo.attach("selected-page", { body: await page.screenshot({ fullPage: true }), contentType: "image/png" });
  42 | });
  43 | 
  44 | test("a real producer restart while paused revokes its incarnation and explicit retry recovers", async ({ page }) => {
  45 |   test.setTimeout(45_000);
  46 |   await page.goto("/page/0/0", { waitUntil: "commit" });
  47 |   const source = page.getByRole("region", { name: "CUBRID page-buffer observation" });
  48 |   const detail = page.getByRole("region", { name: "Selected-page buffer observation" });
  49 |   await source.getByRole("button", { name: "Enable observations" }).click();
  50 |   await expect(detail).toContainText("Observed resident");
  51 |   const before = await (await page.request.get("/api/v1/runtime/capabilities")).json();
  52 |   await page.getByRole("button", { name: "Pause", exact: true }).click();
  53 |   producerCommand("stop");
  54 |   producerCommand("start");
  55 |   await expect(source).toContainText("incarnation-changed", { timeout: 10_000 });
  56 |   await expect(detail).not.toContainText("Observed resident");
  57 |   await expect(page.getByRole("heading", { name: "Page facts" })).toBeVisible();
  58 |   await page.getByRole("button", { name: "Resume", exact: true }).click();
  59 |   await expect(source).toContainText("Automatic retry stopped");
  60 |   await source.getByRole("button", { name: "Refresh selected-page observation" }).click();
  61 |   await expect(detail).toContainText("Observed resident");
  62 |   const after = await (await page.request.get("/api/v1/runtime/capabilities")).json();
  63 |   expect(after.state).toBe("active");
  64 |   expect(after.incarnation_binding).not.toBe(before.incarnation_binding);
  65 | });
  66 | 
```