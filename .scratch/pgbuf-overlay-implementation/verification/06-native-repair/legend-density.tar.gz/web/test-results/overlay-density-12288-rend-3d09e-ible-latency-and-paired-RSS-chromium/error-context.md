# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: overlay-density.spec.ts >> 12288 rendered page cells: per-browser visible latency and paired RSS
- Location: e2e/overlay-density.spec.ts:41:1

# Error details

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 33554432
Received:    34549760
```

# Test source

```ts
  61  |       const browser = await browserType.connect(server.wsEndpoint());
  62  |       const samples: { elapsedMs: number; rss: number }[] = [];
  63  |       const started = performance.now();
  64  |       let sampling = true;
  65  |       let samplingError: unknown;
  66  |       let armError: unknown;
  67  |       let page: Page | undefined;
  68  |       let interaction: number[] = [];
  69  |       let rendered: { count: number; inViewport: number } | null = null;
  70  |       const sampler = (async () => {
  71  |         while (sampling) {
  72  |           samples.push({ elapsedMs: performance.now() - started, rss: await rssTree(pid) });
  73  |           await new Promise((resolve) => setTimeout(resolve, 50));
  74  |         }
  75  |       })().catch((error: unknown) => { samplingError = error; });
  76  |       try {
  77  |         page = await browser.newPage({ viewport });
  78  |         await page.goto(`${densityUrl}/volume/0`, { waitUntil: "commit" });
  79  |         const cells = page.locator("[data-observation-page]");
  80  |         // Exercise real collection pagination; never inject a synthetic model.
  81  |         await loadVolumeCells(page, 12288);
  82  |         await page.evaluate(() => window.scrollTo(0, 0));
  83  |         rendered = await cells.evaluateAll((elements) => ({
  84  |           count: elements.filter((element) => element.getClientRects().length > 0).length,
  85  |           inViewport: elements.filter((element) => {
  86  |             const box = element.getBoundingClientRect();
  87  |             return box.top >= 0 && box.bottom <= innerHeight && box.left >= 0 && box.right <= innerWidth;
  88  |           }).length,
  89  |         }));
  90  |         expect(rendered.count).toBe(12288);
  91  |         if (enabled) {
  92  |           await page.locator(".observation-controls > button[aria-pressed]").click();
  93  |           await expect(page.locator(".observation-detail[aria-label=\"Visible-page buffer observations\"]")).toContainText("Evaluated 512 / requested 512");
  94  |           await page.locator(".runtime-mode select").selectOption(mode);
  95  |         }
  96  |         // Same keyboard focus changes, viewport and DOM workload in both arms.
  97  |         // The second animation frame gives a conservative post-paint bound.
  98  |         await page.evaluate(() => {
  99  |           const samples: number[] = [];
  100 |           Object.assign(window, { densityInputSamples: samples });
  101 |           document.addEventListener("keydown", (event) => {
  102 |             if (event.key !== "Tab") return;
  103 |             const start = event.timeStamp;
  104 |             if (!Number.isFinite(start) || start < 0 || start > performance.now()) throw new Error("Invalid input timestamp clock");
  105 |             const before = document.activeElement;
  106 |             requestAnimationFrame(() => requestAnimationFrame(() => {
  107 |               const active = document.activeElement;
  108 |               if (active === before || !(active instanceof HTMLElement)) return;
  109 |               const rect = active.getBoundingClientRect();
  110 |               if (rect.width > 0 && rect.height > 0 && rect.bottom > 54 && rect.top < innerHeight && rect.right > 0 && rect.left < innerWidth && getComputedStyle(active).outlineStyle !== "none") samples.push(performance.now() - start);
  111 |             }));
  112 |           }, true);
  113 |         });
  114 |         await page.locator("#sector-0").focus();
  115 |         for (let index = 0; index < 40; index += 1) {
  116 |           await page.keyboard.press("Tab");
  117 |           await page.evaluate(() => new Promise<void>((resolve) => requestAnimationFrame(() => requestAnimationFrame(() => resolve()))));
  118 |         }
  119 |         interaction = await page.evaluate(() => Reflect.get(window, "densityInputSamples") as number[]);
  120 |         expect(interaction).toHaveLength(40);
  121 |         const sorted = [...interaction].sort((a, b) => a - b);
  122 |         const p95 = sorted[Math.ceil(sorted.length * 0.95) - 1]!;
  123 |         if (enabled) p95PerArm.push(p95);
  124 |         sampling = false;
  125 |         await sampler;
  126 |         const peak = Math.max(...samples.map((sample) => sample.rss));
  127 |         peaks[enabled ? "enabled" : "disabled"]!.push(peak);
  128 |         runs.push({ pair, mode, enabled, p95Ms: p95, browserVersion: browser.version(), rendered, viewport, interactionMs: interaction, rssSamples: samples, peakRssBytes: peak });
  129 |       } catch (error) {
  130 |         armError = error;
  131 |         throw error;
  132 |       } finally {
  133 |         sampling = false;
  134 |         await sampler;
  135 |         if (page && !page.isClosed()) {
  136 |           try { interaction = await page.evaluate(() => Reflect.get(window, "densityInputSamples") as number[] ?? []); }
  137 |           catch (error) { armError ??= error; }
  138 |         }
  139 |         const raw = testInfo.outputPath(`rss-${browserName}-${pair}-${enabled ? "enabled" : "disabled"}.json`);
  140 |         await writeFile(raw, JSON.stringify({ ...provenance, browserVersion: browser.version(), pair, mode, enabled, viewport, rendered, interaction, armError: armError === undefined ? null : String(armError), samples, samplingError: samplingError === undefined ? null : String(samplingError), completedRuns: runs }, null, 2));
  141 |         await testInfo.attach("density-arm-raw", { path: raw, contentType: "application/json" });
  142 |         await browser.close();
  143 |         await server.close();
  144 |       }
  145 |       if (samplingError !== undefined) throw samplingError;
  146 |       if (armError !== undefined) throw armError;
  147 |     }
  148 |   }
  149 |   const p95 = Math.max(...p95PerArm);
  150 |   const increments = peaks.enabled!.map((peak, index) => peak - peaks.disabled![index]!);
  151 |   const report = {
  152 |     ...provenance,
  153 |     method: "One dedicated browser tree/tab per arm; 50ms sampled summed process RSS from launch through identical 40 Tab interactions. Two order-alternated pairs (state marks, LRU); worst per-arm p95 reported, never averaged across cases. Input keydown to visible outlined focus, bounded by second animation frame. Local diagnostic; manual and dedicated-host qualification remain separate.",
  154 |     p95Ms: p95, incrementalPeakRssBytes: increments, runs,
  155 |     timingPass: p95 <= 100, memoryPass: increments.every((increment) => increment <= 32 * 1024 * 1024),
  156 |   };
  157 |   const output = testInfo.outputPath(`density-${browserName}.json`);
  158 |   await writeFile(output, JSON.stringify(report, null, 2));
  159 |   await testInfo.attach("density-raw", { path: output, contentType: "application/json" });
  160 |   expect(p95).toBeLessThanOrEqual(100);
> 161 |   for (const increment of increments) expect(increment).toBeLessThanOrEqual(32 * 1024 * 1024);
      |                                                         ^ Error: expect(received).toBeLessThanOrEqual(expected)
  162 | });
  163 | 
```