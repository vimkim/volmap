# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: observations.spec.ts >> cached unavailable metadata does not turn a pending first capture into page failures
- Location: e2e/observations.spec.ts:368:1

# Error details

```
Error: expect(locator).toHaveCSS(expected) failed

Locator:  getByRole('region', { name: 'CUBRID page-buffer observation' }).getByRole('button', { name: 'Refresh visible-page observations' })
Expected: "1"
Received: "0.55"
Timeout:  5000ms

Call log:
  - Expect "toHaveCSS" with timeout 5000ms
  - waiting for getByRole('region', { name: 'CUBRID page-buffer observation' }).getByRole('button', { name: 'Refresh visible-page observations' })
    14 × locator resolved to <button disabled type="button">Refresh visible-page observations</button>
       - unexpected value "0.55"

```

```yaml
- button "Refresh visible-page observations" [disabled]
```

# Test source

```ts
  291 |     await page.screenshot({ path: `../.scratch/pgbuf-overlay-implementation/verification/05-${scale.split("/")[0]}-${browserName}.png` });
  292 |     await page.clock.runFor(31000);
  293 |     await expect(cell(10)).toHaveAttribute("data-runtime-state", "expired");
  294 |     await expect(cell(10)).not.toHaveClass(/runtime-resident/);
  295 |     await expect(coverage).not.toContainText("private list 1: 1");
  296 |     complete = true;
  297 |     await page.getByRole("button", { name: "Resume", exact: true }).click();
  298 |     await expect(cell(10)).toHaveAttribute("title", /Observed not resident/);
  299 |     await expect(cell(10)).not.toHaveClass(/runtime-resident/);
  300 |     await expect(coverage).toContainText("No exact list membership observed");
  301 |     await expect(page.locator("#crumb")).toHaveText(revision);
  302 |   });
  303 | }
  304 | 
  305 | test("selected detail exposes exact membership and null meanings; inconsistent topology is refused", async ({ page }) => {
  306 |   let variant = "private";
  307 |   await page.route("**/runtime/page-buffer/observe", async (route) => {
  308 |     const response = await route.fetch();
  309 |     const body = await response.json();
  310 |     const row = body.observations[0];
  311 |     if (row.evidence) {
  312 |       row.evidence.lru_list_kind = variant === "out-of-range" ? "private" : variant;
  313 |       row.evidence.lru_list_index = variant === "private" ? 1 : variant === "out-of-range" ? 3 : null;
  314 |       row.evidence.lru_zone = variant === "none" ? "void" : "lru2";
  315 |     }
  316 |     await route.fulfill({ response, json: body });
  317 |   });
  318 |   await page.goto("http://127.0.0.1:41741/page/0/10", { waitUntil: "commit" });
  319 |   await page.getByRole("button", { name: "Enable observations" }).click();
  320 |   const detail = page.getByRole("region", { name: "Selected-page buffer observation" });
  321 |   await expect(detail).toContainText("Observed resident");
  322 |   await expect(detail).toContainText("lru list index1");
  323 |   await expect(detail).toContainText("incarnation-local");
  324 |   for (const kind of ["none", "invalid"]) {
  325 |     variant = kind;
  326 |     await expect(detail).toContainText(`lru list kind${kind}`);
  327 |     await expect(detail).toContainText("lru list indexnone / not applicable");
  328 |   }
  329 |   variant = "out-of-range";
  330 |   await expect(page.getByRole("region", { name: "CUBRID page-buffer observation" })).toContainText("Incompatible observation response");
  331 |   await expect(detail).not.toContainText("Observed resident");
  332 | });
  333 | 
  334 | for (const scale of ["volume/0", "sector/0/0"]) {
  335 |   test(`${scale} source failure hides marks and paused incarnation change revokes every list`, async ({ page }) => {
  336 |     await page.clock.install();
  337 |     await page.goto(`http://127.0.0.1:41741/${scale}`, { waitUntil: "commit" });
  338 |     await page.getByRole("button", { name: "Enable observations" }).click();
  339 |     const cell = page.locator('[data-observation-page="0:10"]');
  340 |     await expect(cell).toHaveAttribute("data-runtime-state", "resident");
  341 |     await page.getByRole("button", { name: "Pause", exact: true }).click();
  342 |     await page.route("**/runtime/capabilities", async (route) => {
  343 |       const response = await route.fetch();
  344 |       const body = await response.json();
  345 |       body.incarnation_binding = "a-new-server-incarnation";
  346 |       await route.fulfill({ response, json: body });
  347 |     });
  348 |     await page.clock.runFor(5000);
  349 |     const source = page.getByRole("region", { name: "CUBRID page-buffer observation" });
  350 |     await expect(source).toContainText("incarnation-changed");
  351 |     await expect(cell).not.toHaveClass(/runtime-resident/);
  352 |     await expect(page.getByRole("region", { name: "Visible-page buffer observations" })).not.toContainText("Shared lists:");
  353 |     await page.unroute("**/runtime/capabilities");
  354 |     await page.getByRole("button", { name: "Resume", exact: true }).click();
  355 |     await page.getByRole("button", { name: "Refresh visible-page observations" }).click();
  356 |     await expect(cell).toHaveAttribute("data-runtime-state", "resident");
  357 |     await page.route("**/runtime/page-buffer/observe", (route) => route.abort("failed"));
  358 |     await page.clock.runFor(2000);
  359 |     await expect(source).toContainText("Observation source: unavailable");
  360 |     await expect(cell).toHaveAttribute("data-runtime-state", "unavailable");
  361 |     await expect(cell).not.toHaveClass(/runtime-resident/);
  362 |     await expect(cell).not.toHaveAttribute("title", /Observed not resident/);
  363 |     await expect(page.getByRole("region", { name: "Runtime overlay legend" })).toContainText("Source: unavailable");
  364 |     await expect(page.getByRole("heading", { level: 1 })).toContainText(scale.startsWith("volume") ? "Volume 0" : "Sector 0");
  365 |   });
  366 | }
  367 | 
  368 | test("cached unavailable metadata does not turn a pending first capture into page failures", async ({ page }) => {
  369 |   await page.route("**/runtime/capabilities", (route) => route.fulfill({
  370 |     status: 200, headers: { "cache-control": "no-store" },
  371 |     json: { schema: "volmap.runtime", schema_version: 1, source: "cubrid-page-buffer-observation",
  372 |       state: "unavailable", verification: "unverified", reason: "observation-expired",
  373 |       incarnation_binding: null, capture_identity: null, revision: "0" },
  374 |   }));
  375 |   let releaseCapture!: () => void;
  376 |   const captureGate = new Promise<void>((resolve) => { releaseCapture = resolve; });
  377 |   await page.route("**/runtime/page-buffer/observe", async (route) => {
  378 |     await captureGate;
  379 |     await route.fulfill({ status: 503, json: { code: "runtime-unavailable" } });
  380 |   });
  381 |   await page.goto("http://127.0.0.1:41741/volume/0", { waitUntil: "commit" });
  382 |   const source = page.getByRole("region", { name: "CUBRID page-buffer observation" });
  383 |   await expect(source).toContainText("Observation source: unavailable");
  384 |   const pending = page.waitForRequest("**/runtime/page-buffer/observe");
  385 |   await source.getByRole("button", { name: "Enable observations" }).click();
  386 |   await pending;
  387 |   try {
  388 |     await expect(source).toContainText("Observing visible pages");
  389 |     const refresh = source.getByRole("button", { name: "Refresh visible-page observations" });
  390 |     await expect(refresh).toBeDisabled();
> 391 |     await expect(refresh).toHaveCSS("opacity", "1");
      |                           ^ Error: expect(locator).toHaveCSS(expected) failed
  392 |     await expect(refresh).toHaveCSS("outline-style", "dashed");
  393 |     await expect(page.locator('.preview-page[data-runtime-state="unavailable"]')).toHaveCount(0);
  394 |     await expect(page.locator(".sector-card").first()).toHaveAccessibleName(/source unavailable/);
  395 |   } finally {
  396 |     releaseCapture();
  397 |   }
  398 |   await expect(source).toContainText("Observation unavailable");
  399 |   await expect(page.locator('.preview-page[data-runtime-state="unavailable"]').first()).toHaveAttribute("title", /No usable observation/);
  400 |   await page.unroute("**/runtime/page-buffer/observe");
  401 |   await source.getByRole("button", { name: "Refresh visible-page observations" }).click();
  402 |   await expect(source).toContainText("Observation source: active");
  403 |   await expect(page.locator('.preview-page[data-runtime-state="resident"]').first()).toHaveAttribute("title", /Observed resident/);
  404 | });
  405 | 
```