import { defineConfig } from "@playwright/test";
import density from "./playwright.density.config";
export default defineConfig({ ...density, testMatch: "**/density-bundle-probe.spec.ts", outputDir: process.env.VOLMAP_DENSITY_OUTPUT! });
