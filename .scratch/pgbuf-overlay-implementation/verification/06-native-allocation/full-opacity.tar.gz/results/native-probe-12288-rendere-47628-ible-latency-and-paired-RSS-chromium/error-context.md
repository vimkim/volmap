# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: native-probe.spec.ts >> 12288 rendered page cells: per-browser visible latency and paired RSS
- Location: e2e/native-probe.spec.ts:40:1

# Error details

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 33554432
Received:    47751168
```

# Test source

```ts
  63  |       const samples: { elapsedMs: number; rss: number }[] = [];
  64  |       const started = performance.now();
  65  |       let sampling = true;
  66  |       let samplingError: unknown;
  67  |       let armError: unknown;
  68  |       let page: Page | undefined;
  69  |       let interaction: number[] = [];
  70  |       let rendered: { count: number; inViewport: number } | null = null;
  71  |       const sampler = (async () => {
  72  |         while (sampling) {
  73  |           samples.push({ elapsedMs: performance.now() - started, rss: await rssTree(pid) });
  74  |           await new Promise((resolve) => setTimeout(resolve, 50));
  75  |         }
  76  |       })().catch((error: unknown) => { samplingError = error; });
  77  |       try {
  78  |         page = await browser.newPage({ viewport });
  79  |         await page.route("**/app.css", route => route.fulfill({ contentType: "text/css", body: candidateCss }));
  80  |         await page.goto("http://127.0.0.1:41742/volume/0", { waitUntil: "commit" });
  81  |         const cells = page.locator("[data-observation-page]");
  82  |         // Exercise real collection pagination; never inject a synthetic model.
  83  |         await loadVolumeCells(page, 12288);
  84  |         await page.evaluate(() => window.scrollTo(0, 0));
  85  |         rendered = await cells.evaluateAll((elements) => ({
  86  |           count: elements.filter((element) => element.getClientRects().length > 0).length,
  87  |           inViewport: elements.filter((element) => {
  88  |             const box = element.getBoundingClientRect();
  89  |             return box.top >= 0 && box.bottom <= innerHeight && box.left >= 0 && box.right <= innerWidth;
  90  |           }).length,
  91  |         }));
  92  |         expect(rendered.count).toBe(12288);
  93  |         if (enabled) {
  94  |           await page.locator(".observation-controls > button[aria-pressed]").click();
  95  |           await expect(page.locator(".observation-detail[aria-label=\"Visible-page buffer observations\"]")).toContainText("Evaluated 512 / requested 512");
  96  |           await page.locator(".runtime-mode select").selectOption(mode);
  97  |         }
  98  |         // Same keyboard focus changes, viewport and DOM workload in both arms.
  99  |         // The second animation frame gives a conservative post-paint bound.
  100 |         await page.evaluate(() => {
  101 |           const samples: number[] = [];
  102 |           Object.assign(window, { densityInputSamples: samples });
  103 |           document.addEventListener("keydown", (event) => {
  104 |             if (event.key !== "Tab") return;
  105 |             const start = event.timeStamp;
  106 |             if (!Number.isFinite(start) || start < 0 || start > performance.now()) throw new Error("Invalid input timestamp clock");
  107 |             const before = document.activeElement;
  108 |             requestAnimationFrame(() => requestAnimationFrame(() => {
  109 |               const active = document.activeElement;
  110 |               if (active === before || !(active instanceof HTMLElement)) return;
  111 |               const rect = active.getBoundingClientRect();
  112 |               if (rect.width > 0 && rect.height > 0 && rect.bottom > 54 && rect.top < innerHeight && rect.right > 0 && rect.left < innerWidth && getComputedStyle(active).outlineStyle !== "none") samples.push(performance.now() - start);
  113 |             }));
  114 |           }, true);
  115 |         });
  116 |         await page.locator("#sector-0").focus();
  117 |         for (let index = 0; index < 40; index += 1) {
  118 |           await page.keyboard.press("Tab");
  119 |           await page.evaluate(() => new Promise<void>((resolve) => requestAnimationFrame(() => requestAnimationFrame(() => resolve()))));
  120 |         }
  121 |         interaction = await page.evaluate(() => Reflect.get(window, "densityInputSamples") as number[]);
  122 |         expect(interaction).toHaveLength(40);
  123 |         const sorted = [...interaction].sort((a, b) => a - b);
  124 |         const p95 = sorted[Math.ceil(sorted.length * 0.95) - 1]!;
  125 |         if (enabled) p95PerArm.push(p95);
  126 |         sampling = false;
  127 |         await sampler;
  128 |         const peak = Math.max(...samples.map((sample) => sample.rss));
  129 |         peaks[enabled ? "enabled" : "disabled"]!.push(peak);
  130 |         runs.push({ pair, mode, enabled, p95Ms: p95, browserVersion: browser.version(), rendered, viewport, interactionMs: interaction, rssSamples: samples, peakRssBytes: peak });
  131 |       } catch (error) {
  132 |         armError = error;
  133 |         throw error;
  134 |       } finally {
  135 |         sampling = false;
  136 |         await sampler;
  137 |         if (page && !page.isClosed()) {
  138 |           try { interaction = await page.evaluate(() => Reflect.get(window, "densityInputSamples") as number[] ?? []); }
  139 |           catch (error) { armError ??= error; }
  140 |         }
  141 |         const raw = testInfo.outputPath(`rss-${browserName}-${pair}-${enabled ? "enabled" : "disabled"}.json`);
  142 |         await writeFile(raw, JSON.stringify({ ...provenance, browserVersion: browser.version(), pair, mode, enabled, viewport, rendered, interaction, armError: armError === undefined ? null : String(armError), samples, samplingError: samplingError === undefined ? null : String(samplingError), completedRuns: runs }, null, 2));
  143 |         await testInfo.attach("density-arm-raw", { path: raw, contentType: "application/json" });
  144 |         await browser.close();
  145 |         await server.close();
  146 |       }
  147 |       if (samplingError !== undefined) throw samplingError;
  148 |       if (armError !== undefined) throw armError;
  149 |     }
  150 |   }
  151 |   const p95 = Math.max(...p95PerArm);
  152 |   const increments = peaks.enabled!.map((peak, index) => peak - peaks.disabled![index]!);
  153 |   const report = {
  154 |     ...provenance,
  155 |     method: "One dedicated browser tree/tab per arm; 50ms sampled summed process RSS from launch through identical 40 Tab interactions. Two order-alternated pairs (state marks, LRU); worst per-arm p95 reported, never averaged across cases. Input keydown to visible outlined focus, bounded by second animation frame. Local diagnostic; manual and dedicated-host qualification remain separate.",
  156 |     p95Ms: p95, incrementalPeakRssBytes: increments, runs,
  157 |     timingPass: p95 <= 100, memoryPass: increments.every((increment) => increment <= 32 * 1024 * 1024),
  158 |   };
  159 |   const output = testInfo.outputPath(`density-${browserName}.json`);
  160 |   await writeFile(output, JSON.stringify(report, null, 2));
  161 |   await testInfo.attach("density-raw", { path: output, contentType: "application/json" });
  162 |   expect(p95).toBeLessThanOrEqual(100);
> 163 |   for (const increment of increments) expect(increment).toBeLessThanOrEqual(32 * 1024 * 1024);
      |                                                         ^ Error: expect(received).toBeLessThanOrEqual(expected)
  164 | });
  165 | 
```